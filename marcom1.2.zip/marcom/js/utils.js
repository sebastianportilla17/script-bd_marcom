/* ================================================================
   utils.js — Funciones Utilitarias Puras MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Reescrito

   NO manipula el DOM directamente (excepto showToast).
   NO hace fetch ni accede a localStorage.
   Es usado por render.js, init.js, components/ y charts/.
   ================================================================ */

'use strict';

const Utils = (() => {

  /* ================================================================
     1. FORMATO DE MONEDA
     Convierte un número a string COP con separadores de miles.
     formatCurrency(1500000)       → "$ 1.500.000"
     formatCurrency(1500000, true) → "$ 1.5M"
  ================================================================ */
  function formatCurrency(value, compact = false) {
    if (value === null || value === undefined || isNaN(value)) return '$ 0';
    if (compact) {
      if (Math.abs(value) >= 1_000_000_000) return `$ ${(value / 1_000_000_000).toFixed(1)}B`;
      if (Math.abs(value) >= 1_000_000)     return `$ ${(value / 1_000_000).toFixed(1)}M`;
      if (Math.abs(value) >= 1_000)         return `$ ${(value / 1_000).toFixed(0)}K`;
    }
    return '$ ' + Math.round(value).toLocaleString('es-CO');
  }


  /* ================================================================
     2. FORMATO DE NÚMERO
     formatNumber(1234)      → "1.234"
     formatNumber(1234, '%') → "1.234 %"
     formatNumber(45.6)      → "45.6"
  ================================================================ */
  function formatNumber(value, suffix = '', decimals = null) {
    if (value === null || value === undefined || isNaN(value)) return '0';
    const num = decimals !== null ? Number(value).toFixed(decimals) : value;
    const parts = String(num).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    const result = parts.join(',');
    return suffix ? `${result} ${suffix}` : result;
  }


  /* ================================================================
     3. FORMATO DE FECHA
     formatDate(new Date())  → "lun. 8 mar. 2026"
     formatDate(new Date(), 'short') → "08/03/2026"
  ================================================================ */
  function formatDate(date, style = 'long') {
    if (!(date instanceof Date) || isNaN(date)) return '—';
    if (style === 'short') {
      return date.toLocaleDateString('es-CO', {
        day:   '2-digit',
        month: '2-digit',
        year:  'numeric',
      });
    }
    return date.toLocaleDateString('es-CO', {
      weekday: 'short',
      day:     'numeric',
      month:   'short',
      year:    'numeric',
    });
  }


  /* ================================================================
     4. CLASES DE SCORE
     Devuelve las clases CSS para colorear el score del lead.
     scoreClass(85) → { fill: 'sf-high', val: 'sv-high' }
  ================================================================ */
  function scoreClass(score) {
    const s = Number(score);
    if (s >= (window.THRESHOLDS?.score?.high ?? 70)) return { fill: 'sf-high', val: 'sv-high' };
    if (s >= (window.THRESHOLDS?.score?.mid  ?? 40)) return { fill: 'sf-mid',  val: 'sv-mid'  };
    return { fill: 'sf-low', val: 'sv-low' };
  }


  /* ================================================================
     5. CLASES DE AGING
     agingClass(3)  → 'aging-ok'
     agingClass(10) → 'aging-warn'
     agingClass(15) → 'aging-crit'
  ================================================================ */
  function agingClass(days) {
    const d = Number(days);
    const ok   = window.THRESHOLDS?.aging?.ok   ?? 5;
    const warn = window.THRESHOLDS?.aging?.warn  ?? 12;
    if (d <= ok)   return 'aging-ok';
    if (d <= warn) return 'aging-warn';
    return 'aging-crit';
  }


  /* ================================================================
     6. ANIMADOR DE CONTADORES
     Anima un número desde 0 hasta `target` en `duration` ms.
     counter(el, 1500000, 1200, 'currency')
     Formatos: 'currency' | 'percent' | 'integer' | 'decimal'
  ================================================================ */
  function counter(el, target, duration = 900, format = 'integer') {
    if (!el) return;
    const start     = performance.now();
    const numTarget = Number(target);

    function step(now) {
      const elapsed  = now - start;
      const progress = Math.min(elapsed / duration, 1);
      /* Easing out-expo para desaceleración natural */
      const eased    = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current  = numTarget * eased;

      switch (format) {
        case 'currency': el.textContent = formatCurrency(current, true);  break;
        case 'percent':  el.textContent = current.toFixed(1) + '%';       break;
        case 'decimal':  el.textContent = current.toFixed(1);             break;
        default:         el.textContent = formatNumber(Math.round(current));
      }

      if (progress < 1) requestAnimationFrame(step);
      else {
        /* Valor final exacto */
        switch (format) {
          case 'currency': el.textContent = formatCurrency(numTarget, true); break;
          case 'percent':  el.textContent = numTarget.toFixed(1) + '%';      break;
          case 'decimal':  el.textContent = numTarget.toFixed(1);            break;
          default:         el.textContent = formatNumber(numTarget);
        }
      }
    }

    requestAnimationFrame(step);
  }


  /* ================================================================
     7. TOAST — Notificaciones temporales
     showToast('Datos cargados', 'success')
     showToast('Error de red',   'danger')
     Tipos: 'success' | 'warning' | 'danger' | 'info'
  ================================================================ */
  const TOAST_ICONS = {
    success : '✓',
    warning : '⚠',
    danger  : '✕',
    info    : 'ℹ',
  };

  function showToast(msg, type = 'info', duration = 3500) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id        = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span style="font-size:0.85rem;font-weight:700;flex-shrink:0">
        ${TOAST_ICONS[type] ?? TOAST_ICONS.info}
      </span>
      <span>${msg}</span>
    `;
    container.appendChild(toast);

    /* Auto-dismiss */
    setTimeout(() => {
      toast.style.cssText = 'opacity:0;transform:translateX(16px);transition:all .3s ease';
      setTimeout(() => toast.remove(), 320);
    }, duration);
  }


  /* ================================================================
     8. TRUNCAR TEXTO
     truncate('Nombre muy largo de campaña', 24) → "Nombre muy largo de cam…"
  ================================================================ */
  function truncate(str, max = 32) {
    if (!str) return '';
    return str.length > max ? str.slice(0, max - 1) + '…' : str;
  }


  /* ================================================================
     9. INICIALES
     initials('Carlos Martínez') → 'CM'
     initials('Pedro')           → 'PE'
  ================================================================ */
  function initials(name = '') {
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  }


  /* ================================================================
    10. COLOR DE AVATAR
    Asigna un color de avatar consistente según el nombre.
    avatarColor('Carlos') → 'av-blue'
  ================================================================ */
  const AVATAR_COLORS = ['av-blue','av-green','av-purple','av-orange','av-teal','av-pink','av-red'];

  function avatarColor(name = '') {
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash += name.charCodeAt(i);
    return AVATAR_COLORS[hash % AVATAR_COLORS.length];
  }


  /* ================================================================
    11. PORCENTAJE SEGURO
    Evita divisiones por cero.
    safePct(45, 200) → 22.5
    safePct(45, 0)   → 0
  ================================================================ */
  function safePct(value, total) {
    if (!total || isNaN(total) || isNaN(value)) return 0;
    return Math.min((value / total) * 100, 100);
  }


  /* ================================================================
    12. CLAMP
    Limita un valor entre min y max.
    clamp(120, 0, 100) → 100
  ================================================================ */
  function clamp(value, min, max) {
    return Math.min(Math.max(Number(value), min), max);
  }


  /* ── Exponer API pública ────────────────────────────────────── */
  return {
    formatCurrency,
    formatNumber,
    formatDate,
    scoreClass,
    agingClass,
    counter,
    showToast,
    truncate,
    initials,
    avatarColor,
    safePct,
    clamp,
  };

})();

/* Exponer globalmente para que todos los scripts puedan usarlo */
window.Utils = Utils;