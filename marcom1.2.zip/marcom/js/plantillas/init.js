/* ================================================================
   plantillas-init.js — Módulo Plantillas de Correo MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Persistencia: localStorage('marcom-plantillas')
   Al crear/editar/eliminar → se guarda en localStorage
   ================================================================ */
'use strict';

const TIPOS = ['Generación de Leads','Promocional / Ventas','Nutrición (Nurturing)','Re-engagement','Branding / Reconocimiento'];
const VARIABLES_SUGERIDAS = ['{{nombre}}','{{empresa}}','{{cargo}}','{{responsable}}','{{descuento}}','{{fecha_limite}}','{{fecha_demo}}','{{meses_inactivo}}','{{beneficio}}'];

const TIPO_COLORS = {
  'Generación de Leads'     : { badge:'badge-accent',   color:'var(--accent)'  },
  'Promocional / Ventas'    : { badge:'badge-warning',  color:'var(--warning)' },
  'Nutrición (Nurturing)'   : { badge:'badge-info',     color:'var(--info)'    },
  'Re-engagement'           : { badge:'badge-success',  color:'var(--success)' },
  'Branding / Reconocimiento':{ badge:'badge-neutral',  color:'var(--text-muted)'},
};

/* ── Estado ──────────────────────────────────────────────────── */
let PLANTILLAS   = [];
let editingId    = null; /* null = nueva, string = editando */
let previewMode  = false;

function save() {
  localStorage.setItem('marcom-plantillas', JSON.stringify(PLANTILLAS));
}

function load() {
  try {
    const stored = localStorage.getItem('marcom-plantillas');
    if (stored) return JSON.parse(stored);
  } catch {}
  return null;
}

/* ── Helpers ─────────────────────────────────────────────────── */
function fmtDate(s) {
  if (!s) return '—';
  return new Date(s+'T00:00:00').toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
}
function now() { return new Date().toISOString().slice(0,10); }

/* ── Sidebar ─────────────────────────────────────────────────── */
function buildNav() {
  const nav = document.getElementById('sb-nav');
  if (!nav || typeof NAV_ITEMS==='undefined') return;
  nav.innerHTML = '';
  let section = null;
  const page = 'campanas.html'; /* plantillas = sub de campañas en nav */
  NAV_ITEMS.forEach(item => {
    if (item.section !== section) {
      section = item.section;
      if (item.section) {
        const lbl = document.createElement('div');
        lbl.className = 'sb-section-label';
        lbl.textContent = item.section;
        nav.appendChild(lbl);
      }
    }
    const active = page === item.url;
    const iconSvg = (typeof ICONS!=='undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
    const a = document.createElement('a');
    a.className = `sb-item${active?' active':''}`;
    a.href = item.url;
    a.innerHTML = `<span class="sb-item-icon">${iconSvg}</span><span class="sb-item-label">${item.label}</span>`;
    nav.appendChild(a);
  });
}

/* ── Render grid de plantillas ───────────────────────────────── */
function renderGrid() {
  const grid    = document.getElementById('plantillas-grid');
  const counter = document.getElementById('pl-count');
  if (!grid) return;
  if (counter) counter.textContent = PLANTILLAS.length;

  if (!PLANTILLAS.length) {
    grid.innerHTML = `
      <div class="pl-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
        </svg>
        <p>No hay plantillas creadas aún.</p>
        <button class="btn-primary" onclick="openModal()">Crear primera plantilla</button>
      </div>`;
    return;
  }

  grid.innerHTML = PLANTILLAS.map(p => {
    const tc = TIPO_COLORS[p.tipo] ?? TIPO_COLORS['Branding / Reconocimiento'];
    const preview = p.cuerpoHtml
      ? p.cuerpoHtml.replace(/<[^>]+>/g,'').slice(0,110).trim() + '...'
      : '(Sin contenido)';
    return `
      <div class="pl-card" data-id="${p.id}">
        <div class="plc-header">
          <div class="plc-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
              <polyline points="22,6 12,13 2,6"/>
            </svg>
          </div>
          <div class="plc-actions">
            <button class="plc-btn" data-action="preview" data-id="${p.id}" title="Vista previa">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
            <button class="plc-btn" data-action="edit" data-id="${p.id}" title="Editar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="plc-btn plc-btn-danger" data-action="delete" data-id="${p.id}" title="Eliminar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
            </button>
          </div>
        </div>
        <div class="plc-body">
          <div class="plc-nombre">${p.nombre}</div>
          <div class="plc-asunto">${p.asunto}</div>
          <div class="plc-preview">${preview}</div>
        </div>
        <div class="plc-footer">
          <span class="badge ${tc.badge}" style="font-size:.68rem">${p.tipo}</span>
          <span class="plc-meta">${p.veces ?? 0} uso${(p.veces??0)!==1?'s':''} · ${fmtDate(p.creadoEn)}</span>
        </div>
        <div class="plc-vars">
          ${(p.variables ?? []).map(v => `<span class="var-chip">${v}</span>`).join('')}
        </div>
      </div>`;
  }).join('');

  /* Bind acciones */
  grid.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const { action, id } = btn.dataset;
      if (action === 'edit')    openModal(id);
      if (action === 'delete')  deletePlantilla(id);
      if (action === 'preview') openPreview(id);
    });
  });
}

/* ── Modal crear / editar ────────────────────────────────────── */
function openModal(id = null) {
  editingId = id;
  const modal = document.getElementById('modal-plantilla');
  const title = document.getElementById('mp-title');

  /* Llenar campos */
  if (id) {
    const p = PLANTILLAS.find(x => x.id === id);
    if (!p) return;
    title.textContent = 'Editar Plantilla';
    document.getElementById('mp-nombre').value   = p.nombre;
    document.getElementById('mp-tipo').value     = p.tipo;
    document.getElementById('mp-asunto').value   = p.asunto;
    document.getElementById('mp-cuerpo').value   = p.cuerpoHtml ?? '';
    document.getElementById('mp-vars').value     = (p.variables ?? []).join(', ');
  } else {
    title.textContent = 'Nueva Plantilla';
    document.getElementById('mp-nombre').value  = '';
    document.getElementById('mp-tipo').value    = TIPOS[0];
    document.getElementById('mp-asunto').value  = '';
    document.getElementById('mp-cuerpo').value  = '';
    document.getElementById('mp-vars').value    = '{{nombre}}, {{empresa}}';
  }

  previewMode = false;
  showEditorTab();
  modal?.classList.add('modal-show');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modal-plantilla')?.classList.remove('modal-show');
  document.body.style.overflow = '';
  editingId = null;
}

function guardarPlantilla() {
  const nombre = document.getElementById('mp-nombre')?.value.trim();
  const asunto = document.getElementById('mp-asunto')?.value.trim();
  const cuerpo = document.getElementById('mp-cuerpo')?.value.trim();
  const tipo   = document.getElementById('mp-tipo')?.value ?? TIPOS[0];
  const varsRaw= document.getElementById('mp-vars')?.value ?? '';
  const vars   = varsRaw.split(',').map(v=>v.trim()).filter(Boolean);

  if (!nombre) { if(typeof Utils!=='undefined') Utils.showToast('El nombre es obligatorio','warning'); return; }
  if (!asunto) { if(typeof Utils!=='undefined') Utils.showToast('El asunto es obligatorio','warning'); return; }
  if (!cuerpo) { if(typeof Utils!=='undefined') Utils.showToast('El cuerpo del correo es obligatorio','warning'); return; }

  if (editingId) {
    /* Editar */
    const idx = PLANTILLAS.findIndex(p => p.id === editingId);
    if (idx >= 0) {
      PLANTILLAS[idx] = { ...PLANTILLAS[idx], nombre, asunto, cuerpoHtml:cuerpo, tipo, variables:vars };
    }
    if(typeof Utils!=='undefined') Utils.showToast(`Plantilla "${nombre}" actualizada`,'success');
  } else {
    /* Nueva */
    PLANTILLAS.unshift({
      id         : 'pl' + Date.now(),
      nombre, tipo, asunto,
      variables  : vars,
      creadoPor  : 'Usuario actual',
      creadoEn   : now(),
      ultimoUso  : null,
      veces      : 0,
      cuerpoHtml : cuerpo,
    });
    if(typeof Utils!=='undefined') Utils.showToast(`Plantilla "${nombre}" creada`,'success');
  }

  save();
  renderGrid();
  closeModal();
}

function deletePlantilla(id) {
  const p = PLANTILLAS.find(x => x.id === id);
  if (!p) return;
  if (!confirm(`¿Eliminar la plantilla "${p.nombre}"?`)) return;
  PLANTILLAS = PLANTILLAS.filter(x => x.id !== id);
  save();
  renderGrid();
  if(typeof Utils!=='undefined') Utils.showToast('Plantilla eliminada','info');
}

/* ── Preview del correo ──────────────────────────────────────── */
function openPreview(id) {
  const p = PLANTILLAS.find(x => x.id === id);
  if (!p) return;

  /* Abrir modal de preview */
  const modal = document.getElementById('modal-preview');
  const frame = document.getElementById('preview-frame');
  const pnombre = document.getElementById('pv-nombre');
  const pasunto  = document.getElementById('pv-asunto');

  if (pnombre) pnombre.textContent = p.nombre;
  if (pasunto)  pasunto.textContent = `Asunto: ${p.asunto}`;

  /* Reemplazar variables con datos de ejemplo */
  let html = p.cuerpoHtml ?? '<p>(Sin contenido)</p>';
  const ejemplos = {
    '{{nombre}}'        : 'Juan Pérez',
    '{{empresa}}'       : 'TechCorp S.A.',
    '{{cargo}}'         : 'Gerente Comercial',
    '{{responsable}}'   : 'Ana Torres',
    '{{descuento}}'     : '30%',
    '{{fecha_limite}}'  : '31 de marzo',
    '{{fecha_demo}}'    : 'Martes 12 de marzo, 10am',
    '{{meses_inactivo}}': '6',
    '{{beneficio}}'     : 'aumentar sus ventas en un 40%',
  };
  Object.entries(ejemplos).forEach(([k,v]) => {
    html = html.replaceAll(k, `<mark style="background:#fef08a;padding:0 2px;border-radius:2px">${v}</mark>`);
  });

  if (frame) frame.srcdoc = html;
  modal?.classList.add('modal-show');
  document.body.style.overflow = 'hidden';
}

function closePreview() {
  document.getElementById('modal-preview')?.classList.remove('modal-show');
  document.body.style.overflow = '';
}

/* ── Tabs editor / preview en modal ─────────────────────────── */
function showEditorTab() {
  document.getElementById('mp-tab-editor')?.classList.add('mp-tab-active');
  document.getElementById('mp-tab-preview')?.classList.remove('mp-tab-active');
  document.getElementById('mp-editor-content')?.style.setProperty('display','block');
  document.getElementById('mp-preview-content')?.style.setProperty('display','none');
  previewMode = false;
}
function showPreviewTab() {
  document.getElementById('mp-tab-editor')?.classList.remove('mp-tab-active');
  document.getElementById('mp-tab-preview')?.classList.add('mp-tab-active');
  document.getElementById('mp-editor-content')?.style.setProperty('display','none');
  document.getElementById('mp-preview-content')?.style.setProperty('display','block');
  previewMode = true;

  /* Render preview inline */
  const cuerpo = document.getElementById('mp-cuerpo')?.value ?? '';
  const frame  = document.getElementById('mp-inline-frame');
  if (frame) {
    let html = cuerpo;
    const ejemplos = {
      '{{nombre}}':'Juan Pérez','{{empresa}}':'TechCorp','{{cargo}}':'Gerente',
      '{{descuento}}':'30%','{{fecha_limite}}':'31 Mar','{{responsable}}':'Ana Torres',
      '{{fecha_demo}}':'12 Mar 10am','{{meses_inactivo}}':'6','{{beneficio}}':'crecer un 40%',
    };
    Object.entries(ejemplos).forEach(([k,v]) => {
      html = html.replaceAll(k,`<mark style="background:#fef08a;padding:0 2px;border-radius:2px">${v}</mark>`);
    });
    frame.srcdoc = html || '<p style="padding:20px;color:#888;font-family:sans-serif">Escribe HTML en el editor para ver la vista previa.</p>';
  }
}

/* ── Variables sugeridas ─────────────────────────────────────── */
function insertarVariable(v) {
  const ta = document.getElementById('mp-cuerpo');
  if (!ta) return;
  const pos = ta.selectionStart;
  const val = ta.value;
  ta.value  = val.slice(0,pos) + v + val.slice(pos);
  ta.focus();
  ta.selectionStart = ta.selectionEnd = pos + v.length;
}

/* ════════════════════════════════════════════════════════════════
   INIT PRINCIPAL
════════════════════════════════════════════════════════════════ */
window.addEventListener('load', async () => {

  if (typeof Auth !== 'undefined') {
    const user = Auth.initProtectedPage();
    if (!user) return;
  }

  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) dateBadge.textContent = new Date().toLocaleDateString('es-CO',{
    weekday:'short',day:'numeric',month:'short',year:'numeric'
  });

  /* Cargar plantillas */
  const fromStorage = load();
  if (fromStorage) {
    PLANTILLAS = fromStorage;
  } else {
    try {
      const res = await fetch('../data/plantillas.json',{cache:'no-store'});
      PLANTILLAS = res.ok ? await res.json() : [];
      save();
    } catch { PLANTILLAS = []; }
  }

  buildNav();
  renderGrid();

  /* Variables sugeridas chips */
  const varsWrap = document.getElementById('vars-sugeridas');
  if (varsWrap) {
    varsWrap.innerHTML = VARIABLES_SUGERIDAS.map(v =>
      `<button class="var-chip var-chip-btn" data-var="${v}">${v}</button>`
    ).join('');
    varsWrap.querySelectorAll('[data-var]').forEach(btn => {
      btn.addEventListener('click', () => insertarVariable(btn.dataset.var));
    });
  }

  /* Botón nueva plantilla */
  document.getElementById('btn-nueva-plantilla')?.addEventListener('click', () => openModal());

  /* Modal plantilla */
  document.getElementById('mp-close')?.addEventListener('click',    closeModal);
  document.getElementById('mp-cancel')?.addEventListener('click',   closeModal);
  document.getElementById('mp-guardar')?.addEventListener('click',  guardarPlantilla);
  document.getElementById('mp-tab-editor')?.addEventListener('click',  showEditorTab);
  document.getElementById('mp-tab-preview')?.addEventListener('click', showPreviewTab);
  document.getElementById('modal-plantilla')?.addEventListener('click', e => {
    if (e.target.id === 'modal-plantilla') closeModal();
  });

  /* Modal preview */
  document.getElementById('pv-close')?.addEventListener('click',  closePreview);
  document.getElementById('modal-preview')?.addEventListener('click', e => {
    if (e.target.id === 'modal-preview') closePreview();
  });

  /* Globales */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark==='function') toggleDark();
  });
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils!=='undefined') Utils.showToast('Sin notificaciones nuevas','info');
  });
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    if (typeof Auth!=='undefined') Auth.logout();
  });

  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const sbOv    = document.getElementById('sb-overlay');
  mobBtn?.addEventListener('click',  () => { sidebar?.classList.toggle('sidebar-open'); sbOv?.classList.toggle('overlay-show'); });
  sbOv?.addEventListener('click',    () => { sidebar?.classList.remove('sidebar-open'); sbOv?.classList.remove('overlay-show'); });
});