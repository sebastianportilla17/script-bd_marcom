/* ================================================================
   campanas-init.js — Módulo Campañas MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0
   ================================================================ */
'use strict';

/* ── Helpers ─────────────────────────────────────────────────── */
function fmt$(v) {
  if (v === null || v === undefined || v === 0) return '$0';
  if (Math.abs(v) >= 1e9) return `$${(v/1e9).toFixed(1)}B`;
  if (Math.abs(v) >= 1e6) return `$${(v/1e6).toFixed(0)}M`;
  if (Math.abs(v) >= 1e3) return `$${(v/1e3).toFixed(0)}K`;
  return '$' + Math.round(v).toLocaleString('es-CO');
}
function fmtDate(s, style='short') {
  if (!s) return '—';
  const d = new Date(s+'T00:00:00');
  if (style === 'short') return d.toLocaleDateString('es-CO',{day:'2-digit',month:'short'});
  return d.toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
}
function animCounter(el, target, suffix='', dur=900) {
  if (!el || isNaN(target)) return;
  const start = performance.now();
  const step = now => {
    const p = Math.min((now-start)/dur,1);
    const e = 1-Math.pow(2,-10*p);
    const v = target*e;
    el.textContent = (target % 1 !== 0 ? v.toFixed(1) : Math.round(v).toLocaleString('es-CO')) + suffix;
    if (p<1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
function roiClass(roi) {
  if (roi >= 150) return 'roi-high';
  if (roi >= 50)  return 'roi-mid';
  if (roi > 0)    return 'roi-low';
  return 'roi-na';
}

/* ── Tipo → icono + clase ────────────────────────────────────── */
const TIPO_MAP = {
  'Generación de Leads'     : { cls:'cti-gen',   emoji:'🎯', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>` },
  'Promocional / Ventas'    : { cls:'cti-promo',  emoji:'🔥', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2c0 0-4 4-4 8a4 4 0 0 0 8 0c0-4-4-8-4-8z"/></svg>` },
  'Nutrición (Nurturing)'   : { cls:'cti-nur',   emoji:'💧', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>` },
  'Re-engagement'           : { cls:'cti-re',    emoji:'💙', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.5"/></svg>` },
  'Branding / Reconocimiento':{ cls:'cti-brand', emoji:'⭐', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>` },
};

/* ── Estado ──────────────────────────────────────────────────── */
let DATA        = null;
let PLANTILLAS  = [];
let filtered    = [];
let activeDrawer = null;

/* ── Sidebar ─────────────────────────────────────────────────── */
function buildNav() {
  const nav = document.getElementById('sb-nav');
  if (!nav || typeof NAV_ITEMS==='undefined') return;
  nav.innerHTML = '';
  let section = null;
  const page = location.pathname.split('/').pop() || 'index.html';
  NAV_ITEMS.forEach(item => {
    if (item.section !== section) {
      section = item.section;
      if (item.section) {
        const lbl = document.createElement('div');
        lbl.className = 'sb-section-label';
        lbl.textContent = item.section;
        nav.appendChild(lbl);
      }
    }
    const active = page === item.url;
    const iconSvg = (typeof ICONS!=='undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
    const a = document.createElement('a');
    a.className = `sb-item${active?' active':''}`;
    a.href = item.url;
    a.innerHTML = `<span class="sb-item-icon">${iconSvg}</span><span class="sb-item-label">${item.label}</span>`;
    nav.appendChild(a);
  });
}

/* ── KPIs ────────────────────────────────────────────────────── */
function renderKPIs(r) {
  const grid = document.getElementById('kpis-row');
  if (!grid) return;
  const items = [
    { id:'kpi-total',  val:r.totalCampanas, suf:'',  label:'Total Campañas',    color:'blue',   trend:'+3 este mes', trendCls:'kct-up',  icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>` },
    { id:'kpi-activas',val:r.activas,       suf:'',  label:'Campañas Activas',  color:'green',  trend:'En ejecución', trendCls:'kct-info',icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>` },
    { id:'kpi-leads',  val:r.leadsTotal,    suf:'',  label:'Leads Generados',   color:'purple', trend:'+18% vs mes ant', trendCls:'kct-up', icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>` },
    { id:'kpi-roi',    val:r.roiPromedio,   suf:'%', label:'ROI Promedio',       color:'orange', trend:'Meta 150%',    trendCls:'kct-info',icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>` },
  ];
  const colorMap = { blue:'kc-blue', green:'kc-green', purple:'kc-purple', orange:'kc-orange' };
  const iconMap  = { blue:'kci-blue', green:'kci-green', purple:'kci-purple', orange:'kci-orange' };

  grid.innerHTML = '';
  items.forEach((k,i) => {
    const card = document.createElement('div');
    card.className = `kpi-card ${colorMap[k.color]} anim anim-${i+1}`;
    card.innerHTML = `
      <div class="kpi-card-top">
        <div class="kc-icon ${iconMap[k.color]}">${k.icon}</div>
        <span class="kc-trend ${k.trendCls}">${k.trend}</span>
      </div>
      <div class="kc-value" id="${k.id}">${k.val}${k.suf}</div>
      <div class="kc-label">${k.label}</div>`;
    grid.appendChild(card);
    requestAnimationFrame(() => {
      const el = document.getElementById(k.id);
      if (el) animCounter(el, k.val, k.suf);
    });
  });
}

/* ── Tabla campañas ──────────────────────────────────────────── */
function renderTabla(campanas) {
  const tbody   = document.getElementById('camp-tbody');
  const counter = document.getElementById('tc-count');
  if (!tbody) return;
  if (counter) counter.textContent = campanas.length;

  if (!campanas.length) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:40px;color:var(--text-muted)">Sin campañas que coincidan</td></tr>`;
    return;
  }

  tbody.innerHTML = campanas.map(c => {
    const tipo = TIPO_MAP[c.tipo] ?? TIPO_MAP['Branding / Reconocimiento'];
    const estadoBadge = estadoHTML(c.estado);
    const roiC = roiClass(c.roi);
    const roiStr = c.roi > 0 ? `${c.roi}%` : '—';

    return `
      <tr data-id="${c.id}">
        <td>
          <div class="camp-name-cell">
            <div class="camp-tipo-icon ${tipo.cls}">${tipo.svg}</div>
            <div>
              <div class="camp-name">${c.nombre}</div>
              <div class="camp-seg">${c.tipo}</div>
            </div>
          </div>
        </td>
        <td><span class="badge badge-neutral" style="font-size:.70rem">${c.canal}</span></td>
        <td>${estadoBadge}</td>
        <td class="mono-val">${c.leads.toLocaleString('es-CO')}</td>
        <td class="mono-val">${c.conversiones.toLocaleString('es-CO')}</td>
        <td><span class="${roiC}">${roiStr}</span></td>
        <td class="t-sm t-muted">${fmtDate(c.inicio)}</td>
        <td class="t-sm t-muted">${fmtDate(c.fin)}</td>
        <td class="t-sm t-second">${c.responsable}</td>
      </tr>`;
  }).join('');

  tbody.querySelectorAll('tr[data-id]').forEach(row => {
    row.addEventListener('click', () => {
      const camp = campanas.find(c => c.id === row.dataset.id);
      if (camp) openDrawer(camp);
    });
  });
}

function estadoHTML(estado) {
  const map = {
    'Activa'    : 'badge-success',
    'Pausada'   : 'badge-warning',
    'Borrador'  : 'badge-neutral',
    'Finalizada': 'badge-neutral',
  };
  return `<span class="badge ${map[estado] ?? 'badge-neutral'}">${estado}</span>`;
}

/* ── Drawer ──────────────────────────────────────────────────── */
function openDrawer(c) {
  activeDrawer = c;
  const drawer  = document.getElementById('camp-drawer');
  const overlay = document.getElementById('drawer-overlay');

  /* Header */
  document.getElementById('cd-nombre').textContent = c.nombre;
  const badges = document.getElementById('cd-badges');
  const tipo = TIPO_MAP[c.tipo] ?? TIPO_MAP['Branding / Reconocimiento'];
  badges.innerHTML = `
    ${estadoHTML(c.estado)}
    <span class="badge badge-accent" style="font-size:.70rem">${tipo.emoji} ${c.tipo}</span>
    <span class="badge badge-neutral" style="font-size:.70rem">${c.canal}</span>`;

  /* KPIs */
  const kpisEl = document.getElementById('cd-kpis');
  kpisEl.innerHTML = `
    <div class="cd-kpi">
      <div class="cd-kpi-val ckv-blue">${c.leads.toLocaleString('es-CO')}</div>
      <div class="cd-kpi-lbl">Leads generados</div>
    </div>
    <div class="cd-kpi">
      <div class="cd-kpi-val ckv-purple">${c.conversiones.toLocaleString('es-CO')}</div>
      <div class="cd-kpi-lbl">Conversiones</div>
    </div>
    <div class="cd-kpi">
      <div class="cd-kpi-val ${c.roi>=150?'ckv-green':c.roi>=50?'ckv-orange':''}">${c.roi > 0 ? c.roi+'%' : '—'}</div>
      <div class="cd-kpi-lbl">ROI</div>
    </div>
    <div class="cd-kpi">
      <div class="cd-kpi-val">${c.costoPorLead > 0 ? fmt$(c.costoPorLead) : '—'}</div>
      <div class="cd-kpi-lbl">Costo por lead</div>
    </div>`;

  /* Gráfica */
  renderChart(c.rendimiento);

  /* Presupuesto */
  const pct = c.presupuesto > 0 ? Math.round((c.gastoActual/c.presupuesto)*100) : 0;
  const presupEl = document.getElementById('cd-presupuesto');
  presupEl.innerHTML = `
    <div class="cp-row">
      <span class="cp-label">Presupuesto total</span>
      <span class="cp-val">${fmt$(c.presupuesto)}</span>
    </div>
    <div class="cp-row">
      <span class="cp-label">Gasto actual</span>
      <span class="cp-val" style="color:var(--accent)">${fmt$(c.gastoActual)}</span>
    </div>
    <div class="cp-bar-wrap">
      <div class="cp-bar-fill" style="width:${pct}%"></div>
    </div>
    <div class="cp-pct">${pct}% utilizado</div>`;

  /* Plantilla */
  const plantEl = document.getElementById('cd-plantilla');
  if (c.plantillaNombre) {
    plantEl.innerHTML = `
      <div class="cd-plantilla-preview">
        <div class="cpp-nombre">📧 ${c.plantillaNombre}</div>
        <div class="cpp-text">${c.plantillaPreview ?? ''}</div>
      </div>
      <a href="plantillas.html" class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;gap:6px">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        Ver plantilla completa
      </a>`;
  } else {
    plantEl.innerHTML = `<p class="cpp-empty">Sin plantilla asociada a esta campaña.</p>`;
  }

  /* Leads recientes */
  const leadsEl = document.getElementById('cd-leads');
  if (c.leadsRecientes?.length) {
    leadsEl.innerHTML = `
      <div class="cd-leads-list">
        ${c.leadsRecientes.map(l => `
          <div class="cd-lead-item">
            <div class="avatar av-blue" style="width:30px;height:30px;font-size:.72rem">${l.nombre.split(' ').map(p=>p[0]).join('').slice(0,2).toUpperCase()}</div>
            <div class="cd-lead-info">
              <div class="cd-lead-name">${l.nombre}</div>
              <div class="cd-lead-emp">${l.empresa}</div>
            </div>
            <div class="cd-lead-fecha">${fmtDate(l.fecha)}</div>
          </div>`).join('')}
      </div>
      <div style="margin-top:12px">
        <a href="leads.html" class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;gap:6px">
          Ver todos los leads →
        </a>
      </div>`;
  } else {
    leadsEl.innerHTML = `<p style="color:var(--text-muted);font-size:.82rem">Sin leads registrados aún.</p>`;
  }

  drawer?.classList.add('drawer-open');
  overlay?.classList.add('drawer-overlay-show');
  document.body.style.overflow = 'hidden';
}

function closeDrawer() {
  document.getElementById('camp-drawer')?.classList.remove('drawer-open');
  document.getElementById('drawer-overlay')?.classList.remove('drawer-overlay-show');
  document.body.style.overflow = '';
  activeDrawer = null;
}

function renderChart(rendimiento) {
  const el = document.getElementById('cd-chart');
  if (!el) return;
  if (!rendimiento?.length) {
    el.innerHTML = `<p style="color:var(--text-muted);font-size:.78rem">Sin datos de rendimiento aún.</p>`;
    return;
  }
  const max = Math.max(...rendimiento.map(r=>r.leads));
  el.innerHTML = rendimiento.map(r => `
    <div class="cc-row">
      <span class="cc-label">${fmtDate(r.fecha)}</span>
      <div class="cc-bar-wrap">
        <div class="cc-bar-fill" style="width:${max>0?(r.leads/max*100):0}%"></div>
      </div>
      <span class="cc-val">${r.leads}</span>
    </div>`).join('');
}

/* ── Filtros ─────────────────────────────────────────────────── */
function applyFilters() {
  const canal  = document.getElementById('f-canal')?.value   ?? 'Todos';
  const estado = document.getElementById('f-estado')?.value  ?? 'Todos';
  const resp   = document.getElementById('f-resp')?.value    ?? 'Todos';

  filtered = DATA.campanas.filter(c => {
    if (canal  !== 'Todos' && c.canal       !== canal)  return false;
    if (estado !== 'Todos' && c.estado      !== estado) return false;
    if (resp   !== 'Todos' && c.responsable !== resp)   return false;
    return true;
  });
  renderTabla(filtered);
}

function populateFiltros(filtros) {
  const addOpts = (id, arr) => {
    const sel = document.getElementById(id);
    if (!sel) return;
    arr.forEach(v => { const o=document.createElement('option'); o.value=v; o.textContent=v; sel.appendChild(o); });
  };
  addOpts('f-canal',   filtros.canales);
  addOpts('f-estado',  filtros.estados);
  addOpts('f-resp',    filtros.responsables);
  addOpts('f-periodo', filtros.periodos);
}

/* ── Modal nueva campaña ─────────────────────────────────────── */
function openModal() {
  const modal = document.getElementById('modal-nueva');
  if (!modal) return;

  /* Llenar select de plantillas */
  const selPlant = document.getElementById('m-plantilla');
  if (selPlant) {
    selPlant.innerHTML = '<option value="">Sin plantilla</option>';
    PLANTILLAS.forEach(p => {
      const o = document.createElement('option');
      o.value = p.id; o.textContent = p.nombre;
      selPlant.appendChild(o);
    });
  }
  modal.classList.add('modal-show');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modal-nueva')?.classList.remove('modal-show');
  document.body.style.overflow = '';
}

function guardarCampana() {
  const nombre = document.getElementById('m-nombre')?.value.trim();
  if (!nombre) { if(typeof Utils!=='undefined') Utils.showToast('El nombre es obligatorio','warning'); return; }

  const tipo      = document.getElementById('m-tipo')?.value    ?? '';
  const canal     = document.getElementById('m-canal')?.value   ?? '';
  const inicio    = document.getElementById('m-inicio')?.value  ?? '';
  const fin       = document.getElementById('m-fin')?.value     ?? '';
  const resp      = document.getElementById('m-resp')?.value    ?? '';
  const presup    = parseInt(document.getElementById('m-presupuesto')?.value) || 0;
  const plantId   = document.getElementById('m-plantilla')?.value ?? null;
  const plant     = PLANTILLAS.find(p => p.id === plantId);

  const nueva = {
    id              : 'camp' + Date.now(),
    nombre,
    tipo,
    canal,
    estado          : 'Borrador',
    leads           : 0,
    conversiones    : 0,
    roi             : 0,
    costoPorLead    : 0,
    presupuesto     : presup,
    gastoActual     : 0,
    inicio,
    fin,
    responsable     : resp,
    segmento        : '',
    plantillaId     : plantId || null,
    plantillaNombre : plant?.nombre ?? null,
    plantillaPreview: plant?.cuerpoHtml ? plant.cuerpoHtml.replace(/<[^>]+>/g,'').slice(0,120)+'...' : null,
    rendimiento     : [],
    leadsRecientes  : [],
  };

  DATA.campanas.unshift(nueva);
  DATA.resumen.totalCampanas++;
  applyFilters();
  closeModal();
  if(typeof Utils!=='undefined') Utils.showToast(`Campaña "${nombre}" creada en Borrador`, 'success');

  /* Limpiar form */
  ['m-nombre','m-inicio','m-fin','m-presupuesto'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
}

/* ════════════════════════════════════════════════════════════════
   INIT PRINCIPAL
════════════════════════════════════════════════════════════════ */
window.addEventListener('load', async () => {

  if (typeof Auth !== 'undefined') {
    const user = Auth.initProtectedPage();
    if (!user) return;
  }

  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) dateBadge.textContent = new Date().toLocaleDateString('es-CO',{
    weekday:'short',day:'numeric',month:'short',year:'numeric'
  });

  /* Cargar campañas */
  try {
    const res = await fetch('../data/campanas.json',{cache:'no-store'});
    DATA = res.ok ? await res.json() : null;
  } catch { DATA = null; }

  if (!DATA) {
    document.getElementById('main-content').innerHTML =
      '<p style="padding:40px;color:var(--text-muted)">Error cargando datos de campañas.</p>';
    return;
  }

  /* Cargar plantillas (localStorage → JSON fallback) */
  try {
    const stored = localStorage.getItem('marcom-plantillas');
    if (stored) {
      PLANTILLAS = JSON.parse(stored);
    } else {
      const res = await fetch('../data/plantillas.json',{cache:'no-store'});
      PLANTILLAS = res.ok ? await res.json() : [];
      localStorage.setItem('marcom-plantillas', JSON.stringify(PLANTILLAS));
    }
  } catch { PLANTILLAS = []; }

  buildNav();
  renderKPIs(DATA.resumen);
  populateFiltros(DATA.filtros);
  filtered = [...DATA.campanas];
  renderTabla(filtered);

  /* Filtros */
  ['f-canal','f-estado','f-resp','f-periodo'].forEach(id =>
    document.getElementById(id)?.addEventListener('change', applyFilters));

  /* Botón nueva campaña */
  document.getElementById('btn-nueva')?.addEventListener('click', openModal);
  document.getElementById('modal-close')?.addEventListener('click', closeModal);
  document.getElementById('modal-cancel')?.addEventListener('click', closeModal);
  document.getElementById('modal-guardar')?.addEventListener('click', guardarCampana);
  document.getElementById('modal-nueva')?.addEventListener('click', e => {
    if (e.target.id === 'modal-nueva') closeModal();
  });

  /* Drawer */
  document.getElementById('cd-close')?.addEventListener('click', closeDrawer);
  document.getElementById('drawer-overlay')?.addEventListener('click', closeDrawer);

  /* Globales */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark==='function') toggleDark();
  });
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils!=='undefined') Utils.showToast('Sin notificaciones nuevas','info');
  });
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    if (typeof Auth!=='undefined') Auth.logout();
  });

  /* Sidebar móvil */
  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const sbOv    = document.getElementById('sb-overlay');
  mobBtn?.addEventListener('click',  () => { sidebar?.classList.toggle('sidebar-open'); sbOv?.classList.toggle('overlay-show'); });
  sbOv?.addEventListener('click',    () => { sidebar?.classList.remove('sidebar-open'); sbOv?.classList.remove('overlay-show'); });

  setTimeout(() => {
    if (typeof Utils!=='undefined')
      Utils.showToast(`${DATA.resumen.activas} campañas activas en curso`, 'success', 2500);
  }, 600);
});