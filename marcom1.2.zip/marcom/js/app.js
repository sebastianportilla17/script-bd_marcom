
// ─────────────────────────────────────────
// VALIDACIONES LOGIN SAF
// ─────────────────────────────────────────

window.addEventListener("DOMContentLoaded", () => {
  // Seleccionar el formulario y los campos de entrada
  const form = document.querySelector("form");
  const userInput = document.getElementById("user-input");
  const passwordInput = document.getElementById("pw-input");

  // Crear mensajes de error dinámicos o usar los existentes si ya los hay
  let userError = userInput.parentElement.querySelector("small");
  let passError = passwordInput.parentElement.querySelector("small");

  if (!userError) {
    userError = document.createElement("small");
    userInput.parentElement.appendChild(userError);
  }
  if (!passError) {
    passError = document.createElement("small");
    passwordInput.parentElement.appendChild(passError);
  }

  userError.style.color = "red";
  passError.style.color = "red";

  // ───── BLOQUEAR ESPACIOS ─────
  userInput.addEventListener("keydown", (e) => {
    if (e.key === " ") e.preventDefault();
  });

  passwordInput.addEventListener("keydown", (e) => {
    if (e.key === " ") e.preventDefault();
  });

  // ───── VALIDACIÓN EN TIEMPO REAL USUARIO ─────
  userInput.addEventListener("input", () => {
    const value = userInput.value;

    // Solo letras, números y @
    const regex = /^[A-Za-z0-9@]*$/;

    // Si hay un caracter inválido lo elimina y muestra error
    if (!regex.test(value)) {
      userError.textContent = "Solo letras, números y @";
      userInput.value = value.replace(/[^A-Za-z0-9@]/g, "");
      return;
    }

    if (value.length < 8 || value.length > 12) {
      userError.textContent = "Debe tener entre 8 y 12 caracteres";
      return;
    }

    userError.textContent = "";
  });

  // ───── VALIDACIÓN EN TIEMPO REAL CONTRASEÑA ─────
  passwordInput.addEventListener("input", () => {
    const value = passwordInput.value;

    // Solo letras y números
    const regex = /^[A-Za-z0-9]*$/;

    if (!regex.test(value)) {
      passError.textContent = "Solo letras y números";
      passwordInput.value = value.replace(/[^A-Za-z0-9]/g, "");
      return;
    }

    if (value.length < 8 || value.length > 12) {
      passError.textContent = "Debe tener entre 8 y 12 caracteres";
      return;
    }

    passError.textContent = "";
  });

  // ───── VALIDACIÓN FINAL AL ENVIAR ─────
  form.addEventListener("submit", function (e) {
      e.preventDefault(); // bloquea envío normal
    let valid = true;

    const userValue = userInput.value.trim();
    const passValue = passwordInput.value.trim();

    // Reiniciar mensajes de error
    userError.textContent = "";
    passError.textContent = "";

    // Validación usuario vacío
    if (userValue === "") {
      userError.textContent = "El usuario no puede estar vacío";
      valid = false;
    }
    // Validación password vacío
    if (passValue === "") {
      passError.textContent = "La contraseña no puede estar vacía";
      valid = false;
    }

    // Validación usuario regex (para submit)
    const userRegex = /^[A-Za-z0-9@]{8,12}$/;
    if (!userRegex.test(userValue)) {
      userError.textContent = "Solo letras, números y @, entre 8 y 12 caracteres";
      valid = false;
    }

    // Validación password regex (para submit)
    const passRegex = /^[A-Za-z0-9]{8,12}$/;
    if (!passRegex.test(passValue)) {
      passError.textContent = "Solo letras y números, entre 8 y 12 caracteres";
      valid = false;
    }

    if (!valid) return;

    // Buscar usuario en las credenciales demo
    Auth.mockAuth(userValue, passValue).then(user => {
      if (user) {
        Auth.createSession(user, false);
        window.location.href = "src/dashboard.html";
      } else {
        userError.textContent = "Usuario o contraseña incorrectos";
      }
    });
  });
});

// ─────────────────────────────────────────
// PASSWORD TOGGLE (tu función mejorada)
// ─────────────────────────────────────────

function togglePw() {
  const input = document.getElementById('pw-input');
  const eye = document.getElementById('pw-eye');
  if (!input || !eye) return;

  if (input.type === 'password') {
    input.type = 'text';
    eye.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
  } else {
    input.type = 'password';
    eye.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
  }
}
