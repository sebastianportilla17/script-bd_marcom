/* ================================================================
   js/leads/init.js — Eventos e Inicialización · Módulo Leads
   Proyecto : ERP ADSO 3171727 · MARCOM
   Versión  : 2.1 · localStorage + Sidebar con íconos

   ¿QUÉ HACE ESTE ARCHIVO?
   ─────────────────────────────────────────────────────────────
   Es el director de orquesta del módulo Leads. Se encarga de:
     1. Verificar que hay sesión activa
     2. Cargar los datos (localStorage → fallback)
     3. Construir el sidebar con íconos
     4. Renderizar el pipeline kanban
     5. Registrar todos los event listeners
     6. Guardar cambios en localStorage automáticamente

   FLUJO DE EJECUCIÓN:
   ┌─────────────────────────────────────────────────────────┐
   │  window load                                            │
   │    → LeadsEvents.init()                                 │
   │        → verificar sesión (Auth)                        │
   │        → cargar datos (getLeadsData)                    │
   │        → sobreescribir con localStorage si existe       │
   │        → construir sidebar (buildNav)                   │
   │        → renderizar pipeline (LeadsRender.buildPipeline)│
   │        → registrar eventos                              │
   └─────────────────────────────────────────────────────────┘

   localStorage:
   ─────────────────────────────────────────────────────────────
   Clave usada: 'marcom_leads_v1'
   Se guarda cada vez que hay un cambio:
     - Nuevo lead creado
     - Etapa cambiada (drag & drop o botón)
     - Nueva interacción registrada
     - Lead marcado como ganado o perdido
   ================================================================ */

'use strict';

/* ────────────────────────────────────────────────────────────────
   CLAVE DE localStorage
   Si cambias esta clave los datos guardados anteriormente se pierden.
──────────────────────────────────────────────────────────────── */
const LEADS_STORAGE_KEY = 'marcom_leads_v1';

const LeadsEvents = (() => {

  /* ── Variables privadas del módulo ───────────────────────────
     _data    → objeto completo con leads, etapas y motivos
     _current → lead que está abierto en el drawer ahora mismo
  ──────────────────────────────────────────────────────────── */
  let _data    = null;
  let _current = null;


  /* ================================================================
     localStorage — GUARDAR Y CARGAR
     Toda modificación a _data debe llamar _save() al final.
     Así el pipeline siempre refleja el estado real guardado.
  ================================================================ */

  /* ── _save ────────────────────────────────────────────────────
     Serializa _data.leads y lo guarda en localStorage.
     Solo guarda los leads — las etapas y motivos son estáticos
     y viven en LEADS_FALLBACK, no necesitan persistirse.
  ────────────────────────────────────────────────────────────── */
  function _save() {
    try {
      localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(_data.leads));
    } catch (e) {
      /* localStorage lleno o bloqueado — no es crítico */
      console.warn('[MARCOM] No se pudo guardar en localStorage:', e.message);
    }
  }

  /* ── _loadFromStorage ─────────────────────────────────────────
     Lee los leads guardados en localStorage.
     Retorna null si no hay nada guardado todavía.
  ────────────────────────────────────────────────────────────── */
  function _loadFromStorage() {
    try {
      const raw = localStorage.getItem(LEADS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      console.warn('[MARCOM] Error leyendo localStorage:', e.message);
      return null;
    }
  }


  /* ================================================================
     SIDEBAR — CONSTRUCCIÓN DEL NAV
     Construye el menú lateral leyendo NAV_ITEMS de config.js.
     Incluye íconos SVG inline. No depende de dashboard/render.js.
  ================================================================ */
  function buildNav() {
    const nav = document.getElementById('sb-nav');
    if (!nav || typeof NAV_ITEMS === 'undefined') return;

    nav.innerHTML = '';
    let currentSection = null;

    NAV_ITEMS.forEach(item => {

      /* ── Sección label (ej: "COMERCIAL", "MARKETING") ── */
      if (item.section !== currentSection) {
        currentSection = item.section;
        if (item.section) {
          const label       = document.createElement('div');
          label.className   = 'sb-section-label';
          label.textContent = item.section;
          nav.appendChild(label);
        }
      }

      /* ── Item de navegación ── */
      const page   = location.pathname.split('/').pop() || 'index.html';
      const active = page === item.url ? 'active' : '';

      /* Íconos SVG — lee del objeto ICONS definido en config.js */
      const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon])
        ? ICONS[item.icon]
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
             <circle cx="12" cy="12" r="4"/>
           </svg>`;

      const a     = document.createElement('a');
      a.className = `sb-item ${active}`;
      a.href      = item.url;
      a.setAttribute('aria-current', active ? 'page' : 'false');
      a.innerHTML = `
        <span class="sb-item-icon">${iconSvg}</span>
        <span class="sb-item-label">${item.label}</span>
      `;
      nav.appendChild(a);
    });
  }


  /* ================================================================
     DRAWER — ABRIR / CERRAR
     El drawer lateral muestra el perfil completo de un lead.
  ================================================================ */

  /* ── openDrawer ───────────────────────────────────────────────
     Busca el lead por ID y lo pasa a LeadsRender.openDrawer().
     @param {number} id — id_lead del lead a mostrar
  ────────────────────────────────────────────────────────────── */
  function openDrawer(id) {
    if (!_data) return;
    _current = _data.leads.find(l => l.id_lead === id) ?? null;
    if (_current) LeadsRender.openDrawer(_current, _data.etapas);
  }

  /* ── closeDrawer ──────────────────────────────────────────────
     Cierra el drawer y limpia el lead activo.
  ────────────────────────────────────────────────────────────── */
  function closeDrawer() {
    document.getElementById('lead-drawer')?.classList.remove('open');
    document.getElementById('drawer-overlay')?.classList.remove('open');
    document.getElementById('lead-drawer')?.setAttribute('aria-hidden', 'true');
    _current = null;
  }


  /* ================================================================
     CAMBIAR ETAPA
     Actualiza id_etapa del lead, re-renderiza y guarda.
     Llamado tanto desde el drawer como desde drag & drop.
  ================================================================ */
  function changeEtapa(leadId, newEtapa) {
    if (!_data) return;

    const lead = _data.leads.find(l => l.id_lead === leadId);
    if (!lead) return;

    lead.id_etapa = newEtapa;
    _save();

    const etaNom = _data.etapas.find(e => e.id_etapa === newEtapa)?.nom_etapa ?? '';
    Utils.showToast(`Etapa → ${etaNom}`, 'success', 2000);

    const isPipeline = document.getElementById('view-pipeline')
      ?.classList.contains('view-active');
    if (isPipeline) LeadsRender.buildPipeline(_data, window._LeadsCurrentFilters ?? {});
    else            LeadsRender.buildTabla(_data, window._LeadsCurrentFilters ?? {});

    setTimeout(() => LeadsRender.openDrawer(lead, _data.etapas), 100);
  }


  /* ================================================================
     TOGGLE DE VISTAS — Pipeline ↔ Tabla
  ================================================================ */
  function initViewToggle() {
    document.querySelectorAll('.vt-btn[data-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.dataset.view;

        document.querySelectorAll('.vt-btn').forEach(b => {
          b.classList.toggle('vt-active', b.dataset.view === view);
          b.setAttribute('aria-pressed', b.dataset.view === view ? 'true' : 'false');
        });

        document.querySelectorAll('.leads-view').forEach(v => {
          const show = v.id === `view-${view}`;
          v.classList.toggle('view-active', show);
          v.setAttribute('aria-hidden', show ? 'false' : 'true');
        });

        if (view === 'tabla' && _data) {
          LeadsRender.buildTabla(_data, window._LeadsCurrentFilters ?? {});
        }
      });
    });
  }


  /* ================================================================
     FILTROS — Etapa, Canal, Temperatura, Búsqueda
  ================================================================ */
  function initFilters() {
    const rebuild = () => {
      const filtros = {
        etapa: document.getElementById('filter-etapa')?.value ?? '',
        canal: document.getElementById('filter-canal')?.value ?? '',
        temp : document.getElementById('filter-temp')?.value  ?? '',
        q    : document.getElementById('search-leads')?.value ?? '',
      };

      window._LeadsCurrentFilters = filtros;

      const isPipeline = document.getElementById('view-pipeline')
        ?.classList.contains('view-active');
      if (isPipeline) LeadsRender.buildPipeline(_data, filtros);
      else            LeadsRender.buildTabla(_data, filtros);
    };

    ['filter-etapa', 'filter-canal', 'filter-temp'].forEach(id =>
      document.getElementById(id)?.addEventListener('change', rebuild)
    );

    let searchTimer;
    document.getElementById('search-leads')?.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(rebuild, 280);
    });
  }


  /* ================================================================
     MODAL — NUEVO LEAD
  ================================================================ */
  function openModalNuevoLead() {
    _html('modal-title', 'Nuevo Lead');
    _html('modal-body', `
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">Nombre <span>*</span></label>
          <input class="form-input" id="f-nombre" placeholder="Nombre completo" type="text" autocomplete="off"/>
        </div>
        <div class="form-group">
          <label class="form-label">Empresa <span>*</span></label>
          <input class="form-input" id="f-empresa" placeholder="Nombre de la empresa" type="text" autocomplete="off"/>
        </div>
        <div class="form-group">
          <label class="form-label">Teléfono</label>
          <input class="form-input" id="f-tel" placeholder="3001234567" type="tel"/>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input class="form-input" id="f-email" placeholder="correo@empresa.com" type="email"/>
        </div>
        <div class="form-group">
          <label class="form-label">Ciudad</label>
          <input class="form-input" id="f-ciudad" placeholder="Ciudad" type="text"/>
        </div>
        <div class="form-group">
          <label class="form-label">Canal origen</label>
          <select class="form-select" id="f-canal">
            <option value="">Seleccionar canal</option>
            <option>Email</option>
            <option>Instagram</option>
            <option>Facebook</option>
            <option>LinkedIn</option>
            <option>WhatsApp</option>
            <option>Referido</option>
          </select>
        </div>
        <div class="form-group full">
          <label class="form-label">Campaña asociada</label>
          <select class="form-select" id="f-campana">
            <option value="">Sin campaña</option>
            <option>LinkedIn B2B Q1</option>
            <option>Black Friday Digital</option>
            <option>SEO Orgánico Blog</option>
            <option>Referidos Partner</option>
          </select>
        </div>
        <div class="form-actions full" style="margin-top:0;padding-top:14px;border-top:1px solid var(--border)">
          <button class="btn-secondary" onclick="LeadsEvents.closeModal()">Cancelar</button>
          <button class="btn-primary" onclick="LeadsEvents.submitNuevoLead()">Crear Lead</button>
        </div>
      </div>
    `);
    openModal();
  }

  function submitNuevoLead() {
    const nombre  = document.getElementById('f-nombre')?.value.trim();
    const empresa = document.getElementById('f-empresa')?.value.trim();

    if (!nombre || !empresa) {
      Utils.showToast('Nombre y empresa son obligatorios', 'warning');
      return;
    }

    const nuevoLead = {
      id_lead        : Date.now(),
      nombre,
      empresa,
      telefono       : document.getElementById('f-tel')?.value.trim()    || null,
      email          : document.getElementById('f-email')?.value.trim()  || null,
      ciudad         : document.getElementById('f-ciudad')?.value.trim() || null,
      fec_registro   : new Date().toISOString().split('T')[0],
      val_score      : 0,
      id_etapa       : 1,
      ind_estado     : true,
      canal_origen   : document.getElementById('f-canal')?.value   || 'Sin canal',
      campana        : document.getElementById('f-campana')?.value || null,
      vendedor       : 'Admin753',
      proxima_accion : null,
      segmentacion   : [],
      interacciones  : [],
      campanas       : [],
      eventos        : [],
    };

    _data.leads.unshift(nuevoLead);
    _save(); /* guardar en localStorage */

    closeModal();
    LeadsRender.buildPipeline(_data, window._LeadsCurrentFilters ?? {});
    LeadsRender.buildSub(_data.leads);
    Utils.showToast(`Lead "${nombre}" creado y guardado ✓`, 'success');
  }


  /* ================================================================
     MODAL — NUEVA INTERACCIÓN
  ================================================================ */
  function openModalInteraccion() {
    if (!_current) return;
    _html('modal-title', `Nueva interacción · ${_current.nombre}`);
    _html('modal-body', `
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">Tipo <span>*</span></label>
          <select class="form-select" id="fi-tipo">
            <option value="1">📞 Llamada</option>
            <option value="2">✉️ Email</option>
            <option value="3">💬 WhatsApp</option>
            <option value="4">🤝 Visita</option>
            <option value="5">🗓️ Reunión</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Próxima acción</label>
          <input class="form-input" id="fi-proxima" type="date"/>
        </div>
        <div class="form-group full">
          <label class="form-label">Resultado <span>*</span></label>
          <textarea class="form-textarea" id="fi-resultado"
            placeholder="Describe el resultado de la interacción..."></textarea>
        </div>
        <div class="form-actions full" style="margin-top:0;padding-top:14px;border-top:1px solid var(--border)">
          <button class="btn-secondary" onclick="LeadsEvents.closeModal()">Cancelar</button>
          <button class="btn-primary" onclick="LeadsEvents.submitInteraccion()">Registrar</button>
        </div>
      </div>
    `);
    openModal();
  }

  function submitInteraccion() {
    const resultado = document.getElementById('fi-resultado')?.value.trim();
    if (!resultado) {
      Utils.showToast('El resultado es obligatorio', 'warning');
      return;
    }

    const tipo    = parseInt(document.getElementById('fi-tipo')?.value ?? '1');
    const proxima = document.getElementById('fi-proxima')?.value || null;
    const TIPOS   = { 1: 'Llamada', 2: 'Email', 3: 'WhatsApp', 4: 'Visita', 5: 'Reunión' };

    _current.interacciones.unshift({
      tipo,
      canal    : TIPOS[tipo],
      vendedor : 'Admin753',
      fecha    : new Date().toISOString().split('T')[0],
      resultado,
    });

    if (proxima) _current.proxima_accion = proxima;

    _save();
    closeModal();
    LeadsRender.openDrawer(_current, _data.etapas);
    Utils.showToast('Interacción registrada y guardada ✓', 'success');
  }


  /* ================================================================
     ACCIONES DEL DRAWER — Ganado / Perdido
  ================================================================ */
  function convertirGanado() {
    if (!_current) return;
    _current.id_etapa = 6;
    _save();
    Utils.showToast(`¡${_current.nombre} convertido a cliente! 🎉`, 'success', 4000);
    closeDrawer();
    LeadsRender.buildPipeline(_data, window._LeadsCurrentFilters ?? {});
    LeadsRender.buildSub(_data.leads);
  }

  function marcarPerdido() {
    if (!_current) return;
    _current.id_etapa = 7;
    _save();
    Utils.showToast('Lead marcado como perdido', 'warning', 3000);
    closeDrawer();
    LeadsRender.buildPipeline(_data, window._LeadsCurrentFilters ?? {});
    LeadsRender.buildSub(_data.leads);
  }


  /* ================================================================
     MODAL HELPERS
  ================================================================ */
  function openModal() {
    document.getElementById('modal-overlay')?.classList.add('open');
    document.getElementById('modal-overlay')?.setAttribute('aria-hidden', 'false');
  }

  function closeModal() {
    document.getElementById('modal-overlay')?.classList.remove('open');
    document.getElementById('modal-overlay')?.setAttribute('aria-hidden', 'true');
  }


  /* ================================================================
     SHELL — Sidebar móvil, tema, notificaciones, logout
  ================================================================ */
  function initShell() {
    document.getElementById('btn-dark')?.addEventListener('click', () => {
      if (typeof toggleDark === 'function') toggleDark();
    });
    document.getElementById('mob-menu-btn')?.addEventListener('click', () => {
      document.getElementById('sidebar')?.classList.add('sidebar-open');
      document.getElementById('sb-overlay')?.classList.add('overlay-show');
    });
    document.getElementById('sb-overlay')?.addEventListener('click', () => {
      document.getElementById('sidebar')?.classList.remove('sidebar-open');
      document.getElementById('sb-overlay')?.classList.remove('overlay-show');
    });
    document.getElementById('btn-notif')?.addEventListener('click', () => {
      Utils.showToast('Sin notificaciones nuevas', 'info');
    });
    document.getElementById('btn-logout')?.addEventListener('click', () => {
      if (typeof Auth !== 'undefined') Auth.logout();
    });
  }


  /* ── DOM helper ─────────────────────────────────────────────── */
  function _html(id, val) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = val;
  }


  /* ================================================================
     INIT PRINCIPAL
  ================================================================ */
  async function init() {

    /* 1. Sesión */
    const user = typeof Auth !== 'undefined' ? Auth.initProtectedPage() : null;
    if (typeof Auth !== 'undefined' && !user) return;

    /* 2. Fecha */
    const dateBadge = document.getElementById('date-badge');
    if (dateBadge) dateBadge.textContent = Utils.formatDate(new Date());

    /* 3. Datos — prioridad: localStorage → API → fallback */
    _data = await getLeadsData();
    const stored = _loadFromStorage();
    if (stored && stored.length > 0) {
      _data.leads = stored;
      console.info(`[MARCOM] ${stored.length} leads cargados desde localStorage`);
    }

    /* 4. Sidebar */
    buildNav();

    /* 5. Render */
    LeadsRender.buildEtapaFilter(_data.etapas);
    LeadsRender.buildSub(_data.leads);
    LeadsRender.buildPipeline(_data, {});

    /* 6. Eventos */
    initViewToggle();
    initFilters();
    initShell();

    document.getElementById('btn-nuevo-lead')
      ?.addEventListener('click', openModalNuevoLead);

    document.getElementById('drawer-overlay')?.addEventListener('click', closeDrawer);
    document.getElementById('drawer-close')?.addEventListener('click',   closeDrawer);
    document.getElementById('btn-convertir')?.addEventListener('click',  convertirGanado);
    document.getElementById('btn-perdido')?.addEventListener('click',    marcarPerdido);

    document.getElementById('btn-interaccion-rapida')
      ?.addEventListener('click', openModalInteraccion);
    document.getElementById('btn-nueva-interaccion')
      ?.addEventListener('click', openModalInteraccion);

    document.getElementById('modal-close')?.addEventListener('click', closeModal);
    document.getElementById('modal-overlay')?.addEventListener('click', e => {
      if (e.target === e.currentTarget) closeModal();
    });

    document.querySelectorAll('.dtab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.dtab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.dtab-panel').forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`dtab-${tab.dataset.tab}`)?.classList.add('active');
      });
    });

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') { closeDrawer(); closeModal(); }
    });

    /* 7. Toast */
    const activos = _data.leads.filter(l => l.id_etapa !== 6 && l.id_etapa !== 7).length;
    setTimeout(() => {
      Utils.showToast(`Pipeline listo · ${activos} activos de ${_data.leads.length}`, 'success', 3500);
    }, 700);
  }


  return {
    init,
    openDrawer,
    closeDrawer,
    changeEtapa,
    closeModal,
    submitNuevoLead,
    submitInteraccion,
  };

})();

window.LeadsEvents = LeadsEvents;
window.addEventListener('load', () => LeadsEvents.init());