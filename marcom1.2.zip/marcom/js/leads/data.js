/* ================================================================
   js/leads/data.js — Capa de Datos del módulo Leads
   Estructura espejo de la BD:
     tab_leads + tab_terceros + tab_etapas_funnel
     tab_interacciones_lead + tab_lead_camp + tab_segmentacion_tercero
     tab_even_lead + tab_motivos_perdida
================================================================ */
'use strict';

const LEADS_FALLBACK = {

  /* tab_etapas_funnel */
  etapas: [
    { id_etapa: 1, nom_etapa: 'Prospecto',         num_orden: 1, ind_etapa_final: false, color: '#94A3B8' },
    { id_etapa: 2, nom_etapa: 'Contactado',         num_orden: 2, ind_etapa_final: false, color: '#6366F1' },
    { id_etapa: 3, nom_etapa: 'Interesado',         num_orden: 3, ind_etapa_final: false, color: '#0057FF' },
    { id_etapa: 4, nom_etapa: 'Propuesta enviada',  num_orden: 4, ind_etapa_final: false, color: '#F59E0B' },
    { id_etapa: 5, nom_etapa: 'Negociación',        num_orden: 5, ind_etapa_final: false, color: '#EC4899' },
    { id_etapa: 6, nom_etapa: 'Ganado',             num_orden: 6, ind_etapa_final: true,  color: '#00A76F' },
    { id_etapa: 7, nom_etapa: 'Perdido',            num_orden: 7, ind_etapa_final: true,  color: '#E53935' },
  ],

  /* tab_motivos_perdida */
  motivosPerdida: [
    { id_motivo: 1, nom_motivo: 'Precio muy alto'       },
    { id_motivo: 2, nom_motivo: 'Eligió la competencia' },
    { id_motivo: 3, nom_motivo: 'Sin presupuesto'       },
    { id_motivo: 4, nom_motivo: 'No era el momento'     },
    { id_motivo: 5, nom_motivo: 'Sin respuesta'         },
    { id_motivo: 6, nom_motivo: 'Producto no se ajusta' },
  ],

  /* tab_leads JOIN tab_terceros JOIN tab_interacciones + tab_segmentacion */
  leads: [
    {
      id_lead       : 10000001,
      nombre        : 'Carlos Mendoza',
      empresa       : 'TechCorp S.A.',
      telefono      : '3001234567',
      email         : 'carlos@techcorp.com',
      ciudad        : 'Bogotá',
      fec_registro  : '2026-01-15',
      val_score     : 88,
      id_etapa      : 5,
      ind_estado    : true,
      canal_origen  : 'LinkedIn',
      campana       : 'LinkedIn B2B Q1',
      vendedor      : 'Ana Torres',
      proxima_accion: '2026-03-10',
      segmentacion  : [
        { criterio: 'Origen',   valor: 'Redes Sociales' },
        { criterio: 'Temp.',    valor: 'Caliente'       },
        { criterio: 'Empresa',  valor: 'Grande'         },
      ],
      interacciones: [
        { tipo: 1, canal: 'LinkedIn', vendedor: 'Ana Torres', fecha: '2026-03-07', resultado: 'Interesado en propuesta enterprise. Solicita reunión.' },
        { tipo: 5, canal: 'Reunión',  vendedor: 'Ana Torres', fecha: '2026-02-28', resultado: 'Demo realizada. Muy buena recepción del producto.' },
        { tipo: 2, canal: 'Email',    vendedor: 'Ana Torres', fecha: '2026-02-14', resultado: 'Envío de presentación corporativa.' },
      ],
      campanas: [
        { nombre: 'LinkedIn B2B Q1', fec_asignacion: '2026-01-15', etapa: 'Negociación' },
      ],
      eventos: [
        { nombre: 'Webinar B2B Marzo', fecha: '2026-03-05', estado: 'Asistió' },
      ],
    },
    {
      id_lead       : 10000002,
      nombre        : 'Laura Jiménez',
      empresa       : 'Innovatech SAS',
      telefono      : '3109876543',
      email         : 'laura@innovatech.co',
      ciudad        : 'Medellín',
      fec_registro  : '2026-01-22',
      val_score     : 72,
      id_etapa      : 4,
      ind_estado    : true,
      canal_origen  : 'Email',
      campana       : 'Black Friday Digital',
      vendedor      : 'Pedro Ruiz',
      proxima_accion: '2026-03-11',
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Email'   },
        { criterio: 'Temp.',   valor: 'Tibio'   },
        { criterio: 'Empresa', valor: 'Mediana' },
      ],
      interacciones: [
        { tipo: 2, canal: 'Email',    vendedor: 'Pedro Ruiz', fecha: '2026-03-05', resultado: 'Propuesta enviada. Esperando respuesta.' },
        { tipo: 1, canal: 'Email',    vendedor: 'Pedro Ruiz', fecha: '2026-02-20', resultado: 'Llamada de calificación. Necesidad confirmada.' },
      ],
      campanas: [
        { nombre: 'Black Friday Digital', fec_asignacion: '2026-01-22', etapa: 'Propuesta enviada' },
      ],
      eventos: [],
    },
    {
      id_lead       : 10000003,
      nombre        : 'Roberto Silva',
      empresa       : 'Grupo Alfa Ltda',
      telefono      : '3156781234',
      email         : 'rsilva@grupoalfa.com',
      ciudad        : 'Cali',
      fec_registro  : '2026-02-01',
      val_score     : 55,
      id_etapa      : 3,
      ind_estado    : true,
      canal_origen  : 'Instagram',
      campana       : 'SEO Orgánico Blog',
      vendedor      : 'Ana Torres',
      proxima_accion: null,
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Redes Sociales' },
        { criterio: 'Temp.',   valor: 'Tibio'          },
        { criterio: 'Empresa', valor: 'Mediana'        },
      ],
      interacciones: [
        { tipo: 3, canal: 'WhatsApp', vendedor: 'Ana Torres', fecha: '2026-03-01', resultado: 'Envío de catálogo por WhatsApp. Vio los productos.' },
      ],
      campanas: [],
      eventos: [],
    },
    {
      id_lead       : 10000004,
      nombre        : 'Marcela Ríos',
      empresa       : 'Soluciones XYZ',
      telefono      : '3187654321',
      email         : 'mrios@solucionesxyz.co',
      ciudad        : 'Barranquilla',
      fec_registro  : '2026-01-18',
      val_score     : 38,
      id_etapa      : 1,
      ind_estado    : true,
      canal_origen  : 'Facebook',
      campana       : 'Black Friday Digital',
      vendedor      : 'Luis Mora',
      proxima_accion: '2026-03-09',
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Redes Sociales' },
        { criterio: 'Temp.',   valor: 'Frío'           },
        { criterio: 'Empresa', valor: 'Pequeña'        },
      ],
      interacciones: [
        { tipo: 1, canal: 'Facebook', vendedor: 'Luis Mora', fecha: '2026-02-22', resultado: 'No contestó. Se dejó mensaje.' },
      ],
      campanas: [
        { nombre: 'Black Friday Digital', fec_asignacion: '2026-01-18', etapa: 'Prospecto' },
      ],
      eventos: [],
    },
    {
      id_lead       : 10000005,
      nombre        : 'Felipe Vargas',
      empresa       : 'Distribuidora Sur',
      telefono      : '3001112233',
      email         : 'fvargas@distrisur.com',
      ciudad        : 'Bogotá',
      fec_registro  : '2026-02-10',
      val_score     : 91,
      id_etapa      : 5,
      ind_estado    : true,
      canal_origen  : 'Referido',
      campana       : 'Referidos Partner',
      vendedor      : 'Pedro Ruiz',
      proxima_accion: '2026-03-09',
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Referido'  },
        { criterio: 'Temp.',   valor: 'Caliente'  },
        { criterio: 'Empresa', valor: 'Grande'    },
      ],
      interacciones: [
        { tipo: 5, canal: 'Reunión',  vendedor: 'Pedro Ruiz', fecha: '2026-03-08', resultado: 'Revisión de contrato. Firma prevista esta semana.' },
        { tipo: 2, canal: 'Email',    vendedor: 'Pedro Ruiz', fecha: '2026-03-05', resultado: 'Contrato enviado para revisión legal.' },
        { tipo: 1, canal: 'LinkedIn', vendedor: 'Pedro Ruiz', fecha: '2026-02-28', resultado: 'Acuerdo en precio. Proceso en fase legal.' },
      ],
      campanas: [
        { nombre: 'Referidos Partner', fec_asignacion: '2026-02-10', etapa: 'Negociación' },
      ],
      eventos: [
        { nombre: 'Feria Industrial 2026', fecha: '2026-02-20', estado: 'Confirmado' },
      ],
    },
    {
      id_lead       : 10000006,
      nombre        : 'Diana Castillo',
      empresa       : 'Construcciones Norte',
      telefono      : '3223344556',
      email         : 'dcastillo@consnorte.co',
      ciudad        : 'Bucaramanga',
      fec_registro  : '2026-02-15',
      val_score     : 64,
      id_etapa      : 4,
      ind_estado    : true,
      canal_origen  : 'Email',
      campana       : 'SEO Orgánico Blog',
      vendedor      : 'Luis Mora',
      proxima_accion: '2026-03-12',
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Email'   },
        { criterio: 'Temp.',   valor: 'Tibio'   },
        { criterio: 'Empresa', valor: 'Mediana' },
      ],
      interacciones: [
        { tipo: 2, canal: 'Email', vendedor: 'Luis Mora', fecha: '2026-03-03', resultado: 'Propuesta personalizada enviada. Cliente revisando.' },
        { tipo: 1, canal: 'Email', vendedor: 'Luis Mora', fecha: '2026-02-25', resultado: 'Llamada de presentación. Interés moderado.' },
      ],
      campanas: [
        { nombre: 'SEO Orgánico Blog', fec_asignacion: '2026-02-15', etapa: 'Propuesta enviada' },
      ],
      eventos: [],
    },
    {
      id_lead       : 10000007,
      nombre        : 'Andrés Ospina',
      empresa       : 'Logística Express',
      telefono      : '3001234000',
      email         : 'aospina@logexpress.com',
      ciudad        : 'Bogotá',
      fec_registro  : '2026-02-20',
      val_score     : 45,
      id_etapa      : 2,
      ind_estado    : true,
      canal_origen  : 'LinkedIn',
      campana       : 'LinkedIn B2B Q1',
      vendedor      : 'Ana Torres',
      proxima_accion: '2026-03-14',
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Redes Sociales' },
        { criterio: 'Temp.',   valor: 'Tibio'          },
        { criterio: 'Empresa', valor: 'Grande'         },
      ],
      interacciones: [
        { tipo: 4, canal: 'LinkedIn', vendedor: 'Ana Torres', fecha: '2026-03-02', resultado: 'Primer contacto por LinkedIn. Respondió con interés.' },
      ],
      campanas: [
        { nombre: 'LinkedIn B2B Q1', fec_asignacion: '2026-02-20', etapa: 'Contactado' },
      ],
      eventos: [],
    },
    {
      id_lead       : 10000008,
      nombre        : 'Valentina Cruz',
      empresa       : 'Agencia Creativa',
      telefono      : '3142233445',
      email         : 'vcruz@agenciacreat.co',
      ciudad        : 'Medellín',
      fec_registro  : '2026-03-01',
      val_score     : 22,
      id_etapa      : 1,
      ind_estado    : true,
      canal_origen  : 'Instagram',
      campana       : null,
      vendedor      : 'Luis Mora',
      proxima_accion: null,
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Redes Sociales' },
        { criterio: 'Temp.',   valor: 'Frío'           },
        { criterio: 'Empresa', valor: 'Pequeña'        },
      ],
      interacciones: [],
      campanas: [],
      eventos: [],
    },
    {
      id_lead       : 10000009,
      nombre        : 'Jorge Peñaloza',
      empresa       : 'Finanzas Global',
      telefono      : '3005566778',
      email         : 'jpenaloza@finglobal.co',
      ciudad        : 'Bogotá',
      fec_registro  : '2025-11-10',
      val_score     : 61,
      id_etapa      : 6,
      ind_estado    : true,
      canal_origen  : 'Email',
      campana       : 'Black Friday Digital',
      vendedor      : 'Pedro Ruiz',
      proxima_accion: null,
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Email'   },
        { criterio: 'Temp.',   valor: 'Caliente'},
        { criterio: 'Empresa', valor: 'Grande'  },
      ],
      interacciones: [
        { tipo: 6, canal: 'Reunión', vendedor: 'Pedro Ruiz', fecha: '2026-01-15', resultado: 'Contrato firmado. Convertido a cliente.' },
      ],
      campanas: [
        { nombre: 'Black Friday Digital', fec_asignacion: '2025-11-10', etapa: 'Ganado' },
      ],
      eventos: [],
    },
    {
      id_lead       : 10000010,
      nombre        : 'Sofía Martínez',
      empresa       : 'RetailMax',
      telefono      : '3198877665',
      email         : 'smartinez@retailmax.co',
      ciudad        : 'Cali',
      fec_registro  : '2025-12-01',
      val_score     : 30,
      id_etapa      : 7,
      id_motivo_perdida: 1,
      ind_estado    : false,
      canal_origen  : 'Facebook',
      campana       : 'Display Programático',
      vendedor      : 'Luis Mora',
      proxima_accion: null,
      segmentacion  : [
        { criterio: 'Origen',  valor: 'Redes Sociales' },
        { criterio: 'Temp.',   valor: 'Frío'           },
        { criterio: 'Empresa', valor: 'Mediana'        },
      ],
      interacciones: [
        { tipo: 1, canal: 'Facebook', vendedor: 'Luis Mora', fecha: '2025-12-20', resultado: 'Precio demasiado alto. No continúa proceso.' },
      ],
      campanas: [
        { nombre: 'Display Programático', fec_asignacion: '2025-12-01', etapa: 'Perdido' },
      ],
      eventos: [],
    },
  ],
};

async function getLeadsData() {
  try {
    const endpoint = (typeof API !== 'undefined' && API.leads)
      ? API.leads
      : '../data/leads.json';
    const res = await fetch(endpoint, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[MARCOM] getLeadsData: usando datos simulados.', err.message);
    return LEADS_FALLBACK;
  }
}

window.getLeadsData  = getLeadsData;
window.LEADS_FALLBACK = LEADS_FALLBACK;