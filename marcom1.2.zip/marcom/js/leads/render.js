/* ================================================================
   js/leads/render.js — Renderizador del módulo Leads
================================================================ */
'use strict';

const LeadsRender = (() => {

  const TIPO_ICONS = {
    1: { icon: '📞', label: 'Llamada',  bg: 'var(--info-bg)',    color: 'var(--info)'    },
    2: { icon: '✉️',  label: 'Email',    bg: 'var(--accent-bg)', color: 'var(--accent)'  },
    3: { icon: '💬', label: 'WhatsApp', bg: 'var(--success-bg)',color: 'var(--success)' },
    4: { icon: '🤝', label: 'Visita',   bg: 'var(--warning-bg)',color: 'var(--warning)' },
    5: { icon: '🗓️', label: 'Reunión',  bg: 'var(--info-bg)',    color: 'var(--info)'    },
  };

  const TEMP_MAP = {
    'Caliente': { emoji: '🔴', class: 'badge-danger'   },
    'Tibio'   : { emoji: '🟡', class: 'badge-warning'  },
    'Frío'    : { emoji: '🔵', class: 'badge-neutral'  },
  };

  const ETAPA_BADGE = {
    1: 'badge-neutral',
    2: 'badge-info',
    3: 'badge-accent',
    4: 'badge-warning',
    5: 'badge-warning',
    6: 'badge-success',
    7: 'badge-danger',
  };

  /* ── Temperatura del lead ─────────────────────────────── */
  function getTemp(lead) {
    const seg = lead.segmentacion?.find(s => s.criterio === 'Temp.');
    return seg?.valor ?? 'Frío';
  }

  /* ── Aging en días ────────────────────────────────────── */
  function getAging(lead) {
    const fec = new Date(lead.fec_registro);
    const hoy = new Date();
    return Math.floor((hoy - fec) / (1000 * 60 * 60 * 24));
  }

  /* ── Score classes ────────────────────────────────────── */
  function scoreColor(score) {
    if (score >= 70) return { fill: 'var(--success)', cls: 'sv-high' };
    if (score >= 40) return { fill: 'var(--warning)', cls: 'sv-mid'  };
    return                  { fill: 'var(--danger)',  cls: 'sv-low'  };
  }

  /* ── Nombre de etapa por ID ───────────────────────────── */
  function etapaNom(etapas, id) {
    return etapas.find(e => e.id_etapa === id)?.nom_etapa ?? '—';
  }

  /* ===========================================================
     PIPELINE KANBAN
  =========================================================== */
  function buildPipeline(data, filtros = {}) {
    const board = document.getElementById('pipeline-board');
    if (!board) return;

    const leads  = _applyFilters(data.leads, filtros, data.etapas);
    const etapas = data.etapas;

    board.innerHTML = '';

    etapas.forEach(etapa => {
      const leadsEtapa = leads.filter(l => l.id_etapa === etapa.id_etapa);

      const col = document.createElement('div');
      col.className    = 'pipeline-col anim';
      col.dataset.etapa = etapa.id_etapa;
      col.style.animationDelay = `${(etapa.num_orden - 1) * 0.04}s`;

      col.innerHTML = `
        <div class="pipeline-col-header">
          <div style="display:flex;align-items:center;gap:0">
            <span class="col-indicator" style="background:${etapa.color}"></span>
            <span class="col-etapa-name">${etapa.nom_etapa}</span>
          </div>
          <span class="col-count">${leadsEtapa.length}</span>
        </div>
        <div class="pipeline-drop-zone" data-etapa="${etapa.id_etapa}" id="drop-${etapa.id_etapa}">
          ${leadsEtapa.length === 0
            ? '<div class="empty-col">Sin leads</div>'
            : leadsEtapa.map(l => buildLeadCard(l, etapas)).join('')}
        </div>
      `;
      board.appendChild(col);
    });

    _initDragDrop(data);
  }

  /* ── Tarjeta de lead ──────────────────────────────────── */
  function buildLeadCard(lead, etapas) {
    const temp  = getTemp(lead);
    const tMap  = TEMP_MAP[temp] ?? TEMP_MAP['Frío'];
    const aging = getAging(lead);
    const agCls = Utils.agingClass(aging);
    const sc    = scoreColor(lead.val_score);
    const av    = Utils.avatarColor(lead.nombre);
    const ini   = Utils.initials(lead.nombre);

    return `
      <div class="lead-card"
           draggable="true"
           data-id="${lead.id_lead}"
           data-etapa="${lead.id_etapa}"
           onclick="LeadsEvents.openDrawer(${lead.id_lead})">
        <div class="lead-card-top">
          <div>
            <div class="lead-card-name">${Utils.truncate(lead.nombre, 22)}</div>
            <div class="lead-card-empresa">${Utils.truncate(lead.empresa, 24)}</div>
          </div>
          <span class="lead-card-temp" title="${temp}">${tMap.emoji}</span>
        </div>
        <div class="lead-card-score">
          <div class="lcs-bar">
            <div class="lcs-fill" style="width:${lead.val_score}%;background:${sc.fill}"></div>
          </div>
          <span class="lcs-val ${sc.cls}">${lead.val_score}</span>
        </div>
        <div class="lead-card-footer">
          <span class="lead-card-canal">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.22 1.21 2 2 0 012.22 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.16A16 16 0 0012 12.06l.66-.66a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 13.92v3z"/></svg>
            ${lead.canal_origen}
          </span>
          <span class="lead-card-aging ${agCls}">${aging}d</span>
        </div>
      </div>
    `;
  }

  /* ===========================================================
     TABLA DE LEADS
  =========================================================== */
  function buildTabla(data, filtros = {}) {
    const tbody = document.getElementById('leads-tbody');
    const count = document.getElementById('tabla-count');
    if (!tbody) return;

    const leads = _applyFilters(data.leads, filtros, data.etapas);
    if (count) count.textContent = leads.length;

    tbody.innerHTML = leads.map(l => {
      const temp  = getTemp(l);
      const tMap  = TEMP_MAP[temp] ?? TEMP_MAP['Frío'];
      const aging = getAging(l);
      const agCls = Utils.agingClass(aging);
      const sc    = scoreColor(l.val_score);
      const ebadge = ETAPA_BADGE[l.id_etapa] ?? 'badge-neutral';
      const etNom  = etapaNom(data.etapas, l.id_etapa);
      const ini    = Utils.initials(l.nombre);
      const av     = Utils.avatarColor(l.nombre);

      return `
        <tr onclick="LeadsEvents.openDrawer(${l.id_lead})" style="cursor:pointer">
          <td>
            <div class="lead-cell">
              <div class="avatar ${av}">${ini}</div>
              <div>
                <div class="lead-name">${l.nombre}</div>
                <div class="lead-email">${l.empresa}</div>
              </div>
            </div>
          </td>
          <td><span class="badge ${ebadge}">${etNom}</span></td>
          <td>
            <div class="score-wrap">
              <div class="score-bar">
                <div class="score-fill" style="width:${l.val_score}%;background:${sc.fill}"></div>
              </div>
              <span class="score-val ${sc.cls}">${l.val_score}</span>
            </div>
          </td>
          <td><span class="badge ${tMap.class}">${tMap.emoji} ${temp}</span></td>
          <td class="t-sm t-second">${l.canal_origen}</td>
          <td class="t-sm t-second">${Utils.truncate(l.campana ?? '—', 20)}</td>
          <td class="t-sm t-second">${l.vendedor}</td>
          <td class="t-mono t-sm ${l.proxima_accion ? 'sv-mid' : 't-muted'}">
            ${l.proxima_accion ?? '—'}
          </td>
          <td><span class="${agCls}">${aging}d</span></td>
          <td><button class="tbl-btn-ver">Ver →</button></td>
        </tr>
      `;
    }).join('');
  }

  /* ===========================================================
     DRAWER — PERFIL DEL LEAD
  =========================================================== */
  function openDrawer(lead, etapas) {
    if (!lead) return;

    const temp  = getTemp(lead);
    const tMap  = TEMP_MAP[temp] ?? TEMP_MAP['Frío'];
    const aging = getAging(lead);
    const agCls = Utils.agingClass(aging);
    const sc    = scoreColor(lead.val_score);
    const av    = Utils.avatarColor(lead.nombre);
    const ini   = Utils.initials(lead.nombre);
    const etNom = etapaNom(etapas, lead.id_etapa);
    const ebadge = ETAPA_BADGE[lead.id_etapa] ?? 'badge-neutral';

    /* Header */
    const avatarEl = document.getElementById('drawer-avatar');
    if (avatarEl) { avatarEl.textContent = ini; avatarEl.className = `drawer-avatar ${av}`; }
    _set('drawer-lead-name',    lead.nombre);
    _set('drawer-lead-empresa', lead.empresa);

    /* Score bar */
    const fill = document.getElementById('drawer-score-fill');
    if (fill) { fill.style.width = lead.val_score + '%'; fill.style.background = sc.fill; }
    _set('drawer-score-val',   lead.val_score);
    _html('drawer-etapa-badge',  `<span class="badge ${ebadge}">${etNom}</span>`);
    _html('drawer-temp-badge',   `<span class="badge ${tMap.class}">${tMap.emoji} ${temp}</span>`);
    _html('drawer-aging',        `<span class="${agCls}">${aging}d</span>`);

    /* Botones ganado/perdido */
    const etapaActual = lead.id_etapa;
    document.getElementById('btn-convertir')?.classList.toggle('hidden', etapaActual === 6);
    document.getElementById('btn-perdido')?.classList.toggle('hidden', etapaActual === 7);

    /* Tab Info */
    _html('drawer-info-grid', `
      <div class="info-item"><span class="info-label">Teléfono</span><span class="info-val">${lead.telefono ?? '—'}</span></div>
      <div class="info-item"><span class="info-label">Email</span><span class="info-val t-truncate" style="max-width:140px">${lead.email ?? '—'}</span></div>
      <div class="info-item"><span class="info-label">Ciudad</span><span class="info-val">${lead.ciudad ?? '—'}</span></div>
      <div class="info-item"><span class="info-label">Canal origen</span><span class="info-val">${lead.canal_origen ?? '—'}</span></div>
      <div class="info-item"><span class="info-label">Vendedor</span><span class="info-val">${lead.vendedor ?? '—'}</span></div>
      <div class="info-item"><span class="info-label">Registro</span><span class="info-val">${lead.fec_registro ?? '—'}</span></div>
    `);

    /* Segmentación */
    const segHTML = (lead.segmentacion ?? []).map(s => `
      <div class="seg-chip">
        <span class="seg-chip-label">${s.criterio}:</span>
        ${s.valor}
      </div>
    `).join('') || '<span class="t-muted t-sm">Sin segmentación</span>';
    _html('drawer-segmentacion', segHTML);

    /* Próxima acción */
    const proxEl = document.getElementById('drawer-proxima-accion');
    if (proxEl) {
      if (lead.proxima_accion) {
        proxEl.className = 'proxima-accion';
        proxEl.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span>${lead.proxima_accion}</span>`;
      } else {
        proxEl.className = 'proxima-accion sin-accion';
        proxEl.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span>Sin próxima acción agendada</span>`;
      }
    }

    /* Etapa steps */
    const stepsHTML = etapas.map(e => {
      let cls = 'etapa-step';
      if (e.id_etapa === lead.id_etapa) cls += ' etapa-actual';
      if (e.id_etapa === 6) cls += ' etapa-final-g';
      if (e.id_etapa === 7) cls += ' etapa-final-p';
      return `<button class="${cls}" data-etapa="${e.id_etapa}" onclick="LeadsEvents.changeEtapa(${lead.id_lead}, ${e.id_etapa})">${e.nom_etapa}</button>`;
    }).join('');
    _html('drawer-etapa-steps', stepsHTML);

    /* Interacciones */
    const intHTML = (lead.interacciones ?? []).length
      ? lead.interacciones.map(i => {
          const t = TIPO_ICONS[i.tipo] ?? TIPO_ICONS[1];
          return `
            <div class="interaccion-item">
              <div class="interaccion-icon" style="background:${t.bg}">
                ${t.icon}
              </div>
              <div class="interaccion-body">
                <div class="interaccion-tipo">${t.label} · ${i.canal}</div>
                <div class="interaccion-resultado">${i.resultado}</div>
                <div class="interaccion-meta">
                  <span class="interaccion-fecha">${i.fecha}</span>
                  <span class="interaccion-vendedor">· ${i.vendedor}</span>
                </div>
              </div>
            </div>
          `;
        }).join('')
      : '<p class="t-muted t-sm">Sin interacciones registradas.</p>';
    _html('drawer-interacciones', intHTML);

    /* Campañas */
    const campHTML = (lead.campanas ?? []).length
      ? lead.campanas.map(c => `
          <div class="campana-item">
            <div class="campana-dot"></div>
            <span class="campana-name">${c.nombre}</span>
            <span class="campana-etapa">${c.etapa}</span>
          </div>
        `).join('')
      : '<p class="t-muted t-sm">Sin campañas asociadas.</p>';
    _html('drawer-campanas', campHTML);

    /* Eventos */
    const evHTML = (lead.eventos ?? []).length
      ? lead.eventos.map(e => `
          <div class="evento-item">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            <span class="evento-name">${e.nombre}</span>
            <span class="evento-fecha">${e.estado}</span>
          </div>
        `).join('')
      : '<p class="t-muted t-sm">Sin eventos registrados.</p>';
    _html('drawer-eventos', evHTML);

    /* Abrir drawer */
    document.getElementById('lead-drawer')?.classList.add('open');
    document.getElementById('drawer-overlay')?.classList.add('open');
    document.getElementById('lead-drawer')?.setAttribute('aria-hidden', 'false');
  }

  /* ── Helpers DOM ──────────────────────────────────────── */
  function _set(id, val)  { const el = document.getElementById(id); if (el) el.textContent = val; }
  function _html(id, val) { const el = document.getElementById(id); if (el) el.innerHTML   = val; }

  /* ── Drag & Drop ──────────────────────────────────────── */
  function _initDragDrop(data) {
    const cards = document.querySelectorAll('.lead-card[draggable]');
    const zones = document.querySelectorAll('.pipeline-drop-zone');

    let draggingId   = null;
    let draggingEtapa = null;

    cards.forEach(card => {
      card.addEventListener('dragstart', e => {
        draggingId    = parseInt(card.dataset.id);
        draggingEtapa = parseInt(card.dataset.etapa);
        card.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      card.addEventListener('dragend', () => {
        card.classList.remove('dragging');
        zones.forEach(z => z.classList.remove('drag-over'));
      });
    });

    zones.forEach(zone => {
      zone.addEventListener('dragover', e => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        zone.classList.add('drag-over');
      });
      zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
      zone.addEventListener('drop', e => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        const newEtapa = parseInt(zone.dataset.etapa);
        if (!draggingId || newEtapa === draggingEtapa) return;
        /* Actualizar en los datos */
        const lead = data.leads.find(l => l.id_lead === draggingId);
        if (lead) {
          lead.id_etapa = newEtapa;
          buildPipeline(data, window._LeadsCurrentFilters ?? {});
          Utils.showToast(`Lead movido a "${data.etapas.find(e => e.id_etapa === newEtapa)?.nom_etapa}"`, 'success', 2500);
        }
        draggingId = null;
        draggingEtapa = null;
      });
    });
  }

  /* ── Filtros ──────────────────────────────────────────── */
  function _applyFilters(leads, filtros, etapas) {
    return leads.filter(l => {
      if (filtros.etapa && l.id_etapa !== parseInt(filtros.etapa)) return false;
      if (filtros.canal && l.canal_origen !== filtros.canal) return false;
      if (filtros.temp  && getTemp(l) !== filtros.temp) return false;
      if (filtros.q) {
        const q = filtros.q.toLowerCase();
        if (!l.nombre.toLowerCase().includes(q) && !l.empresa.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }

  /* ── Poblar filtro de etapas ──────────────────────────── */
  function buildEtapaFilter(etapas) {
    const sel = document.getElementById('filter-etapa');
    if (!sel) return;
    etapas.forEach(e => {
      const opt = document.createElement('option');
      opt.value       = e.id_etapa;
      opt.textContent = e.nom_etapa;
      sel.appendChild(opt);
    });
  }

  /* ── Sub encabezado ───────────────────────────────────── */
  function buildSub(leads) {
    const activos = leads.filter(l => l.id_etapa !== 6 && l.id_etapa !== 7).length;
    const ganados = leads.filter(l => l.id_etapa === 6).length;
    const sub = document.getElementById('leads-sub');
    if (sub) sub.textContent = `${activos} activos · ${ganados} ganados · ${leads.length} total`;
  }

  return { buildPipeline, buildTabla, openDrawer, buildEtapaFilter, buildSub };

})();

window.LeadsRender = LeadsRender;