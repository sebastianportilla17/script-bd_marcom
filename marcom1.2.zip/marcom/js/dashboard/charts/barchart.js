/* ================================================================
   charts.js — barChart · donutChart · hBarChart  v2.1 FIXED
   SVG puro. Sin librerías externas.
================================================================ */
'use strict';

/* Helpers internos — funcionan aunque Utils no haya cargado aún */
const _pct   = (v, t)      => (!t ? 0 : Math.min((v / t) * 100, 100));
const _clamp = (v, mn, mx) => Math.min(Math.max(Number(v), mn), mx);
const _fmt   = v            => {
  if (typeof Utils !== 'undefined') return Utils.formatNumber(v);
  return String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
};
const _trunc = (s, n) => {
  if (typeof Utils !== 'undefined') return Utils.truncate(s, n);
  return s && s.length > n ? s.slice(0, n - 1) + '…' : (s || '');
};


/* ================================================================
   barChart(container, data)
   data: [{ mes, leads, conv }]
   Dibuja barras verticales dobles (leads azul / conv verde).
================================================================ */
function barChart(container, data = []) {
  if (!container || !data.length) return;

  const maxVal = Math.max(...data.map(d => d.leads), 1);

  const barsHTML = data.map(d => {
    const leadsH = _clamp(_pct(d.leads, maxVal), 2, 100);
    const convH  = _clamp(_pct(d.conv,  maxVal), 2, 100);
    return `
      <div class="bar-col">
        <div class="bar-pair">
          <div class="bar bar-leads" style="height:${leadsH}%" title="Leads: ${d.leads}"></div>
          <div class="bar bar-conv"  style="height:${convH}%"  title="Conv: ${d.conv}"></div>
        </div>
        <span class="bar-label">${d.mes}</span>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <div class="bar-chart">${barsHTML}</div>
    <div class="chart-legend">
      <div class="legend-item">
        <span class="legend-dot" style="background:var(--accent)"></span>
        Leads captados
      </div>
      <div class="legend-item">
        <span class="legend-dot" style="background:var(--success)"></span>
        Conversiones
      </div>
    </div>
  `;
}

window.barChart = barChart;


/* ================================================================
   donutChart(container, data)
   data: [{ name, count, pct, color }]
   Dibuja un donut SVG con el total en el centro + leyenda.
================================================================ */
function donutChart(container, data = []) {
  if (!container || !data.length) return;

  const R      = 44;          /* radio del arco */
  const CX     = 60;
  const CY     = 60;
  const stroke = 14;
  const circ   = 2 * Math.PI * R;
  const total  = data.reduce((s, d) => s + d.count, 0);

  let offset = 0;
  const arcs = data.map(d => {
    const dash      = (d.pct / 100) * circ;
    const gap       = circ - dash;
    const arc       = `
      <circle
        cx="${CX}" cy="${CY}" r="${R}"
        fill="none"
        stroke="${d.color}"
        stroke-width="${stroke}"
        stroke-dasharray="${dash} ${gap}"
        stroke-dashoffset="${-offset}"
        stroke-linecap="butt"
      />
    `;
    offset += dash;
    return arc;
  }).join('');

  const legendHTML = data.map(d => `
    <div class="donut-legend-row">
      <span class="donut-legend-dot" style="background:${d.color}"></span>
      <span class="donut-legend-name">${d.name}</span>
      <span class="donut-legend-val">${_fmt(d.count)}</span>
    </div>
  `).join('');

  container.innerHTML = `
    <div class="donut-wrap">
      <svg class="donut-svg" width="120" height="120" viewBox="0 0 120 120">
        <circle cx="${CX}" cy="${CY}" r="${R}"
          fill="none"
          stroke="var(--bg-2)"
          stroke-width="${stroke}"/>
        ${arcs}
      </svg>
      <div class="donut-center">
        <span class="donut-value">${_fmt(total)}</span>
        <span class="donut-lbl">total</span>
      </div>
    </div>
    <div class="donut-legend">${legendHTML}</div>
  `;
}

window.donutChart = donutChart;


/* ================================================================
   hBarChart(container, data, type)
   type: 'roi' | 'funnel'

   roi    → data: [{ canal, roi, positivo }]
            valores positivos en verde, negativos en rojo
            la barra ocupa el % del máximo absoluto

   funnel → data: [{ etapa, leads, color }]
            barras de izquierda a derecha, coloreadas individualmente
================================================================ */
function hBarChart(container, data = [], type = 'funnel') {
  if (!container || !data.length) return;

  let rowsHTML = '';

  if (type === 'roi') {
    const maxAbs = Math.max(...data.map(d => Math.abs(d.roi)), 1);
    rowsHTML = data.map(d => {
      const pct       = _clamp(_pct(Math.abs(d.roi), maxAbs), 2, 100);
      const fillColor = d.positivo ? 'var(--success)' : 'var(--danger)';
      const valClass  = d.positivo ? 'h-bar-pos' : 'h-bar-neg';
      const sign      = d.positivo ? '+' : '';
      return `
        <div class="h-bar-row">
          <span class="h-bar-label" title="${d.canal}">${_trunc(d.canal, 14)}</span>
          <div class="h-bar-track">
            <div class="h-bar-fill" style="width:${pct}%;background:${fillColor}"></div>
          </div>
          <span class="h-bar-value ${valClass}">${sign}${d.roi}%</span>
        </div>
      `;
    }).join('');

  } else {
    /* funnel */
    const maxLeads = Math.max(...data.map(d => d.leads), 1);
    rowsHTML = data.map(d => {
      const pct = _clamp(_pct(d.leads, maxLeads), 2, 100);
      return `
        <div class="h-bar-row">
          <span class="h-bar-label" title="${d.etapa}">${_trunc(d.etapa, 14)}</span>
          <div class="h-bar-track">
            <div class="h-bar-fill" style="width:${pct}%;background:${d.color ?? 'var(--accent)'}"></div>
          </div>
          <span class="h-bar-value" style="color:var(--text-2)">${_fmt(d.leads)}</span>
        </div>
      `;
    }).join('');
  }

  container.innerHTML = `<div>${rowsHTML}</div>`;
}

window.hBarChart = hBarChart;