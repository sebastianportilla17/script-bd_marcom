/* ================================================================
   render.js — Ensamblador del Dashboard MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Reescrito

   Usa los componentes y charts para construir el DOM completo.
   init.js llama Render.gerencial(data) y Render.operativa(data).
   Nunca hace fetch ni accede a localStorage directamente.
================================================================ */
'use strict';

const Render = (() => {

  /* ============================================================
     HELPERS PRIVADOS
  ============================================================ */

  /** Agrega clases de animación escalonada a un array de elementos */
  function animateItems(items) {
    items.forEach((el, i) => {
      el.classList.add('anim', `anim-${Math.min(i + 1, 6)}`);
    });
  }

  /** Construye una fila de la tabla de campañas */
  function buildCampanaRow(c) {
    const roiClass = c.roi >= 0 ? 'roi-pos' : 'roi-neg';
    const roiSign  = c.roi >= 0 ? '+' : '';
    const estadoBadge = {
      activa  : 'badge-success',
      pausada : 'badge-warning',
      cerrada : 'badge-neutral',
    }[c.estado] ?? 'badge-neutral';

    return `
      <tr>
        <td>
          <span class="t-semi t-base" style="color:var(--text)">${Utils.truncate(c.nombre, 28)}</span>
        </td>
        <td>
          <span class="badge badge-accent">${c.canal}</span>
        </td>
        <td class="t-mono t-sm">${Utils.formatNumber(c.leads)}</td>
        <td>
          <div class="score-wrap">
            <div class="score-bar">
              <div class="score-fill ${c.convRate >= 25 ? 'sf-high' : c.convRate >= 15 ? 'sf-mid' : 'sf-low'}"
                   style="width:${Utils.clamp(c.convRate, 0, 100)}%"></div>
            </div>
            <span class="score-val ${c.convRate >= 25 ? 'sv-high' : c.convRate >= 15 ? 'sv-mid' : 'sv-low'}">
              ${c.convRate.toFixed(1)}%
            </span>
          </div>
        </td>
        <td><span class="${roiClass}">${roiSign}${c.roi}%</span></td>
        <td><span class="badge ${estadoBadge}">${c.estado}</span></td>
      </tr>
    `;
  }

  /** Construye una fila de la tabla de leads */
  function buildLeadRow(l) {
    const sc  = Utils.scoreClass(l.score);
    const agC = Utils.agingClass(l.aging);
    const av  = Utils.avatarColor(l.nombre);
    const ini = Utils.initials(l.nombre);

    const etapaBadge = {
      'Prospecto'   : 'badge-neutral',
      'Calificado'  : 'badge-accent',
      'Propuesta'   : 'badge-info',
      'Negociación' : 'badge-warning',
      'Cierre'      : 'badge-success',
    }[l.etapa] ?? 'badge-neutral';

    return `
      <tr>
        <td>
          <div class="lead-cell">
            <div class="avatar ${av}">${ini}</div>
            <div>
              <div class="lead-name">${l.nombre}</div>
              <div class="lead-email">${l.empresa}</div>
            </div>
          </div>
        </td>
        <td><span class="badge ${etapaBadge}">${l.etapa}</span></td>
        <td>
          <div class="score-wrap">
            <div class="score-bar">
              <div class="score-fill ${sc.fill}" style="width:${l.score}%"></div>
            </div>
            <span class="score-val ${sc.val}">${l.score}</span>
          </div>
        </td>
        <td><span class="${agC}">${l.aging}d</span></td>
        <td class="t-mono t-sm t-muted">${l.ultimoContacto}</td>
        <td class="t-sm t-second">${l.responsable}</td>
      </tr>
    `;
  }


  /* ============================================================
     SIDEBAR NAV
     Construye los items del sidebar desde NAV_ITEMS (config.js)
  ============================================================ */
  function buildNav(badgeCount = 0) {
    const nav = document.getElementById('sb-nav');
    if (!nav || typeof NAV_ITEMS === 'undefined') return;

    nav.innerHTML = '';

    let currentSection = null;

    NAV_ITEMS.forEach(item => {
      /* Sección label */
      if (item.section !== currentSection) {
        currentSection = item.section;
        if (item.section) {
          const label = document.createElement('div');
          label.className   = 'sb-section-label';
          label.textContent = item.section;
          nav.appendChild(label);
        }
      }

      const page   = location.pathname.split('/').pop() || 'index.html';
      const active = page === item.url ? 'active' : '';
      const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon])
        ? ICONS[item.icon]
        : '';

      const a = document.createElement('a');
      a.className = `sb-item ${active}`;
      a.href      = item.url;
      a.setAttribute('aria-current', active ? 'page' : 'false');

      const badgeHTML = (item.badge && badgeCount > 0)
        ? `<span class="sb-badge" style="display:flex">${badgeCount}</span>`
        : '';

      a.innerHTML = `
        <span class="sb-item-icon">${iconSvg}</span>
        <span class="sb-item-label">${item.label}</span>
        ${badgeHTML}
      `;

      nav.appendChild(a);
    });
  }


  /* ============================================================
     VISTA GERENCIAL
  ============================================================ */
  function gerencial(data) {
    const g = data.gerencial;

    /* ── Encabezado ──────────────────────────────────────────── */
    const hdr = document.getElementById('view-header-gerencial');
    if (hdr) {
      hdr.innerHTML = `
        <h1 class="view-title">Dashboard Gerencial</h1>
        <p class="view-sub">Período: ${data.meta?.periodo ?? 'Actual'}</p>
      `;
    }

    /* ── Fila 1: Tendencias (4 KPIs) ─────────────────────────── */
    const gridTend = document.getElementById('kpis-tendencias');
    if (gridTend && g.tendencias) {
      gridTend.innerHTML = '';
      const cards = g.tendencias.map(d => MetricCard(d));
      animateItems(cards);
      cards.forEach(c => gridTend.appendChild(c));
    }

    /* ── Fila 2: Charts gerenciales ───────────────────────────── */
    const chartsRow = document.getElementById('charts-gerencial');
    if (chartsRow) {
      chartsRow.innerHTML = '';

      /* Bar chart */
      const barCard = ChartCard({
        title    : 'Leads vs Conversiones',
        sub      : 'Últimos 6 meses',
        slotId   : 'slot-bar-gerencial',
        badgeText: 'Mensual',
      });
      barCard.classList.add('anim', 'anim-1');
      chartsRow.appendChild(barCard);

      /* Donut fuentes */
      const donutCard = ChartCard({
        title    : 'Origen de Leads',
        sub      : 'Por canal de captación',
        slotId   : 'slot-donut-gerencial',
        badgeText: `${Utils.formatNumber(g.fuentes?.reduce((s,d) => s + d.count, 0))} leads`,
        badgeClass: 'badge-info',
      });
      donutCard.classList.add('anim', 'anim-2');
      chartsRow.appendChild(donutCard);

      /* HBar ROI */
      const roiCard = ChartCard({
        title    : 'ROI por Canal',
        sub      : 'Retorno sobre inversión',
        slotId   : 'slot-roi-gerencial',
        badgeText: 'ROI %',
        badgeClass: 'badge-success',
      });
      roiCard.classList.add('anim', 'anim-3');
      chartsRow.appendChild(roiCard);

      /* Dibujar gráficas */
      requestAnimationFrame(() => {
        barChart(document.getElementById('slot-bar-gerencial'),    g.barras);
        donutChart(document.getElementById('slot-donut-gerencial'), g.fuentes);
        hBarChart(document.getElementById('slot-roi-gerencial'),   g.roiCanales, 'roi');
      });
    }

    /* ── Fila 3: Diagnóstico del Embudo ───────────────────────── */
    const gridDiag = document.getElementById('kpis-diagnostico');
    if (gridDiag && g.diagnostico) {
      gridDiag.innerHTML = '';
      const cards = g.diagnostico.map(d => MetricCard(d));
      animateItems(cards);
      cards.forEach(c => gridDiag.appendChild(c));
    }

    /* ── Fila 3: Salud Financiera ─────────────────────────────── */
    const gridFin = document.getElementById('kpis-financiera');
    if (gridFin && g.financiera) {
      gridFin.innerHTML = '';
      const cards = g.financiera.map(d => MetricCard(d));
      animateItems(cards);
      cards.forEach(c => gridFin.appendChild(c));
    }

    /* ── Fila 4: Tabla de Campañas ────────────────────────────── */
    const tableCont = document.getElementById('table-campanas');
    if (tableCont && g.campanas) {
      tableCont.innerHTML = '';
      const table = TableCard({
        title       : 'Campañas Activas',
        count       : g.campanas.length,
        viewAllUrl  : 'campanas.html',
        viewAllLabel: 'Ver todas →',
        tbodyId     : 'campanas-tbody',
        columns     : [
          { label: 'Campaña'     },
          { label: 'Canal'       },
          { label: 'Leads',      width: '80px' },
          { label: 'Conv. Rate', width: '140px' },
          { label: 'ROI',        width: '80px' },
          { label: 'Estado',     width: '100px' },
        ],
      });
      table.classList.add('anim', 'anim-1');
      tableCont.appendChild(table);

      const tbody = document.getElementById('campanas-tbody');
      if (tbody) tbody.innerHTML = g.campanas.map(buildCampanaRow).join('');
    }
  }


  /* ============================================================
     VISTA OPERATIVA
  ============================================================ */
  function operativa(data) {
    const o = data.operativa;

    /* ── Encabezado ──────────────────────────────────────────── */
    const hdr = document.getElementById('view-header-operativa');
    if (hdr) {
      const urgentes = o.tareas?.filter(t => t.urgencia === 'urgent').length ?? 0;
      hdr.innerHTML = `
        <h1 class="view-title">Vista Operativa</h1>
        <p class="view-sub">Hoy · ${o.tareas?.length ?? 0} acciones · ${urgentes} urgentes</p>
      `;
    }

    /* ── Fila 1: Acción Inmediata (4 KPIs) ───────────────────── */
    const gridOp = document.getElementById('kpis-operativa');
    if (gridOp && o.metricas) {
      gridOp.innerHTML = '';
      const cards = o.metricas.map(d => MetricCard(d));
      animateItems(cards);
      cards.forEach(c => gridOp.appendChild(c));
    }

    /* ── Fila 2: Charts operativos ────────────────────────────── */
    const chartsOp = document.getElementById('charts-operativa');
    if (chartsOp) {
      chartsOp.innerHTML = '';

      /* HBar funnel */
      const funnelCard = ChartCard({
        title    : 'Embudo de Ventas',
        sub      : 'Leads por etapa',
        slotId   : 'slot-funnel-op',
        badgeText: 'Operativo',
        badgeClass: 'badge-accent',
      });
      funnelCard.classList.add('anim', 'anim-1');
      chartsOp.appendChild(funnelCard);

      /* Donut temperatura */
      const totalTemp = o.temperatura?.reduce((s, d) => s + d.count, 0) ?? 0;
      const tempCard  = ChartCard({
        title    : 'Temperatura de Leads',
        sub      : 'Caliente / Tibio / Frío',
        slotId   : 'slot-temp-op',
        badgeText: `${Utils.formatNumber(totalTemp)} leads`,
        badgeClass: 'badge-warning',
      });
      tempCard.classList.add('anim', 'anim-2');
      chartsOp.appendChild(tempCard);

      requestAnimationFrame(() => {
        hBarChart(document.getElementById('slot-funnel-op'), o.funnel, 'funnel');
        donutChart(document.getElementById('slot-temp-op'),  o.temperatura);
      });
    }

    /* ── Fila 3: Tabla de Leads ───────────────────────────────── */
    const tableLeads = document.getElementById('table-leads');
    if (tableLeads && o.leads) {
      tableLeads.innerHTML = '';
      const table = TableCard({
        title       : 'Leads Recientes',
        count       : o.leads.length,
        viewAllUrl  : 'leads.html',
        viewAllLabel: 'Ver todos →',
        tbodyId     : 'leads-tbody',
        columns     : [
          { label: 'Lead'             },
          { label: 'Etapa',   width: '120px' },
          { label: 'Score',   width: '130px' },
          { label: 'Aging',   width: '70px'  },
          { label: 'Último contacto', width: '130px' },
          { label: 'Responsable'      },
        ],
      });
      table.classList.add('anim', 'anim-1');
      tableLeads.appendChild(table);

      const tbody = document.getElementById('leads-tbody');
      if (tbody) tbody.innerHTML = o.leads.map(buildLeadRow).join('');
    }

    /* ── Fila 4: Tareas del Día ───────────────────────────────── */
    const secTareas = document.getElementById('section-tareas');
    if (secTareas && o.tareas) {
      secTareas.innerHTML = '';

      const tasksCard = document.createElement('div');
      tasksCard.className = 'tasks-card anim anim-2';
      tasksCard.innerHTML = `
        <div class="tasks-header">
          <span class="tasks-title">Acciones del Día</span>
          <span class="table-count">${o.tareas.length}</span>
        </div>
        <ul class="tasks-list" id="tasks-list"></ul>
      `;
      secTareas.appendChild(tasksCard);

      const list = document.getElementById('tasks-list');
      if (list) {
        o.tareas.forEach(t => list.appendChild(AlertItem(t)));
      }
    }
  }


  /* ── Exponer API pública ──────────────────────────────────── */
  return { buildNav, gerencial, operativa };

})();

window.Render = Render;