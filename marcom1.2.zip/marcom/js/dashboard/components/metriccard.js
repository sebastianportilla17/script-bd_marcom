/* ================================================================
   MetricCard.js — Componente de Tarjeta de Métrica
   Retorna un HTMLElement <article class="metric-card">
   listo para insertar en el DOM. render.js lo llama.
================================================================ */
'use strict';

/**
 * MetricCard({ id, label, value, format, suffix, trend, trendDir,
 *              footer, color, icon, valueDanger })
 * @returns {HTMLElement}
 */
function MetricCard(data) {
  const {
    id          = '',
    label       = '',
    value       = 0,
    format      = 'integer',
    suffix      = '',
    trend       = '',
    trendDir    = 'info',
    footer      = '',
    color       = 'blue',
    icon        = 'bar-chart',
    valueDanger = false,
  } = data;

  /* Clase de color del borde superior e ícono */
  const colorMap = {
    blue  : { card: 'mc-blue',   icon: 'ic-blue'   },
    green : { card: 'mc-green',  icon: 'ic-green'  },
    orange: { card: 'mc-orange', icon: 'ic-orange' },
    red   : { card: 'mc-red',    icon: 'ic-red'    },
    purple: { card: 'mc-purple', icon: 'ic-purple' },
  };
  const colors = colorMap[color] ?? colorMap.blue;

  /* Clase del badge de tendencia */
  const trendMap = { up: 'tr-up', down: 'tr-down', warn: 'tr-warn', info: 'tr-info' };
  const trendClass = trendMap[trendDir] ?? 'tr-info';

  /* SVG del ícono */
  const iconSvg = (typeof ICONS !== 'undefined' && ICONS[icon])
    ? ICONS[icon]
    : ICONS?.['bar-chart'] ?? '';

  /* Formato inicial del valor para el placeholder */
  let displayValue = '';
  switch (format) {
    case 'currency': displayValue = Utils.formatCurrency(value, true); break;
    case 'percent' : displayValue = Number(value).toFixed(1) + '%';    break;
    case 'decimal' : displayValue = Number(value).toFixed(1);          break;
    default        : displayValue = Utils.formatNumber(value);
  }
  if (suffix) displayValue += ' ' + suffix;

  /* Construir el elemento */
  const article = document.createElement('article');
  article.className = `metric-card ${colors.card}`;
  article.id        = `mc-${id}`;

  article.innerHTML = `
    <div class="mc-top">
      <div class="mc-icon ${colors.icon}">
        ${iconSvg}
      </div>
      ${trend ? `<span class="mc-trend ${trendClass}">${trend}</span>` : ''}
    </div>

    <div class="mc-value${valueDanger ? ' val-danger' : ''}" id="mc-val-${id}">
      ${displayValue}
    </div>
    <div class="mc-label">${label}</div>

    ${footer ? `<div class="mc-footer">${footer}</div>` : ''}
  `;

  /* Animar el valor si es numérico y el format lo permite */
  requestAnimationFrame(() => {
    const valEl = article.querySelector(`#mc-val-${id}`);
    if (valEl && !isNaN(Number(value))) {
      Utils.counter(valEl, Number(value), 900, format);
      /* Si tiene suffix, actualizar tras el counter */
      if (suffix && format !== 'currency') {
        setTimeout(() => {
          if (valEl.textContent && !valEl.textContent.includes(suffix)) {
            valEl.textContent += ' ' + suffix;
          }
        }, 950);
      }
    }
  });

  return article;
}

window.MetricCard = MetricCard;