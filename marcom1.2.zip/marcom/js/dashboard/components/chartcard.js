/* ================================================================
   chartCard.js — Contenedor visual para gráficas
   Retorna <div class="card"> con header y .chart-slot vacío.
   Las funciones de charts/ dibujan dentro del slot por su id.
================================================================ */
'use strict';

/**
 * ChartCard({ id, title, sub, badgeText, badgeClass, slotId })
 * @returns {HTMLElement}
 */
function ChartCard({ id = '', title = '', sub = '', badgeText = '', badgeClass = 'badge-accent', slotId = '' } = {}) {
  const div = document.createElement('div');
  div.className = 'card';
  div.id        = id || undefined;

  div.innerHTML = `
    <div class="card-header">
      <div>
        <div class="card-title">${title}</div>
        ${sub ? `<div class="card-sub">${sub}</div>` : ''}
      </div>
      ${badgeText ? `<div class="card-header-right"><span class="badge ${badgeClass}">${badgeText}</span></div>` : ''}
    </div>
    <div class="chart-slot" id="${slotId}"></div>
  `;

  return div;
}

window.ChartCard = ChartCard;


/* ================================================================
   tableCard.js — Tarjeta de tabla con toolbar y scroll
================================================================ */

/**
 * TableCard({ title, count, viewAllUrl, viewAllLabel, columns, tbodyId })
 * @returns {HTMLElement}
 */
function TableCard({
  title        = '',
  count        = 0,
  viewAllUrl   = '#',
  viewAllLabel = 'Ver todos →',
  columns      = [],
  tbodyId      = '',
} = {}) {
  const div = document.createElement('div');
  div.className = 'table-card';

  const colHeaders = columns
    .map(col => `<th style="${col.width ? `width:${col.width}` : ''}">${col.label}</th>`)
    .join('');

  div.innerHTML = `
    <div class="table-toolbar">
      <span class="table-title">${title}</span>
      <span class="table-count">${count}</span>
      <div class="spacer"></div>
      <a href="${viewAllUrl}" class="btn-secondary btn-sm">${viewAllLabel}</a>
    </div>
    <div class="table-scroll">
      <table class="data-table">
        <thead>
          <tr>${colHeaders}</tr>
        </thead>
        <tbody id="${tbodyId}">
          <tr><td colspan="${columns.length}" style="text-align:center;padding:24px;color:var(--text-muted)">Cargando...</td></tr>
        </tbody>
      </table>
    </div>
  `;

  return div;
}

window.TableCard = TableCard;


/* ================================================================
   alertItem.js — Item de alerta / tarea del día
================================================================ */

/**
 * AlertItem({ urgencia, nombre, meta, hora })
 * urgencia: 'urgent' | 'normal' | 'ok'
 * @returns {HTMLElement}
 */
function AlertItem({ urgencia = 'normal', nombre = '', meta = '', hora = '' } = {}) {
  const urgMap = { urgent: 'td-urgent', normal: 'td-normal', ok: 'td-ok' };
  const cls    = urgMap[urgencia] ?? 'td-normal';

  const li = document.createElement('li');
  li.className = `task-item ${cls}`;

  li.innerHTML = `
    <span class="task-dot" aria-hidden="true"></span>
    <div class="task-body">
      <div class="task-name">${nombre}</div>
      ${meta ? `<div class="task-meta">${meta}</div>` : ''}
    </div>
    ${hora ? `<span class="task-time">${hora}</span>` : ''}
  `;

  return li;
}

window.AlertItem = AlertItem;