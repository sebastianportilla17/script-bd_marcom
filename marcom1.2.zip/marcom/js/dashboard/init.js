/* ================================================================
   events.js — Event Listeners del Dashboard MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Reescrito

   Centraliza TODOS los addEventListener del dashboard.
   Se ejecuta DESPUÉS de render.js para que los elementos existan.
================================================================ */
'use strict';

const Events = (() => {

  /* ── Toggle de vistas: Gerencial ↔ Operativa ─────────────── */
  function initViewToggle() {
    const btns = document.querySelectorAll('.vt-btn[data-view]');

    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.view;

        /* Actualizar botones */
        btns.forEach(b => {
          const active = b.dataset.view === target;
          b.classList.toggle('vt-active', active);
          b.setAttribute('aria-pressed', active ? 'true' : 'false');
        });

        /* Mostrar/ocultar secciones */
        document.querySelectorAll('.dashboard-view').forEach(view => {
          const show = view.id === `view-${target}`;
          view.classList.toggle('view-active', show);
          view.setAttribute('aria-hidden', show ? 'false' : 'true');
        });
      });
    });
  }


  /* ── Tema oscuro / claro ─────────────────────────────────── */
  function initThemeToggle() {
    document.getElementById('btn-dark')?.addEventListener('click', () => {
      if (typeof toggleDark === 'function') toggleDark();
    });
  }


  /* ── Sidebar móvil ───────────────────────────────────────── */
  function initMobileSidebar() {
    const btn     = document.getElementById('mob-menu-btn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sb-overlay');

    function openSidebar() {
      sidebar?.classList.add('sidebar-open');
      overlay?.classList.add('overlay-show');
      btn?.setAttribute('aria-expanded', 'true');
    }

    function closeSidebar() {
      sidebar?.classList.remove('sidebar-open');
      overlay?.classList.remove('overlay-show');
      btn?.setAttribute('aria-expanded', 'false');
    }

    btn?.addEventListener('click', openSidebar);
    overlay?.addEventListener('click', closeSidebar);

    /* Cerrar con Escape */
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeSidebar();
    });
  }


  /* ── Notificaciones ──────────────────────────────────────── */
  function initNotifBtn() {
    document.getElementById('btn-notif')?.addEventListener('click', () => {
      Utils.showToast('No hay notificaciones nuevas', 'info');
    });
  }


  /* ── Logout ──────────────────────────────────────────────── */
  function initLogout() {
    document.getElementById('btn-logout')?.addEventListener('click', () => {
      if (typeof Auth !== 'undefined') Auth.logout();
    });
  }


  /* ── Init: activa todos los listeners ───────────────────── */
  function init() {
    initViewToggle();
    initThemeToggle();
    initMobileSidebar();
    initNotifBtn();
    initLogout();
  }

  return { init };

})();

window.Events = Events;


/* ================================================================
   init.js — Director de Orquesta del Dashboard MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Reescrito

   Flujo:
   1. Verifica sesión activa (Auth.initProtectedPage)
   2. Muestra la fecha en el header
   3. Carga datos con getDashboardData()
   4. Construye el nav del sidebar
   5. Renderiza vista gerencial y operativa
   6. Activa todos los eventos
   7. Muestra toast de bienvenida
================================================================ */
'use strict';
window.addEventListener('load', async () => {
  /* ── 1. Verificar sesión ────────────────────────────────── */
  const user = (typeof Auth !== 'undefined')
    ? Auth.initProtectedPage()
    : null;

  /* Si no hay sesión, Auth ya redirigió al login */
  if (typeof Auth !== 'undefined' && !user) return;


  /* ── 2. Fecha en el header ──────────────────────────────── */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) {
    dateBadge.textContent = Utils.formatDate(new Date());
  }


  /* ── 3. Cargar datos ────────────────────────────────────── */
  let data;
  try {
    data = await getDashboardData();
  } catch (err) {
    console.error('[MARCOM] Error al cargar datos:', err);
    data = FALLBACK_DATA;
    Utils.showToast('Usando datos simulados', 'warning');
  }


  /* ── 4. Construir sidebar nav ───────────────────────────── */
  const leadsEnRiesgo = data?.operativa?.metricas?.find(m => m.id === 'en-riesgo')?.value ?? 0;
  Render.buildNav(leadsEnRiesgo);


  /* ── 5. Renderizar vistas ───────────────────────────────── */
  Render.gerencial(data);
  Render.operativa(data);


  /* ── 6. Activar eventos ─────────────────────────────────── */
  Events.init();


  /* ── 7. Punto rojo de notificaciones ────────────────────── */
  const enRiesgo = data?.operativa?.metricas?.find(m => m.id === 'en-riesgo')?.value ?? 0;
  if (enRiesgo > 0) {
    document.getElementById('notif-dot')?.classList.add('dot-active');
  }


  /* ── 8. Toast de bienvenida ─────────────────────────────── */
  const nombre = user?.name ?? 'Usuario';
  setTimeout(() => {
    Utils.showToast(`Bienvenido, ${nombre}. Dashboard listo.`, 'success', 3000);
  }, 600);

});