/* ================================================================
   config.js — Configuración Global del Dashboard MARCOM
   Módulo: Marketing y Comercial — ERP ADSO 3171727
   Versión: 1.0
   Descripción: Constantes, rutas de API, navegación y configuración
                global del dashboard. Nunca contiene lógica de negocio.
                Es el primer archivo que carga init.js.
   ================================================================ */


/* ================================================================
   1. ENTORNO
   Detecta si estamos en desarrollo o producción.
   En producción apunta a la API PHP real.
   En desarrollo usa los JSON simulados de /data/
   ================================================================ */

const ENV = {
  isDev:  window.location.hostname === 'localhost' ||
          window.location.hostname === '127.0.0.1',
};


/* ================================================================
   2. API
   URLs de los endpoints PHP.
   En desarrollo apunta a /data/*.json
   En producción apunta a /api/*.php
   Cuando conectes PHP solo cambias API_BASE a tu servidor real.
   ================================================================ */

const API_BASE = ENV.isDev
  ? '../data'       /* desarrollo — archivos JSON simulados */
  : '../api';       /* producción — endpoints PHP */

const API = {
  dashboard: `${API_BASE}/dashboard.json`,   /* en prod: dashboard.php */
  leads:     `${API_BASE}/leads.json`,
  campanas:  `${API_BASE}/campanas.json`,
  kpis:      `${API_BASE}/kpis.json`,
  eventos:   `${API_BASE}/eventos.json`,
  clientes:   `${API_BASE}/clientes.json`,
  

};


/* ================================================================
   3. NAVEGACIÓN
   Define todos los items del sidebar.
   render.js los usa para construir el nav dinámicamente.
   El campo "section" agrupa los items visualmente.
   El campo "badge" indica si muestra contador de notificaciones.
   ================================================================ */

const NAV_ITEMS = [

  /* Dashboard */
  {
    id:      'dashboard',
    label:   'Dashboard',
    icon:    'grid',
    url:     'dashboard.html',
    section: null,           /* sin sección — va primero solo */
    badge:   false,
  },

  /* ── Sección Comercial ──────────────────────────────────────── */
  {
    id:      'leads',
    label:   'Leads',
    icon:    'user',
    url:     'leads.html',
    section: 'Comercial',
    badge:   true,           /* muestra contador de leads sin atender */
  },
  {
    id:      'clientes',
    label:   'Clientes',
    icon:    'users',
    url:     'clientes.html',
    section: 'Comercial',
    badge:   false,
  },
  {
    id:      'pipeline',
    label:   'Embudo de Ventas',
    icon:    'trending-up',
    url:     'pipeline.html',
    section: 'Comercial',
    badge:   false,
  },

  /* ── Sección Marketing ──────────────────────────────────────── */
  {
    id:      'campanas',
    label:   'Campañas',
    icon:    'activity',
    url:     'campanas.html',
    section: 'Marketing',
    badge:   false,
  },
  {
    id:      'eventos',
    label:   'Eventos',
    icon:    'calendar',
    url:     'eventos.html',
    section: 'Marketing',
    badge:   false,
  },

  /* ── Sección Análisis ───────────────────────────────────────── */
  {
    id:      'kpis',
    label:   'Reportes KPI',
    icon:    'bar-chart',
    url:     'kpis.html',
    section: 'Análisis',
    badge:   false,
  },

  /* ── Sección Sistema ────────────────────────────────────────── */
  {
    id:      'configuracion',
    label:   'Configuración',
    icon:    'settings',
    url:     'configuracion.html',
    section: 'Sistema',
    badge:   false,
  },
];


/* ================================================================
   4. ICONOS SVG
   Mapa de iconos usado por el sidebar y los componentes.
   Centralizar los SVGs aquí evita repetirlos en cada componente.
   Para agregar un ícono nuevo: añade la clave y el path SVG.
   ================================================================ */

const ICONS = {

  /* Navegación */
  'grid': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
    <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
  </svg>`,

  'user': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <circle cx="12" cy="8" r="4"/>
    <path d="M6 20v-2a6 6 0 0 1 12 0v2"/>
  </svg>`,

  'users': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>`,

  'trending-up': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
  </svg>`,

  'activity': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
  </svg>`,

  'calendar': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
    <line x1="16" y1="2" x2="16" y2="6"/>
    <line x1="8" y1="2" x2="8" y2="6"/>
    <line x1="3" y1="10" x2="21" y2="10"/>
  </svg>`,

  'bar-chart': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="18" y1="20" x2="18" y2="10"/>
    <line x1="12" y1="20" x2="12" y2="4"/>
    <line x1="6" y1="20" x2="6" y2="14"/>
  </svg>`,

  'settings': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/>
  </svg>`,

  /* Métricas */
  'dollar': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="12" y1="1" x2="12" y2="23"/>
    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
  </svg>`,

  'check': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <polyline points="20 6 9 17 4 12"/>
  </svg>`,

  'phone': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
  </svg>`,

  'layers': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
    <path d="M2 17l10 5 10-5"/>
    <path d="M2 12l10 5 10-5"/>
  </svg>`,

  'file': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
  </svg>`,

  'alert': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <circle cx="12" cy="12" r="10"/>
    <line x1="12" y1="8" x2="12" y2="12"/>
    <line x1="12" y1="16" x2="12.01" y2="16"/>
  </svg>`,

  'brand': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
    stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"/>
    <line x1="12" y1="20" x2="12" y2="4"/>
    <line x1="6"  y1="20" x2="6"  y2="14"/>
  </svg>`,

  'logout': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
    <polyline points="16 17 21 12 16 7"/>
    <line x1="21" y1="12" x2="9" y2="12"/>
  </svg>`,

  'bell': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
    <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
  </svg>`,

  'sun': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1"  x2="12" y2="3"/>
    <line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1"  y1="12" x2="3"  y2="12"/>
    <line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
    <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
  </svg>`,

  'moon': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
  </svg>`,

  'menu': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="3"  y1="6"  x2="21" y2="6"/>
    <line x1="3"  y1="12" x2="21" y2="12"/>
    <line x1="3"  y1="18" x2="21" y2="18"/>
  </svg>`,
};


/* ================================================================
   5. PERÍODOS
   Opciones de filtro de período para las métricas.
   Futuro: el usuario podrá cambiar entre períodos desde el header.
   ================================================================ */

const PERIODS = [
  { id: 'semana',    label: 'Esta semana'    },
  { id: 'mes',       label: 'Este mes'       },
  { id: 'trimestre', label: 'Este trimestre' },
  { id: 'anio',      label: 'Este año'       },
];


/* ================================================================
   6. COLORES DE GRÁFICAS
   Paleta consistente para las visualizaciones.
   Siempre usar estos colores en las gráficas para mantener
   coherencia visual entre barChart, donutChart y hBarChart.
   ================================================================ */

const CHART_COLORS = [
  '#0057FF',   /* azul principal */
  '#00C48C',   /* verde éxito    */
  '#F79009',   /* naranja aviso  */
  '#7C3AED',   /* púrpura info   */
  '#94A3B8',   /* gris neutro    */
  '#F04438',   /* rojo peligro   */
];


/* ================================================================
   7. UMBRALES
   Valores límite para clasificar scores, aging y temperaturas.
   Cambiar aquí afecta automáticamente los colores de la tabla
   y los badges de los leads.
   ================================================================ */

const THRESHOLDS = {
  score: {
    high: 70,   /* score >= 70 → verde, lead caliente  */
    mid:  40,   /* score >= 40 → amarillo, lead tibio  */
                /* score <  40 → rojo, lead frío       */
  },
  aging: {
    ok:   5,    /* días <= 5  → verde, en tiempo       */
    warn: 12,   /* días <= 12 → amarillo, en riesgo    */
                /* días >  12 → rojo, estancado        */
  },
};