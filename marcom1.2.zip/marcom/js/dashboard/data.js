/* ================================================================
   data.js — Capa de Datos MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Reescrito

   Responsabilidades:
     · Intentar fetch al endpoint configurado en API.dashboard
     · Si falla (dev sin servidor / red caída) retornar FALLBACK_DATA
     · Exponer getDashboardData() como única función pública

   FALLBACK_DATA refleja exactamente la estructura que esperan
   render.js y todos los componentes. Cuando conectes PHP,
   tu API debe retornar este mismo formato JSON.
   ================================================================ */

'use strict';

/* ================================================================
   FALLBACK DATA — Datos simulados completos
   Estructura espejo de lo que retornará la API PHP.
   Período de referencia: Marzo 2026
================================================================ */
const FALLBACK_DATA = {

  meta: {
    periodo   : 'Marzo 2026',
    generado  : new Date().toISOString(),
    simulado  : true,
  },

  /* ============================================================
     VISTA GERENCIAL
  ============================================================ */
  gerencial: {

    /* ── Fila 1: Tendencias y Rendimiento (4 KPIs) ─────────── */
    tendencias: [
      {
        id      : 'total-leads',
        label   : 'Total Leads',
        value   : 1247,
        format  : 'integer',
        trend   : '+18.2%',
        trendDir: 'up',
        footer  : 'vs. período anterior: 1.054',
        color   : 'blue',
        icon    : 'user',
      },
      {
        id      : 'leads-nuevos',
        label   : 'Leads Nuevos',
        value   : 312,
        format  : 'integer',
        trend   : '+8.3%',
        trendDir: 'up',
        footer  : 'Captados en Marzo 2026',
        color   : 'green',
        icon    : 'trending-up',
      },
      {
        id      : 'conv-rate',
        label   : 'Tasa de Conversión',
        value   : 23.4,
        format  : 'percent',
        trend   : '+2.1%',
        trendDir: 'up',
        footer  : 'Meta del período: 25%',
        color   : 'purple',
        icon    : 'check',
      },
      {
        id      : 'revenue',
        label   : 'Revenue Generado',
        value   : 284500000,
        format  : 'currency',
        trend   : '+31.5%',
        trendDir: 'up',
        footer  : 'Meta: $ 250M · Superada ✓',
        color   : 'green',
        icon    : 'dollar',
      },
    ],

    /* ── Fila 2: Gráfica de barras — Leads vs Conversiones ─── */
    barras: [
      { mes: 'Oct', leads: 180, conv: 38 },
      { mes: 'Nov', leads: 210, conv: 51 },
      { mes: 'Dic', leads: 195, conv: 44 },
      { mes: 'Ene', leads: 240, conv: 58 },
      { mes: 'Feb', leads: 275, conv: 63 },
      { mes: 'Mar', leads: 312, conv: 74 },
    ],

    /* ── Fila 2: Donut — Fuentes de leads ──────────────────── */
    fuentes: [
      { name: 'Web Orgánico', count: 487, pct: 39, color: '#0057FF' },
      { name: 'Redes Sociales',count: 312, pct: 25, color: '#00C48C' },
      { name: 'Email Mkt',    count: 224, pct: 18, color: '#F79009' },
      { name: 'Referidos',    count: 137, pct: 11, color: '#7C3AED' },
      { name: 'Otros',        count:  87, pct:  7, color: '#94A3B8' },
    ],

    /* ── Fila 2: HBar — ROI por canal ──────────────────────── */
    roiCanales: [
      { canal: 'Email Mkt',      roi: 420, positivo: true  },
      { canal: 'Web Orgánico',   roi: 310, positivo: true  },
      { canal: 'Redes Sociales', roi: 185, positivo: true  },
      { canal: 'Referidos',      roi: 140, positivo: true  },
      { canal: 'Pauta Display',  roi: -45, positivo: false },
    ],

    /* ── Fila 3: Diagnóstico del Embudo (4 KPIs) ───────────── */
    diagnostico: [
      {
        id      : 'conv-rate-emb',
        label   : 'Conv. Rate Embudo',
        value   : 23.4,
        format  : 'percent',
        trend   : 'Meta: 25%',
        trendDir: 'info',
        footer  : '292 leads cerrados / 1.247 totales',
        color   : 'purple',
        icon    : 'layers',
      },
      {
        id      : 'tiempo-cierre',
        label   : 'Tiempo de Cierre',
        value   : 18,
        format  : 'integer',
        suffix  : 'días',
        trend   : '-3 días',
        trendDir: 'up',
        footer  : 'Promedio histórico: 21 días',
        color   : 'blue',
        icon    : 'calendar',
      },
      {
        id      : 'leads-perdidos',
        label   : 'Leads Perdidos',
        value   : 87,
        format  : 'integer',
        trend   : 'Motivo: precio',
        trendDir: 'warn',
        footer  : '6.9% del total · vs 8.1% anterior',
        color   : 'orange',
        icon    : 'alert',
      },
      {
        id      : 'leads-activos-g',
        label   : 'En Pipeline',
        value   : 868,
        format  : 'integer',
        trend   : 'activos',
        trendDir: 'info',
        footer  : '69.6% del total de leads',
        color   : 'blue',
        icon    : 'activity',
      },
    ],

    /* ── Fila 3: Salud Financiera (4 KPIs) ─────────────────── */
    financiera: [
      {
        id      : 'cpa',
        label   : 'CPA',
        value   : 185000,
        format  : 'currency',
        trend   : '-12%',
        trendDir: 'up',
        footer  : 'Costo por adquisición. Meta: < $200K',
        color   : 'green',
        icon    : 'dollar',
      },
      {
        id      : 'pipeline-value',
        label   : 'Pipeline Value',
        value   : 1840000000,
        format  : 'currency',
        trend   : '+24%',
        trendDir: 'up',
        footer  : 'Valor potencial de leads activos',
        color   : 'blue',
        icon    : 'layers',
      },
      {
        id      : 'valor-cliente',
        label   : 'Valor por Cliente',
        value   : 975000,
        format  : 'currency',
        trend   : '+8.5%',
        trendDir: 'up',
        footer  : 'Revenue promedio / cliente nuevo',
        color   : 'purple',
        icon    : 'dollar',
      },
      {
        id      : 'roi-campanas',
        label   : 'ROI Campañas',
        value   : 284,
        format  : 'percent',
        trend   : '+41pts',
        trendDir: 'up',
        footer  : 'vs período anterior: 243%',
        color   : 'green',
        icon    : 'trending-up',
      },
    ],

    /* ── Fila 4: Tabla Campañas ─────────────────────────────── */
    campanas: [
      {
        id       : 'c001',
        nombre   : 'Black Friday Digital',
        canal    : 'Email + Display',
        leads    : 198,
        conv     : 47,
        convRate : 23.7,
        roi      : 385,
        estado   : 'activa',
        inversion: 4200000,
      },
      {
        id       : 'c002',
        nombre   : 'LinkedIn B2B Q1',
        canal    : 'Redes Sociales',
        leads    : 124,
        conv     : 31,
        convRate : 25.0,
        roi      : 210,
        estado   : 'activa',
        inversion: 3800000,
      },
      {
        id       : 'c003',
        nombre   : 'SEO Orgánico Blog',
        canal    : 'Web Orgánico',
        leads    : 312,
        conv     : 68,
        convRate : 21.8,
        roi      : 540,
        estado   : 'activa',
        inversion: 1500000,
      },
      {
        id       : 'c004',
        nombre   : 'Referidos Partner',
        canal    : 'Referidos',
        leads    : 87,
        conv     : 29,
        convRate : 33.3,
        roi      : 680,
        estado   : 'activa',
        inversion:  900000,
      },
      {
        id       : 'c005',
        nombre   : 'Display Programático',
        canal    : 'Pauta Display',
        leads    : 246,
        conv     : 18,
        convRate :  7.3,
        roi      : -45,
        estado   : 'pausada',
        inversion: 6200000,
      },
    ],
  },

  /* ============================================================
     VISTA OPERATIVA
  ============================================================ */
  operativa: {

    /* ── Fila 1: Acción Inmediata (4 KPIs) ─────────────────── */
    metricas: [
      {
        id      : 'leads-activos',
        label   : 'Leads Activos',
        value   : 868,
        format  : 'integer',
        trend   : 'en funnel',
        trendDir: 'info',
        footer  : 'Excluye ganados y perdidos',
        color   : 'blue',
        icon    : 'layers',
      },
      {
        id      : 'sin-contacto',
        label   : 'Sin Contacto Hoy',
        value   : 34,
        format  : 'integer',
        trend   : '⚠ atención',
        trendDir: 'warn',
        footer  : 'Superaron el umbral de días',
        color   : 'orange',
        icon    : 'phone',
      },
      {
        id      : 'en-riesgo',
        label   : 'En Riesgo',
        value   : 12,
        format  : 'integer',
        trend   : '🔴 urgente',
        trendDir: 'down',
        footer  : 'Próximos a expirar hoy',
        color   : 'red',
        icon    : 'alert',
        valueDanger: true,
      },
      {
        id      : 'tareas-hoy',
        label   : 'Tareas Pendientes',
        value   : 21,
        format  : 'integer',
        trend   : 'para hoy',
        trendDir: 'info',
        footer  : '8 urgentes · 13 normales',
        color   : 'purple',
        icon    : 'file',
      },
    ],

    /* ── Fila 2: HBar — Embudo de ventas por etapa ──────────── */
    funnel: [
      { etapa: 'Prospecto',    leads: 287, color: '#94A3B8' },
      { etapa: 'Calificado',   leads: 198, color: '#0057FF' },
      { etapa: 'Propuesta',    leads: 154, color: '#7C3AED' },
      { etapa: 'Negociación',  leads:  98, color: '#F79009' },
      { etapa: 'Cierre',       leads:  62, color: '#00C48C' },
      { etapa: 'Ganado',       leads:  69, color: '#00A76F' },
    ],

    /* ── Fila 2: Donut — Temperatura de leads ───────────────── */
    temperatura: [
      { name: 'Caliente',  count: 287, pct: 33, color: '#F04438' },
      { name: 'Tibio',     count: 389, pct: 45, color: '#F79009' },
      { name: 'Frío',      count: 192, pct: 22, color: '#94A3B8' },
    ],

    /* ── Fila 3: Tabla de Leads Recientes ───────────────────── */
    leads: [
      {
        id         : 'l001',
        nombre     : 'Carlos Mendoza',
        empresa    : 'TechCorp S.A.',
        etapa      : 'Negociación',
        score      : 88,
        aging      : 3,
        ultimoContacto: '2026-03-07',
        responsable: 'Ana Torres',
      },
      {
        id         : 'l002',
        nombre     : 'Laura Jiménez',
        empresa    : 'Innovatech',
        etapa      : 'Propuesta',
        score      : 72,
        aging      : 7,
        ultimoContacto: '2026-03-05',
        responsable: 'Pedro Ruiz',
      },
      {
        id         : 'l003',
        nombre     : 'Roberto Silva',
        empresa    : 'Grupo Alfa',
        etapa      : 'Calificado',
        score      : 55,
        aging      : 11,
        ultimoContacto: '2026-03-01',
        responsable: 'Ana Torres',
      },
      {
        id         : 'l004',
        nombre     : 'Marcela Ríos',
        empresa    : 'Soluciones XYZ',
        etapa      : 'Prospecto',
        score      : 38,
        aging      : 16,
        ultimoContacto: '2026-02-22',
        responsable: 'Luis Mora',
      },
      {
        id         : 'l005',
        nombre     : 'Felipe Vargas',
        empresa    : 'Distribuidora Sur',
        etapa      : 'Cierre',
        score      : 91,
        aging      : 2,
        ultimoContacto: '2026-03-08',
        responsable: 'Pedro Ruiz',
      },
      {
        id         : 'l006',
        nombre     : 'Diana Castillo',
        empresa    : 'Construcciones Norte',
        etapa      : 'Propuesta',
        score      : 64,
        aging      : 9,
        ultimoContacto: '2026-03-03',
        responsable: 'Luis Mora',
      },
    ],

    /* ── Fila 4: Tareas del Día ─────────────────────────────── */
    tareas: [
      {
        urgencia: 'urgent',
        nombre  : 'Llamar a Felipe Vargas',
        meta    : 'Distribuidora Sur · Cierre pendiente firma',
        hora    : '09:00',
      },
      {
        urgencia: 'urgent',
        nombre  : 'Enviar propuesta a TechCorp',
        meta    : 'Carlos Mendoza · Revisión final de contrato',
        hora    : '10:30',
      },
      {
        urgencia: 'urgent',
        nombre  : 'Follow-up Marcela Ríos',
        meta    : 'Soluciones XYZ · 16 días sin contacto 🔴',
        hora    : '11:00',
      },
      {
        urgencia: 'normal',
        nombre  : 'Reunión con Laura Jiménez',
        meta    : 'Innovatech · Presentación de propuesta',
        hora    : '14:00',
      },
      {
        urgencia: 'normal',
        nombre  : 'Actualizar pipeline semanal',
        meta    : 'Revisión de etapas y scores',
        hora    : '16:00',
      },
      {
        urgencia: 'ok',
        nombre  : 'Revisar métricas de campaña',
        meta    : 'Display Programático · analizar pausa',
        hora    : '17:30',
      },
    ],
  },
};


/* ================================================================
   getDashboardData()
   Intenta fetch al endpoint configurado en API.dashboard.
   Si el fetch falla o devuelve error → retorna FALLBACK_DATA.
   Siempre retorna una Promise que resuelve con los datos.
================================================================ */
async function getDashboardData() {
  try {
    /* En dev: ENV.isDev = true → apunta a ../data/dashboard.json
       En prod: apunta a ../api/dashboard.php               */
    const endpoint = (typeof API !== 'undefined' && API.dashboard)
      ? API.dashboard
      : '../data/dashboard.json';

    const res = await fetch(endpoint, { cache: 'no-store' });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    return data;

  } catch (err) {
    /* En desarrollo es normal que no haya servidor.
       En producción este warning ayuda a diagnosticar. */
    console.warn('[MARCOM] getDashboardData: usando datos simulados.', err.message);
    return FALLBACK_DATA;
  }
}

/* ── Exponer globalmente ──────────────────────────────────────── */
window.getDashboardData = getDashboardData;
window.FALLBACK_DATA    = FALLBACK_DATA;