/* ================================================================
   data.js — Capa de Datos · Clientes
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   ================================================================ */
'use strict';

const CLIENTES_FALLBACK = {
  meta: { periodo: 'Marzo 2026', simulado: true },

  kpis: [
    { id:'total-clientes',   label:'Total Clientes',       value:348,         format:'integer',  trend:'+12',    trendDir:'up',   footer:'vs. mes anterior: 336',          color:'blue',   icon:'users'       },
    { id:'clientes-activos', label:'Clientes Activos',     value:291,         format:'integer',  trend:'83.6%',  trendDir:'up',   footer:'Con compra en últimos 90 días',  color:'green',  icon:'check'       },
    { id:'valor-total',      label:'Valor Acumulado',      value:4820000000,  format:'currency', trend:'+24.1%', trendDir:'up',   footer:'Revenue total generado',         color:'purple', icon:'dollar'      },
    { id:'promedio-compra',  label:'Promedio por Cliente', value:13850000,    format:'currency', trend:'+8.3%',  trendDir:'up',   footer:'Ticket promedio histórico',      color:'orange', icon:'trending-up' },
  ],

  clientes: [
    {
      id:'c001', nombre:'Carlos Mendoza',   empresa:'TechCorp S.A.',       ciudad:'Bogotá',       email:'c.mendoza@techcorp.co',     telefono:'3001234567', cargo:'Gerente de Compras',
      industria:'Tecnología',  tamano:'Grande',   segmentos:['Referido','Caliente','Grande'],
      valor:48500000,  ultimaCompra:'2026-03-07', numFacturas:12, estado:'activo',   responsable:'Ana Torres',  fecCreacion:'2024-06-15', fuente:'Referido',
      actividad:[
        { tipo:'compra',  desc:'Factura #2341 — $12.500.000',       fecha:'2026-03-07' },
        { tipo:'llamada', desc:'Llamada de seguimiento post-venta',  fecha:'2026-03-02' },
        { tipo:'email',   desc:'Envío propuesta renovación anual',   fecha:'2026-02-20' },
        { tipo:'reunion', desc:'Reunión revisión Q1',                fecha:'2026-02-10' },
      ],
    },
    {
      id:'c002', nombre:'Laura Jiménez',    empresa:'Innovatech',          ciudad:'Medellín',     email:'l.jimenez@innovatech.co',   telefono:'3119876543', cargo:'Directora Financiera',
      industria:'Consultoría', tamano:'Mediana',  segmentos:['Email','Tibio','Mediana'],
      valor:22750000,  ultimaCompra:'2026-03-05', numFacturas:7,  estado:'activo',   responsable:'Pedro Ruiz', fecCreacion:'2024-09-22', fuente:'Email Mkt',
      actividad:[
        { tipo:'compra',  desc:'Factura #2339 — $8.200.000',         fecha:'2026-03-05' },
        { tipo:'email',   desc:'Respuesta a propuesta de servicios',  fecha:'2026-02-28' },
        { tipo:'llamada', desc:'Llamada aclaración de contrato',      fecha:'2026-02-15' },
      ],
    },
    {
      id:'c003', nombre:'Roberto Silva',    empresa:'Grupo Alfa',          ciudad:'Cali',         email:'r.silva@grupoalfa.com',     telefono:'3205551234', cargo:'CEO',
      industria:'Manufactura', tamano:'Grande',   segmentos:['Redes Sociales','Caliente','Grande'],
      valor:95000000,  ultimaCompra:'2026-02-28', numFacturas:24, estado:'activo',   responsable:'Ana Torres',  fecCreacion:'2023-03-10', fuente:'LinkedIn',
      actividad:[
        { tipo:'compra',  desc:'Factura #2330 — $22.000.000',  fecha:'2026-02-28' },
        { tipo:'reunion', desc:'Revisión contrato anual',       fecha:'2026-02-20' },
        { tipo:'email',   desc:'Informe de rendimiento Q4',     fecha:'2026-01-30' },
      ],
    },
    {
      id:'c004', nombre:'Marcela Ríos',     empresa:'Soluciones XYZ',      ciudad:'Barranquilla', email:'m.rios@solucionesxyz.co',   telefono:'3154449876', cargo:'Jefe de Operaciones',
      industria:'Logística',   tamano:'Pequeña',  segmentos:['Búsqueda Orgánica','Frío','Pequeña'],
      valor:8400000,   ultimaCompra:'2026-01-15', numFacturas:3,  estado:'inactivo', responsable:'Luis Mora',   fecCreacion:'2025-01-08', fuente:'Web Orgánico',
      actividad:[
        { tipo:'compra',  desc:'Factura #2290 — $3.200.000',           fecha:'2026-01-15' },
        { tipo:'llamada', desc:'Intento de contacto sin respuesta',     fecha:'2026-01-20' },
      ],
    },
    {
      id:'c005', nombre:'Felipe Vargas',    empresa:'Distribuidora Sur',   ciudad:'Bogotá',       email:'f.vargas@distrisur.co',     telefono:'3007778899', cargo:'Gerente Comercial',
      industria:'Distribución',tamano:'Mediana',  segmentos:['Referido','Caliente','Mediana'],
      valor:37200000,  ultimaCompra:'2026-03-08', numFacturas:9,  estado:'activo',   responsable:'Pedro Ruiz', fecCreacion:'2024-11-03', fuente:'Referido',
      actividad:[
        { tipo:'compra',  desc:'Factura #2342 — $9.800.000',      fecha:'2026-03-08' },
        { tipo:'reunion', desc:'Cierre contrato Q2 2026',          fecha:'2026-03-05' },
        { tipo:'email',   desc:'Envío orden de compra confirmada', fecha:'2026-02-28' },
      ],
    },
    {
      id:'c006', nombre:'Diana Castillo',   empresa:'Construcciones Norte', ciudad:'Bucaramanga', email:'d.castillo@consnorte.co',   telefono:'3103336655', cargo:'Directora de Proyectos',
      industria:'Construcción',tamano:'Grande',   segmentos:['Email','Tibio','Grande'],
      valor:61000000,  ultimaCompra:'2026-02-14', numFacturas:15, estado:'activo',   responsable:'Luis Mora',   fecCreacion:'2023-08-20', fuente:'Email Mkt',
      actividad:[
        { tipo:'compra',  desc:'Factura #2318 — $14.500.000',      fecha:'2026-02-14' },
        { tipo:'llamada', desc:'Negociación descuento por volumen', fecha:'2026-02-05' },
        { tipo:'reunion', desc:'Presentación nuevos productos',     fecha:'2026-01-25' },
      ],
    },
    {
      id:'c007', nombre:'Andrés Mora',      empresa:'FinServ Colombia',    ciudad:'Bogotá',       email:'a.mora@finserv.co',         telefono:'3012223344', cargo:'VP de Finanzas',
      industria:'Finanzas',    tamano:'Grande',   segmentos:['LinkedIn','Caliente','Grande'],
      valor:128000000, ultimaCompra:'2026-03-01', numFacturas:31, estado:'activo',   responsable:'Ana Torres',  fecCreacion:'2022-11-14', fuente:'LinkedIn',
      actividad:[
        { tipo:'compra',  desc:'Factura #2335 — $28.000.000',    fecha:'2026-03-01' },
        { tipo:'reunion', desc:'Revisión estrategia anual 2026', fecha:'2026-02-22' },
        { tipo:'email',   desc:'Informe de ROI campaña Q4',      fecha:'2026-02-10' },
      ],
    },
    {
      id:'c008', nombre:'Valentina Cruz',   empresa:'Retail Express',      ciudad:'Medellín',     email:'v.cruz@retailexpress.co',   telefono:'3148889900', cargo:'Gerente de Marketing',
      industria:'Retail',      tamano:'Mediana',  segmentos:['Redes Sociales','Tibio','Mediana'],
      valor:19500000,  ultimaCompra:'2026-02-20', numFacturas:5,  estado:'activo',   responsable:'Pedro Ruiz', fecCreacion:'2025-02-14', fuente:'Instagram',
      actividad:[
        { tipo:'compra', desc:'Factura #2325 — $6.500.000',        fecha:'2026-02-20' },
        { tipo:'email',  desc:'Cotización campaña primavera 2026',  fecha:'2026-02-15' },
      ],
    },
  ],
};

async function getClientesData() {
  try {
    const endpoint = (typeof API !== 'undefined' && API.clientes)
      ? API.clientes
      : '../data/clientes.json';
    const res = await fetch(endpoint, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[MARCOM] getClientesData: usando datos simulados.', err.message);
    return CLIENTES_FALLBACK;
  }
}

window.getClientesData   = getClientesData;
window.CLIENTES_FALLBACK = CLIENTES_FALLBACK;