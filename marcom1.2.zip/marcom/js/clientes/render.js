/* ================================================================
   render.js — Renderizado · Clientes
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   ================================================================ */
'use strict';

const ClientesRender = (() => {

  /* ── Colores del avatar ── */
  const AV_COLORS = ['av-blue','av-green','av-purple','av-orange','av-teal','av-pink','av-red'];
  function avColor(name = '') {
    let h = 0;
    for (let i = 0; i < name.length; i++) h += name.charCodeAt(i);
    return AV_COLORS[h % AV_COLORS.length];
  }
  function initials(name = '') {
    const p = name.trim().split(/\s+/);
    return p.length >= 2 ? (p[0][0]+p[1][0]).toUpperCase() : name.slice(0,2).toUpperCase();
  }

  /* ── KPIs ─────────────────────────────────────────────────── */
  function buildKPIs(kpis) {
    const grid = document.getElementById('kpis-clientes');
    if (!grid) return;
    grid.innerHTML = '';

    const colorMap = {
      blue  : { card:'mc-blue',   icon:'ic-blue'   },
      green : { card:'mc-green',  icon:'ic-green'  },
      purple: { card:'mc-purple', icon:'ic-purple' },
      orange: { card:'mc-orange', icon:'ic-orange' },
    };
    const trendMap = { up:'tr-up', down:'tr-down', warn:'tr-warn', info:'tr-info' };
    const iconSvgs = {
      users        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
      check        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>`,
      dollar       : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`,
      'trending-up': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
    };

    kpis.forEach((d, i) => {
      const c  = colorMap[d.color] ?? colorMap.blue;
      const tc = trendMap[d.trendDir] ?? 'tr-info';
      let displayValue = '';
      if (d.format === 'currency') displayValue = formatCurrency(d.value);
      else if (d.format === 'percent') displayValue = Number(d.value).toFixed(1) + '%';
      else displayValue = formatNumber(d.value);

      const art = document.createElement('article');
      art.className = `metric-card ${c.card} anim anim-${i+1}`;
      art.innerHTML = `
        <div class="mc-top">
          <div class="mc-icon ${c.icon}">${iconSvgs[d.icon] ?? ''}</div>
          ${d.trend ? `<span class="mc-trend ${tc}">${d.trend}</span>` : ''}
        </div>
        <div class="mc-value" id="kpi-val-${d.id}">${displayValue}</div>
        <div class="mc-label">${d.label}</div>
        ${d.footer ? `<div class="mc-footer">${d.footer}</div>` : ''}
      `;
      grid.appendChild(art);

      /* Animar contador */
      requestAnimationFrame(() => {
        const el = document.getElementById(`kpi-val-${d.id}`);
        if (el && !isNaN(Number(d.value))) animCounter(el, d.value, d.format);
      });
    });
  }

  function formatCurrency(v) {
    if (Math.abs(v) >= 1e9) return `$ ${(v/1e9).toFixed(1)}B`;
    if (Math.abs(v) >= 1e6) return `$ ${(v/1e6).toFixed(0)}M`;
    if (Math.abs(v) >= 1e3) return `$ ${(v/1e3).toFixed(0)}K`;
    return '$ ' + Math.round(v).toLocaleString('es-CO');
  }
  function formatNumber(v) {
    return Math.round(v).toLocaleString('es-CO');
  }
  function animCounter(el, target, format, dur = 900) {
    const start = performance.now();
    const step = now => {
      const p = Math.min((now-start)/dur, 1);
      const e = 1 - Math.pow(2, -10*p);
      const cur = target * e;
      if (format === 'currency') el.textContent = formatCurrency(cur);
      else if (format === 'percent') el.textContent = cur.toFixed(1) + '%';
      else el.textContent = formatNumber(cur);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* ── Tabla ────────────────────────────────────────────────── */
  function buildTable(clientes) {
    const tbody  = document.getElementById('clientes-tbody');
    const count  = document.getElementById('tabla-count');
    if (!tbody) return;

    if (count) count.textContent = clientes.length;

    if (!clientes.length) {
      tbody.innerHTML = `
        <tr><td colspan="8">
          <div class="table-empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
            </svg>
            <p>No se encontraron clientes</p>
          </div>
        </td></tr>`;
      return;
    }

    tbody.innerHTML = clientes.map(c => buildRow(c)).join('');
  }

  function buildRow(c) {
    const av  = avColor(c.nombre);
    const ini = initials(c.nombre);
    const estadoBadge = c.estado === 'activo'
      ? '<span class="badge badge-success">Activo</span>'
      : '<span class="badge badge-neutral">Inactivo</span>';

    const chips = c.segmentos.slice(0, 2)
      .map(s => `<span class="seg-chip">${s}</span>`).join('');

    const valor = `$ ${(c.valor/1e6).toFixed(1)}M`;
    const fecha = new Date(c.ultimaCompra + 'T00:00:00').toLocaleDateString('es-CO',{ day:'2-digit', month:'short', year:'numeric' });
    const respIni = initials(c.responsable);
    const respAv  = avColor(c.responsable);

    return `
      <tr data-id="${c.id}" class="cliente-row">
        <td class="col-check">
          <input type="checkbox" class="row-checkbox" data-id="${c.id}" aria-label="Seleccionar ${c.nombre}"/>
        </td>
        <td>
          <div class="cliente-cell">
            <div class="avatar ${av}">${ini}</div>
            <div>
              <div class="cliente-name">${c.nombre}</div>
              <div class="cliente-email">${c.cargo}</div>
            </div>
          </div>
        </td>
        <td class="t-sm t-second">${c.empresa}</td>
        <td class="t-sm t-muted">${c.ciudad}</td>
        <td><div class="seg-chips">${chips}</div></td>
        <td><span class="valor-cell">${valor}</span></td>
        <td><span class="fecha-cell">${fecha}</span></td>
        <td>${estadoBadge}</td>
        <td>
          <div class="resp-cell">
            <div class="avatar ${respAv}" style="width:26px;height:26px;font-size:.62rem">${respIni}</div>
            <span class="resp-name">${c.responsable}</span>
          </div>
        </td>
        <td>
          <div class="row-actions">
            <button class="row-btn rb-view btn-open-drawer" data-id="${c.id}" title="Ver resumen">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            </button>
            <button class="row-btn rb-edit" data-id="${c.id}" title="Editar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
          </div>
        </td>
      </tr>`;
  }

  /* ── Drawer ───────────────────────────────────────────────── */
  function openDrawer(cliente) {
    const drawer  = document.getElementById('cliente-drawer');
    const overlay = document.getElementById('drawer-overlay');
    if (!drawer || !overlay) return;

    /* Avatar */
    const av  = avColor(cliente.nombre);
    const ini = initials(cliente.nombre);
    document.getElementById('d-avatar').className    = `drawer-avatar ${av}`;
    document.getElementById('d-avatar').textContent  = ini;
    document.getElementById('d-nombre').textContent  = cliente.nombre;
    document.getElementById('d-empresa').textContent = `${cliente.empresa} · ${cliente.ciudad}`;

    /* Stats */
    const valor = `$ ${(cliente.valor/1e6).toFixed(1)}M`;
    document.getElementById('d-valor').textContent    = valor;
    document.getElementById('d-facturas').textContent = cliente.numFacturas;
    const fechaUlt = new Date(cliente.ultimaCompra+'T00:00:00').toLocaleDateString('es-CO',{day:'2-digit',month:'short'});
    document.getElementById('d-ultima').textContent  = fechaUlt;

    /* Estado badge */
    const estadoEl = document.getElementById('d-estado');
    estadoEl.className = cliente.estado === 'activo' ? 'badge badge-success' : 'badge badge-neutral';
    estadoEl.textContent = cliente.estado === 'activo' ? 'Activo' : 'Inactivo';

    /* Resumen */
    const infoList = document.getElementById('d-info-list');
    infoList.innerHTML = [
      ['Email',      cliente.email],
      ['Teléfono',   cliente.telefono],
      ['Cargo',      cliente.cargo],
      ['Industria',  cliente.industria],
      ['Tamaño',     cliente.tamano],
      ['Fuente',     cliente.fuente],
      ['Responsable',cliente.responsable],
      ['Cliente desde', new Date(cliente.fecCreacion+'T00:00:00').toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'})],
    ].map(([lbl,val]) => `
      <div class="info-row">
        <span class="info-lbl">${lbl}</span>
        <span class="info-val">${val}</span>
      </div>`).join('');

    /* Segmentos */
    const segEl = document.getElementById('d-segmentos');
    segEl.innerHTML = cliente.segmentos
      .map(s => `<span class="seg-chip">${s}</span>`).join('');

    /* Actividad */
    const actEl = document.getElementById('d-actividad');
    const actIcons = {
      compra  : { cls:'ai-compra',   svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>` },
      llamada : { cls:'ai-llamada',  svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 1h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>` },
      email   : { cls:'ai-email',   svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>` },
      reunion : { cls:'ai-reunion', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>` },
      whatsapp: { cls:'ai-whatsapp',svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>` },
    };

    actEl.innerHTML = cliente.actividad.map(a => {
      const ic = actIcons[a.tipo] ?? actIcons.email;
      const f  = new Date(a.fecha+'T00:00:00').toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
      return `
        <div class="activity-item">
          <div class="act-icon-wrap">
            <div class="act-icon ${ic.cls}">${ic.svg}</div>
            <div class="act-line"></div>
          </div>
          <div class="act-content">
            <div class="act-desc">${a.desc}</div>
            <div class="act-date">${f}</div>
          </div>
        </div>`;
    }).join('');

    /* Link perfil completo */
    const linkPerfil = document.getElementById('btn-ver-perfil');
    if (linkPerfil) linkPerfil.href = `cliente-perfil.html?id=${cliente.id}`;

    /* Abrir */
    overlay.classList.add('drawer-overlay-show');
    drawer.classList.add('drawer-open');
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer() {
    document.getElementById('cliente-drawer')?.classList.remove('drawer-open');
    document.getElementById('drawer-overlay')?.classList.remove('drawer-overlay-show');
    document.body.style.overflow = '';
  }

  return { buildKPIs, buildTable, openDrawer, closeDrawer, initials, avColor };
})();

window.ClientesRender = ClientesRender;