/* ================================================================
   cliente-perfil-init.js — Lógica del perfil individual
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Flujo:
   1. Lee ?id= de la URL
   2. Carga datos con getClientesData()
   3. Encuentra el cliente por id
   4. Renderiza header, info, KPIs, timeline, campañas, eventos
   ================================================================ */
'use strict';

/* ── Helpers ────────────────────────────────────────────────── */
const AV_COLORS = ['av-blue','av-green','av-purple','av-orange','av-teal','av-pink','av-red'];
function avColor(name = '') {
  let h = 0;
  for (let i = 0; i < name.length; i++) h += name.charCodeAt(i);
  return AV_COLORS[h % AV_COLORS.length];
}
function initials(name = '') {
  const p = name.trim().split(/\s+/);
  return p.length >= 2 ? (p[0][0]+p[1][0]).toUpperCase() : name.slice(0,2).toUpperCase();
}
function fmt$(v) {
  if (Math.abs(v) >= 1e9) return `$ ${(v/1e9).toFixed(1)}B`;
  if (Math.abs(v) >= 1e6) return `$ ${(v/1e6).toFixed(1)}M`;
  if (Math.abs(v) >= 1e3) return `$ ${(v/1e3).toFixed(0)}K`;
  return '$ ' + Math.round(v).toLocaleString('es-CO');
}
function fmtDate(str, style='long') {
  if (!str) return '—';
  const d = new Date(str + 'T00:00:00');
  if (style === 'short') return d.toLocaleDateString('es-CO',{day:'2-digit',month:'short'});
  return d.toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
}

/* ── CAMPAÑAS Y EVENTOS simulados por cliente ───────────────── */
const CAMPANAS_MOCK = {
  c001: [
    { nombre:'Black Friday Digital', canal:'Email + Display', estado:'activa',  fecha:'2025-11-01' },
    { nombre:'LinkedIn B2B Q1',      canal:'Redes Sociales',  estado:'activa',  fecha:'2026-01-10' },
  ],
  c002: [
    { nombre:'SEO Orgánico Blog',    canal:'Web Orgánico',    estado:'activa',  fecha:'2025-09-15' },
  ],
  c003: [
    { nombre:'Referidos Partner',    canal:'Referidos',       estado:'activa',  fecha:'2025-06-01' },
    { nombre:'Black Friday Digital', canal:'Email + Display', estado:'cerrada', fecha:'2025-11-01' },
  ],
  c005: [
    { nombre:'Referidos Partner',    canal:'Referidos',       estado:'activa',  fecha:'2024-12-01' },
  ],
  c007: [
    { nombre:'LinkedIn B2B Q1',      canal:'Redes Sociales',  estado:'activa',  fecha:'2026-01-10' },
    { nombre:'SEO Orgánico Blog',    canal:'Web Orgánico',    estado:'activa',  fecha:'2025-09-15' },
    { nombre:'Black Friday Digital', canal:'Email + Display', estado:'cerrada', fecha:'2025-11-01' },
  ],
};

const EVENTOS_MOCK = {
  c001: [{ nombre:'Webinar Transformación Digital Q1', fecha:'2026-02-15', estado:'Asistió'  }],
  c003: [{ nombre:'Feria Industrial Medellín 2025',    fecha:'2025-10-08', estado:'Asistió'  }],
  c006: [{ nombre:'Lanzamiento Suite Pro 2026',        fecha:'2026-01-20', estado:'Confirmado'}],
  c007: [
    { nombre:'Webinar Transformación Digital Q1', fecha:'2026-02-15', estado:'Asistió'   },
    { nombre:'Cumbre Fintech Bogotá 2025',        fecha:'2025-11-20', estado:'Asistió'   },
  ],
};

/* ── Iconos de actividad ─────────────────────────────────────── */
const ACT_ICONS = {
  compra  : { cls:'ti-compra',  svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`,                    label:'Compra'   },
  llamada : { cls:'ti-llamada', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`, label:'Llamada'  },
  email   : { cls:'ti-email',   svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`, label:'Email'    },
  reunion : { cls:'ti-reunion', svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`, label:'Reunión'  },
  nota    : { cls:'ti-nota',    svg:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`, label:'Nota'     },
};

/* ── Sidebar nav ─────────────────────────────────────────────── */
function buildNav() {
  const nav = document.getElementById('sb-nav');
  if (!nav || typeof NAV_ITEMS === 'undefined') return;
  nav.innerHTML = '';
  let section = null;
  const page  = 'clientes.html'; /* perfil = sub-página de clientes */
  NAV_ITEMS.forEach(item => {
    if (item.section !== section) {
      section = item.section;
      if (item.section) {
        const lbl = document.createElement('div');
        lbl.className   = 'sb-section-label';
        lbl.textContent = item.section;
        nav.appendChild(lbl);
      }
    }
    const active  = page === item.url;
    const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
    const a = document.createElement('a');
    a.className = `sb-item${active ? ' active' : ''}`;
    a.href      = item.url;
    a.innerHTML = `<span class="sb-item-icon">${iconSvg}</span><span class="sb-item-label">${item.label}</span>`;
    nav.appendChild(a);
  });
}

/* ── Render header ───────────────────────────────────────────── */
function renderHeader(c) {
  const av  = avColor(c.nombre);
  const ini = initials(c.nombre);

  /* Avatar */
  const avEl = document.getElementById('ph-avatar');
  avEl.className   = `ph-avatar ${av}`;
  avEl.textContent = ini;

  /* Status dot */
  const dot = document.getElementById('ph-status-dot');
  dot.className = `ph-status-dot ${c.estado === 'activo' ? 'psd-activo' : 'psd-inactivo'}`;

  /* Info */
  document.getElementById('ph-name').textContent    = c.nombre;
  document.getElementById('ph-cargo').textContent   = c.cargo;
  document.getElementById('ph-empresa').textContent = c.empresa;
  document.getElementById('ph-ciudad').textContent  = c.ciudad;

  /* Badges */
  const badgesEl = document.getElementById('ph-badges');
  const estadoBadge = c.estado === 'activo'
    ? '<span class="badge badge-success">Activo</span>'
    : '<span class="badge badge-neutral">Inactivo</span>';
  badgesEl.innerHTML = estadoBadge + c.segmentos.map(s =>
    `<span class="badge badge-accent">${s}</span>`).join('');

  /* KPIs del header */
  document.getElementById('ph-valor').textContent    = fmt$(c.valor);
  document.getElementById('ph-facturas').textContent = c.numFacturas;
  document.getElementById('ph-resp').textContent     = c.responsable;

  /* Título de página */
  document.title = `${c.nombre} · MARCOM`;
}

/* ── Render info general ─────────────────────────────────────── */
function renderInfo(c) {
  const el = document.getElementById('info-grid');
  if (!el) return;

  el.innerHTML = `
    <div class="info-section-title">Datos Personales</div>

    <div class="info-field">
      <span class="if-label">Nombre completo</span>
      <span class="if-value">${c.nombre}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Cargo</span>
      <span class="if-value">${c.cargo}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Email</span>
      <span class="if-value"><a href="mailto:${c.email}">${c.email}</a></span>
    </div>
    <div class="info-field">
      <span class="if-label">Teléfono</span>
      <span class="if-value"><a href="tel:${c.telefono}">${c.telefono}</a></span>
    </div>

    <div class="info-divider"></div>
    <div class="info-section-title">Empresa</div>

    <div class="info-field">
      <span class="if-label">Empresa</span>
      <span class="if-value">${c.empresa}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Industria</span>
      <span class="if-value">${c.industria}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Tamaño</span>
      <span class="if-value">${c.tamano}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Ciudad</span>
      <span class="if-value">${c.ciudad}</span>
    </div>

    <div class="info-divider"></div>
    <div class="info-section-title">Origen</div>

    <div class="info-field">
      <span class="if-label">Fuente</span>
      <span class="if-value">${c.fuente}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Responsable</span>
      <span class="if-value">${c.responsable}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Cliente desde</span>
      <span class="if-value">${fmtDate(c.fecCreacion)}</span>
    </div>
    <div class="info-field">
      <span class="if-label">Estado</span>
      <span class="if-value">${c.estado === 'activo' ? '✅ Activo' : '⚫ Inactivo'}</span>
    </div>
  `;
}

/* ── Render KPIs ─────────────────────────────────────────────── */
function renderKPIs(c) {
  const el = document.getElementById('kpis-grid');
  if (!el) return;

  /* Días desde última compra */
  const diasDesde = Math.floor((Date.now() - new Date(c.ultimaCompra+'T00:00:00')) / 86400000);
  const ticketProm = c.numFacturas > 0 ? c.valor / c.numFacturas : 0;

  el.innerHTML = `
    <div class="kpi-mini">
      <span class="km-label">Valor Total</span>
      <span class="km-value kmv-green" id="kpi-valor">${fmt$(c.valor)}</span>
      <span class="km-sub">Revenue acumulado</span>
    </div>
    <div class="kpi-mini">
      <span class="km-label">Facturas</span>
      <span class="km-value kmv-blue" id="kpi-facturas">${c.numFacturas}</span>
      <span class="km-sub">Compras realizadas</span>
    </div>
    <div class="kpi-mini">
      <span class="km-label">Ticket Promedio</span>
      <span class="km-value kmv-purple" id="kpi-ticket">${fmt$(ticketProm)}</span>
      <span class="km-sub">Por factura</span>
    </div>
    <div class="kpi-mini">
      <span class="km-label">Última Compra</span>
      <span class="km-value ${diasDesde > 60 ? 'kmv-orange' : ''}">${diasDesde}d</span>
      <span class="km-sub">${fmtDate(c.ultimaCompra)}</span>
    </div>
  `;
}

/* ── Render Timeline ─────────────────────────────────────────── */
function renderTimeline(c) {
  const el = document.getElementById('timeline');
  if (!el || !c.actividad?.length) {
    el.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <p>Sin actividad registrada</p>
      </div>`;
    return;
  }

  el.innerHTML = c.actividad.map(a => {
    const ic = ACT_ICONS[a.tipo] ?? ACT_ICONS.nota;
    return `
      <div class="tl-item">
        <div class="tl-left">
          <div class="tl-icon ${ic.cls}">${ic.svg}</div>
          <div class="tl-line"></div>
        </div>
        <div class="tl-right">
          <div class="tl-title">${a.desc}</div>
          <span class="tl-badge tb-${a.tipo}">${ic.label}</span>
          <div class="tl-date">${fmtDate(a.fecha)}</div>
        </div>
      </div>`;
  }).join('');
}

/* ── Render Campañas & Eventos ───────────────────────────────── */
function renderCampanas(clienteId) {
  const el = document.getElementById('campanas-list');
  if (!el) return;

  const camps  = CAMPANAS_MOCK[clienteId] ?? [];
  const events = EVENTOS_MOCK[clienteId]  ?? [];

  if (!camps.length && !events.length) {
    el.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
        </svg>
        <p>Sin campañas ni eventos asociados</p>
      </div>`;
    return;
  }

  const campHTML = camps.map(cp => {
    const estadoBadge = cp.estado === 'activa'
      ? '<span class="badge badge-success">Activa</span>'
      : '<span class="badge badge-neutral">Cerrada</span>';
    return `
      <div class="campaign-item">
        <div class="ci-icon cii-camp">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
          </svg>
        </div>
        <div class="ci-info">
          <div class="ci-name">${cp.nombre}</div>
          <div class="ci-meta">${cp.canal} · ${fmtDate(cp.fecha, 'short')}</div>
        </div>
        <div class="ci-badge">${estadoBadge}</div>
      </div>`;
  }).join('');

  const evtHTML = events.map(ev => {
    const estadoBadge = ev.estado === 'Asistió'
      ? '<span class="badge badge-success">Asistió</span>'
      : '<span class="badge badge-warning">Confirmado</span>';
    return `
      <div class="campaign-item">
        <div class="ci-icon cii-event">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="4" width="18" height="18" rx="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/>
            <line x1="8"  y1="2" x2="8"  y2="6"/>
            <line x1="3"  y1="10" x2="21" y2="10"/>
          </svg>
        </div>
        <div class="ci-info">
          <div class="ci-name">${ev.nombre}</div>
          <div class="ci-meta">Evento · ${fmtDate(ev.fecha, 'short')}</div>
        </div>
        <div class="ci-badge">${estadoBadge}</div>
      </div>`;
  }).join('');

  el.innerHTML = campHTML + evtHTML;
}

/* ── Render Segmentación ─────────────────────────────────────── */
function renderSegmentos(c) {
  const el = document.getElementById('seg-chips');
  if (!el) return;
  const tagIcons = {
    'Referido'         : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
    'Caliente'         : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2c0 0-4 4-4 8a4 4 0 0 0 8 0c0-4-4-8-4-8z"/></svg>`,
    'Tibio'            : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/></svg>`,
    'Frío'             : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 7l-5-5-5 5"/><path d="M17 17l-5 5-5-5"/><line x1="2" y1="12" x2="22" y2="12"/></svg>`,
    'Grande'           : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>`,
    'Mediana'          : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>`,
    'Pequeña'          : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>`,
  };
  el.innerHTML = c.segmentos.map(s => `
    <span class="seg-chip-lg">
      ${tagIcons[s] ?? ''}
      ${s}
    </span>`).join('');
}

/* ── Notas rápidas ───────────────────────────────────────────── */
function initNotas() {
  const btn      = document.getElementById('btn-guardar-nota');
  const textarea = document.getElementById('nota-textarea');
  const list     = document.getElementById('notas-list');

  btn?.addEventListener('click', () => {
    const txt = textarea?.value.trim();
    if (!txt) return;
    const now = new Date().toLocaleDateString('es-CO',{day:'2-digit',month:'short',year:'numeric'});
    const item = document.createElement('div');
    item.className = 'tl-item';
    item.innerHTML = `
      <div class="tl-left">
        <div class="tl-icon ti-nota">${ACT_ICONS.nota.svg}</div>
        <div class="tl-line"></div>
      </div>
      <div class="tl-right">
        <div class="tl-title">${txt}</div>
        <span class="tl-badge" style="background:var(--bg-2);color:var(--text-muted)">Nota</span>
        <div class="tl-date">${now}</div>
      </div>`;
    list?.prepend(item);
    textarea.value = '';
    if (typeof Utils !== 'undefined') Utils.showToast('Nota guardada', 'success', 2000);
  });
}

/* ════════════════════════════════════════════════════════════════
   INIT PRINCIPAL
════════════════════════════════════════════════════════════════ */
window.addEventListener('load', async () => {

  /* 1. Sesión */
  let user = null;
  if (typeof Auth !== 'undefined') {
    user = Auth.initProtectedPage();
    if (!user) return;
  }

  /* 2. Fecha */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) {
    dateBadge.textContent = new Date().toLocaleDateString('es-CO',{
      weekday:'short', day:'numeric', month:'short', year:'numeric'
    });
  }

  /* 3. Leer ?id= de la URL */
  const params    = new URLSearchParams(location.search);
  const clienteId = params.get('id') ?? 'c001'; /* fallback al primero */

  /* 4. Cargar datos */
  let data;
  try { data = await getClientesData(); }
  catch { data = window.CLIENTES_FALLBACK; }

  const cliente = data.clientes?.find(c => c.id === clienteId)
    ?? data.clientes?.[0];

  if (!cliente) {
    document.getElementById('main-content').innerHTML =
      '<p style="padding:40px;color:var(--text-muted)">Cliente no encontrado.</p>';
    return;
  }

  /* 5. Nav */
  buildNav();

  /* 6. Renderizar todo */
  renderHeader(cliente);
  renderInfo(cliente);
  renderKPIs(cliente);
  renderTimeline(cliente);
  renderCampanas(cliente.id);
  renderSegmentos(cliente);
  initNotas();

  /* 7. Eventos globales */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark === 'function') toggleDark();
  });
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('Sin notificaciones nuevas', 'info');
  });
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    if (typeof Auth !== 'undefined') Auth.logout();
  });

  /* Sidebar móvil */
  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const sbOv    = document.getElementById('sb-overlay');
  mobBtn?.addEventListener('click',  () => { sidebar?.classList.toggle('sidebar-open'); sbOv?.classList.toggle('overlay-show'); });
  sbOv?.addEventListener('click',    () => { sidebar?.classList.remove('sidebar-open'); sbOv?.classList.remove('overlay-show'); });

  /* Acciones del header */
  document.getElementById('btn-email')?.addEventListener('click', () =>
    Utils?.showToast(`Email enviado a ${cliente.email}`, 'success'));
  document.getElementById('btn-call')?.addEventListener('click', () =>
    Utils?.showToast(`Llamando a ${cliente.telefono}...`, 'info'));
  document.getElementById('btn-nota')?.addEventListener('click', () => {
    document.getElementById('nota-textarea')?.focus();
    document.getElementById('nota-textarea')?.scrollIntoView({ behavior:'smooth', block:'center' });
  });

});