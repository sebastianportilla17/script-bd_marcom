/* ================================================================
   init.js — Director de orquesta · Clientes
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   ================================================================ */
'use strict';

/* ── Estado local ───────────────────────────────────────────── */
let ALL_CLIENTES  = [];
let selectedIds   = new Set();
let sortCol       = 'valor';
let sortDir       = 'desc';
let currentFilter = { search:'', estado:'', tamano:'', responsable:'' };

/* ── Helpers ────────────────────────────────────────────────── */
function formatCurrency(v) {
  if (Math.abs(v) >= 1e9) return `$ ${(v/1e9).toFixed(1)}B`;
  if (Math.abs(v) >= 1e6) return `$ ${(v/1e6).toFixed(1)}M`;
  return '$ ' + Math.round(v).toLocaleString('es-CO');
}

/* ── Filtrar + ordenar ──────────────────────────────────────── */
function applyFilters() {
  let list = [...ALL_CLIENTES];
  const { search, estado, tamano, responsable } = currentFilter;

  if (search) {
    const q = search.toLowerCase();
    list = list.filter(c =>
      c.nombre.toLowerCase().includes(q)   ||
      c.empresa.toLowerCase().includes(q)  ||
      c.ciudad.toLowerCase().includes(q)   ||
      c.email.toLowerCase().includes(q)
    );
  }
  if (estado)      list = list.filter(c => c.estado === estado);
  if (tamano)      list = list.filter(c => c.tamano === tamano);
  if (responsable) list = list.filter(c => c.responsable === responsable);

  /* Ordenar */
  list.sort((a, b) => {
    let va = a[sortCol], vb = b[sortCol];
    if (typeof va === 'string') { va = va.toLowerCase(); vb = vb.toLowerCase(); }
    if (va < vb) return sortDir === 'asc' ? -1 :  1;
    if (va > vb) return sortDir === 'asc' ?  1 : -1;
    return 0;
  });

  return list;
}

function rerender() {
  ClientesRender.buildTable(applyFilters());
  bindRowEvents();
  updateSortIcons();
  syncBulkBar();
  selectedIds.clear();
  document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = false);
  document.getElementById('select-all')?.checked && (document.getElementById('select-all').checked = false);
}

function updateSortIcons() {
  document.querySelectorAll('.th-sortable').forEach(th => {
    th.classList.remove('sort-asc','sort-desc');
    if (th.dataset.col === sortCol) th.classList.add(sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
  });
}

/* ── Sidebar nav ────────────────────────────────────────────── */
function buildNav() {
  const nav = document.getElementById('sb-nav');
  if (!nav || typeof NAV_ITEMS === 'undefined') return;
  nav.innerHTML = '';
  let section = null;
  const page  = location.pathname.split('/').pop() || 'index.html';
  NAV_ITEMS.forEach(item => {
    if (item.section !== section) {
      section = item.section;
      if (item.section) {
        const lbl = document.createElement('div');
        lbl.className   = 'sb-section-label';
        lbl.textContent = item.section;
        nav.appendChild(lbl);
      }
    }
    const active  = page === item.url;
    const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
    const a = document.createElement('a');
    a.className = `sb-item${active ? ' active' : ''}`;
    a.href      = item.url;
    a.innerHTML = `
      <span class="sb-item-icon">${iconSvg}</span>
      <span class="sb-item-label">${item.label}</span>`;
    nav.appendChild(a);
  });
}

/* ── Bulk bar ────────────────────────────────────────────────── */
function syncBulkBar() {
  const bar = document.getElementById('bulk-bar');
  if (!bar) return;
  const n = selectedIds.size;
  if (n > 0) {
    bar.classList.add('bulk-visible');
    document.getElementById('bulk-count').textContent =
      `${n} cliente${n !== 1 ? 's' : ''} seleccionado${n !== 1 ? 's' : ''}`;
  } else {
    bar.classList.remove('bulk-visible');
  }
}

/* ── Eventos de filas ────────────────────────────────────────── */
function bindRowEvents() {
  /* Abrir drawer al hacer click en la fila (pero no en checkbox ni botones) */
  document.querySelectorAll('.cliente-row').forEach(tr => {
    tr.addEventListener('click', e => {
      if (e.target.closest('.row-checkbox,.row-actions')) return;
      const id  = tr.dataset.id;
      const cli = ALL_CLIENTES.find(c => c.id === id);
      if (cli) ClientesRender.openDrawer(cli);
    });
  });

  /* Botón de ver drawer explícito */
  document.querySelectorAll('.btn-open-drawer').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const id  = btn.dataset.id;
      const cli = ALL_CLIENTES.find(c => c.id === id);
      if (cli) ClientesRender.openDrawer(cli);
    });
  });

  /* Checkboxes de fila */
  document.querySelectorAll('.row-checkbox').forEach(cb => {
    cb.addEventListener('change', () => {
      const id = cb.dataset.id;
      const tr = cb.closest('tr');
      if (cb.checked) { selectedIds.add(id); tr?.classList.add('row-selected'); }
      else            { selectedIds.delete(id); tr?.classList.remove('row-selected'); }
      syncBulkBar();

      /* Sync select-all */
      const all    = document.querySelectorAll('.row-checkbox');
      const allSel = document.getElementById('select-all');
      if (allSel) allSel.checked = selectedIds.size === all.length && all.length > 0;
    });
  });
}

/* ── Modal nuevo cliente ─────────────────────────────────────── */
function openModal() {
  const overlay = document.getElementById('modal-overlay');
  overlay?.classList.add('modal-show');
  document.body.style.overflow = 'hidden';
  document.getElementById('form-nombre')?.focus();
}
function closeModal() {
  document.getElementById('modal-overlay')?.classList.remove('modal-show');
  document.body.style.overflow = '';
}

/* ── Exportar CSV simple ─────────────────────────────────────── */
function exportCSV() {
  const list = applyFilters();
  const headers = ['Nombre','Empresa','Ciudad','Valor','Última Compra','Estado','Responsable'];
  const rows    = list.map(c => [
    c.nombre, c.empresa, c.ciudad,
    formatCurrency(c.valor), c.ultimaCompra, c.estado, c.responsable
  ]);
  const csv = [headers, ...rows].map(r => r.map(v => `"${v}"`).join(',')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type:'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `clientes_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  if (typeof Utils !== 'undefined') Utils.showToast('CSV exportado correctamente', 'success');
}

/* ── Llenar filtro de responsables ──────────────────────────── */
function populateFilters(clientes) {
  const sel = document.getElementById('filter-responsable');
  if (!sel) return;
  const responsables = [...new Set(clientes.map(c => c.responsable))].sort();
  responsables.forEach(r => {
    const opt = document.createElement('option');
    opt.value = r; opt.textContent = r;
    sel.appendChild(opt);
  });
}

/* ── INIT PRINCIPAL ──────────────────────────────────────────── */
window.addEventListener('load', async () => {

  /* 1. Sesión */
  let user = null;
  if (typeof Auth !== 'undefined') {
    user = Auth.initProtectedPage();
    if (!user) return;
  }

  /* 2. Fecha */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) {
    dateBadge.textContent = new Date().toLocaleDateString('es-CO',{
      weekday:'short', day:'numeric', month:'short', year:'numeric'
    });
  }

  /* 3. Datos */
  let data;
  try {
    data = await getClientesData();
  } catch {
    data = window.CLIENTES_FALLBACK;
  }

  ALL_CLIENTES = data.clientes ?? [];

  /* 4. Nav */
  buildNav();

  /* 5. KPIs */
  ClientesRender.buildKPIs(data.kpis ?? []);

  /* 6. Tabla */
  populateFilters(ALL_CLIENTES);
  rerender();

  /* 7. Subtítulo */
  const sub = document.getElementById('page-sub');
  if (sub) sub.textContent = `${ALL_CLIENTES.length} clientes registrados · ${data.meta?.periodo ?? ''}`;

  /* 8. Eventos ─────────────────────────────────────── */

  /* Search */
  document.getElementById('search-clientes')?.addEventListener('input', e => {
    currentFilter.search = e.target.value.trim();
    rerender();
  });

  /* Filtros select */
  document.getElementById('filter-estado')?.addEventListener('change', e => {
    currentFilter.estado = e.target.value; rerender();
  });
  document.getElementById('filter-tamano')?.addEventListener('change', e => {
    currentFilter.tamano = e.target.value; rerender();
  });
  document.getElementById('filter-responsable')?.addEventListener('change', e => {
    currentFilter.responsable = e.target.value; rerender();
  });

  /* Ordenar columnas */
  document.querySelectorAll('.th-sortable').forEach(th => {
    th.addEventListener('click', () => {
      const col = th.dataset.col;
      if (sortCol === col) sortDir = sortDir === 'asc' ? 'desc' : 'asc';
      else { sortCol = col; sortDir = 'asc'; }
      rerender();
    });
  });

  /* Select all */
  document.getElementById('select-all')?.addEventListener('change', e => {
    const checked = e.target.checked;
    document.querySelectorAll('.row-checkbox').forEach(cb => {
      cb.checked = checked;
      const tr = cb.closest('tr');
      const id = cb.dataset.id;
      if (checked) { selectedIds.add(id); tr?.classList.add('row-selected'); }
      else          { selectedIds.delete(id); tr?.classList.remove('row-selected'); }
    });
    syncBulkBar();
  });

  /* Nuevo cliente */
  document.getElementById('btn-nuevo-cliente')?.addEventListener('click', openModal);
  document.getElementById('modal-close')?.addEventListener('click', closeModal);
  document.getElementById('modal-overlay')?.addEventListener('click', e => {
    if (e.target.id === 'modal-overlay') closeModal();
  });
  document.getElementById('btn-cancelar')?.addEventListener('click', closeModal);
  document.getElementById('btn-guardar')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('Cliente guardado correctamente', 'success');
    closeModal();
  });

  /* Exportar */
  document.getElementById('btn-exportar')?.addEventListener('click', exportCSV);

  /* Deselect bulk */
  document.getElementById('btn-bulk-deselect')?.addEventListener('click', () => {
    selectedIds.clear();
    document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = false);
    document.querySelectorAll('.row-selected').forEach(tr => tr.classList.remove('row-selected'));
    document.getElementById('select-all')?.checked && (document.getElementById('select-all').checked = false);
    syncBulkBar();
  });

  /* Drawer cerrar */
  document.getElementById('drawer-close-btn')?.addEventListener('click', ClientesRender.closeDrawer);
  document.getElementById('drawer-overlay')?.addEventListener('click', ClientesRender.closeDrawer);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      ClientesRender.closeDrawer();
      closeModal();
    }
  });

  /* Sidebar móvil */
  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const sbOv    = document.getElementById('sb-overlay');
  mobBtn?.addEventListener('click', () => {
    sidebar?.classList.toggle('sidebar-open');
    sbOv?.classList.toggle('overlay-show');
  });
  sbOv?.addEventListener('click', () => {
    sidebar?.classList.remove('sidebar-open');
    sbOv?.classList.remove('overlay-show');
  });

  /* Tema */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark === 'function') toggleDark();
  });

  /* Notificaciones */
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('No hay notificaciones nuevas', 'info');
  });

  /* Logout */
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    if (typeof Auth !== 'undefined') Auth.logout();
  });

  /* 9. Toast bienvenida */
  setTimeout(() => {
    if (typeof Utils !== 'undefined')
      Utils.showToast(`${ALL_CLIENTES.length} clientes cargados`, 'success', 2500);
  }, 600);

});