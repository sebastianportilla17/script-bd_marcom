/* ================================================================
   js/kpis/init.js — Director de Orquesta del Módulo KPI
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Flujo:
   1. Verifica sesión activa (Auth.initProtectedPage)
   2. Muestra la fecha en el header
   3. Construye el nav del sidebar
   4. Carga datos del período por defecto ('mes')
   5. Renderiza todos los bloques
   6. Activa el toggle de período (mes | trimestre | anio)
   7. Toast de bienvenida
================================================================ */
'use strict';

window.addEventListener('load', async () => {

  /* ── 1. Verificar sesión ────────────────────────────────── */
  const user = (typeof Auth !== 'undefined')
    ? Auth.initProtectedPage()
    : null;
  if (typeof Auth !== 'undefined' && !user) return;


  /* ── 2. Fecha en el header ──────────────────────────────── */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge && typeof Utils !== 'undefined') {
    dateBadge.textContent = Utils.formatDate(new Date());
  }


  /* ── 3. Sidebar nav ─────────────────────────────────────── */
  KpiRender.buildNav();


  /* ── 4. Cargar y renderizar período por defecto ──────────── */
  let currentPeriodo = 'mes';
  await loadAndRender(currentPeriodo);


  /* ── 5. Toggle de período ────────────────────────────────── */
  document.querySelectorAll('.period-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const periodo = btn.dataset.period;
      if (periodo === currentPeriodo) return;

      /* Actualizar botones activos */
      document.querySelectorAll('.period-btn').forEach(b => {
        b.classList.toggle('period-active', b.dataset.period === periodo);
      });

      currentPeriodo = periodo;
      await loadAndRender(periodo);
    });
  });


  /* ── 6. Notificaciones ───────────────────────────────────── */
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('No hay notificaciones nuevas', 'info');
  });


  /* ── 7. Tema oscuro ─────────────────────────────────────── */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark === 'function') toggleDark();
  });


  /* ── 8. Sidebar móvil ────────────────────────────────────── */
  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sb-overlay');

  function openSidebar()  { sidebar?.classList.add('sidebar-open');    overlay?.classList.add('overlay-show');    mobBtn?.setAttribute('aria-expanded','true');  }
  function closeSidebar() { sidebar?.classList.remove('sidebar-open'); overlay?.classList.remove('overlay-show'); mobBtn?.setAttribute('aria-expanded','false'); }

  mobBtn?.addEventListener('click', openSidebar);
  overlay?.addEventListener('click', closeSidebar);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSidebar(); });


  /* ── 9. Toast de bienvenida ─────────────────────────────── */
  const nombre = user?.name ?? 'Usuario';
  setTimeout(() => {
    if (typeof Utils !== 'undefined') {
      Utils.showToast(`KPIs cargados · Período: ${nombre}`, 'success', 2800);
    }
  }, 700);

});


/* ================================================================
   loadAndRender(periodo)
   Carga los datos del período y dispara el renderizado completo.
   Muestra un estado de carga mientras el fetch está en vuelo.
================================================================ */
async function loadAndRender(periodo) {
  /* Feedback visual: vaciar contadores mientras carga */
  document.querySelectorAll('.ec-value').forEach(el => {
    el.textContent = '—';
  });

  let data;
  try {
    data = await getKpiData(periodo);
  } catch (err) {
    console.error('[MARCOM] Error al cargar KPIs:', err);
    data = FALLBACK_KPI_DATA.periodos[periodo];
    data.meta = FALLBACK_KPI_DATA.meta;
    if (typeof Utils !== 'undefined') Utils.showToast('Usando datos simulados', 'warning');
  }

  /* Actualizar sub del page-header */
  const pageSub = document.getElementById('page-sub');
  if (pageSub && data.label) {
    pageSub.textContent = `Indicadores clave · ${data.label}`;
  }

  KpiRender.all(data);
}