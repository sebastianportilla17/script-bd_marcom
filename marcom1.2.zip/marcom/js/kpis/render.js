/* ================================================================
   js/kpis/render.js — Ensamblador del Módulo KPI
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Responsabilidades:
     · Renderizar todos los bloques del módulo KPI con datos reales
     · Animar contadores con Utils.counter()
     · Pintar funnel, tablas, cards de canales y gestión comercial
     · Exponer KpiRender.all(data) como punto de entrada
================================================================ */
'use strict';

const KpiRender = (() => {

  /* ============================================================
     HELPERS PRIVADOS
  ============================================================ */

  /** Añade clases de animación escalonada */
  function stagger(elements) {
    elements.forEach((el, i) => {
      el.classList.add('anim', `anim-${Math.min(i + 1, 6)}`);
    });
  }

  /** Icono SVG inline para tarjetas ejecutivas */
  function getIcon(name) {
    if (typeof ICONS !== 'undefined' && ICONS[name]) return ICONS[name];
    return '';
  }

  /** Clase de color de avatar determinista */
  function avColor(name) {
    if (typeof Utils !== 'undefined') return Utils.avatarColor(name);
    const colors = ['av-blue','av-green','av-purple','av-orange','av-teal'];
    let h = 0; for (const c of name) h += c.charCodeAt(0);
    return colors[h % colors.length];
  }

  /** Iniciales */
  function ini(name) {
    if (typeof Utils !== 'undefined') return Utils.initials(name);
    const p = name.trim().split(/\s+/);
    return p.length >= 2 ? (p[0][0] + p[1][0]).toUpperCase() : name.slice(0,2).toUpperCase();
  }

  /** Formato moneda compacto */
  function fmt(value, format) {
    if (typeof Utils === 'undefined') return String(value);
    switch (format) {
      case 'currency': return Utils.formatCurrency(value, true);
      case 'percent' : return value.toFixed(1) + '%';
      default        : return Utils.formatNumber(value);
    }
  }

  /** % seguro evitando división por cero */
  function pct(a, b) {
    if (!b) return 0;
    return Math.min(Math.round((a / b) * 100), 100);
  }

  /** Badge de estado campaña */
  function estadoBadge(estado) {
    const map = { activa: 'badge-success', pausada: 'badge-warning', borrador: 'badge-neutral', finalizada: 'badge-neutral' };
    return `<span class="badge ${map[estado] ?? 'badge-neutral'}">${estado}</span>`;
  }


  /* ============================================================
     BLOQUE 1 — KPIs EJECUTIVOS
  ============================================================ */
  function renderEjecutivos(data) {
    const grid = document.getElementById('exec-kpis-grid');
    if (!grid || !data.ejecutivos) return;

    grid.innerHTML = '';

    data.ejecutivos.forEach((d, i) => {
      const card = document.createElement('article');
      card.className = `exec-card ec-${d.color} anim anim-${Math.min(i+1,6)}`;

      const trendClass = { up: 'et-up', down: 'et-down', warn: 'et-warn', info: 'et-info' }[d.trendDir] ?? 'et-info';
      const isDanger   = d.id === 'en-riesgo' ? 'val-danger' : '';

      card.innerHTML = `
        <div class="ec-top">
          <span class="ec-label">${d.label}</span>
          <span class="ec-trend ${trendClass}">${d.trend}</span>
        </div>
        <div class="ec-value ${isDanger}" id="ecv-${d.id}">—</div>
        <div class="ec-footer">${d.footer}</div>
        <div class="ec-bg-icon" aria-hidden="true">${getIcon(d.icon)}</div>
      `;

      grid.appendChild(card);

      /* Animar contador */
      requestAnimationFrame(() => {
        const el = document.getElementById(`ecv-${d.id}`);
        if (el && typeof Utils !== 'undefined') {
          Utils.counter(el, d.value, 900, d.format);
        } else if (el) {
          el.textContent = fmt(d.value, d.format);
        }
      });
    });

    /* Actualizar sub del bloque */
    const sub = document.getElementById('bloque1-sub');
    if (sub) sub.textContent = data.label ?? 'Período actual';
  }


  /* ============================================================
     BLOQUE 2 — FUNNEL DE VENTAS
  ============================================================ */
  function renderFunnel(data) {
    const visual = document.getElementById('funnel-visual');
    const stats  = document.getElementById('funnel-stats');
    if (!visual || !stats || !data.funnel?.length) return;

    const maxLeads = data.funnel[0].leads; // primera etapa = total
    const total    = maxLeads;

    /* ── Visual: barras horizontales ── */
    visual.innerHTML = '';
    data.funnel.forEach((row, i) => {
      const widthPct  = pct(row.leads, maxLeads);
      /* % conversión respecto a etapa anterior */
      const prevLeads = i === 0 ? row.leads : data.funnel[i - 1].leads;
      const convPct   = i === 0 ? 100 : pct(row.leads, prevLeads);
      const convClass = convPct >= 80 ? 'fp-good' : convPct >= 50 ? 'fp-warn' : 'fp-bad';
      const convLabel = i === 0 ? '—' : convPct + '%';

      const rowEl = document.createElement('div');
      rowEl.className = 'funnel-row';
      rowEl.innerHTML = `
        <span class="funnel-label" title="${row.etapa}">${row.etapa}</span>
        <div class="funnel-track">
          <div class="funnel-fill" style="width:0%;background:${row.color}" data-w="${widthPct}">
            <span class="funnel-count-inner">${Utils?.formatNumber(row.leads) ?? row.leads}</span>
          </div>
        </div>
        <span class="funnel-pct ${i === 0 ? '' : convClass}">${convLabel}</span>
      `;
      visual.appendChild(rowEl);
    });

    /* Animar barras con pequeño delay */
    requestAnimationFrame(() => setTimeout(() => {
      visual.querySelectorAll('.funnel-fill').forEach(el => {
        el.style.width = el.dataset.w + '%';
      });
    }, 120));

    /* ── Stats: métricas clave del funnel ── */
    const ganados       = data.funnel.find(e => e.etapa === 'Ganado')?.leads ?? 0;
    const negociacion   = data.funnel.find(e => e.etapa === 'Negociación')?.leads ?? 0;
    const propuesta     = data.funnel.find(e => e.etapa === 'Propuesta')?.leads ?? 0;
    const convGlobal    = (pct(ganados, total)).toFixed(1) + '%';
    const tasaCierre    = propuesta ? (pct(ganados, propuesta)).toFixed(1) + '%' : '—';

    stats.innerHTML = `
      <div class="fs-title">Métricas del Funnel</div>
      <div class="fs-item">
        <span class="fs-label">Conversión global</span>
        <span class="fs-val fv-good">${convGlobal}</span>
        <span class="fs-sub">${ganados} de ${total} leads convertidos</span>
      </div>
      <div class="fs-item">
        <span class="fs-label">Tasa de cierre</span>
        <span class="fs-val ${ganados/propuesta >= 0.3 ? 'fv-good' : 'fv-warn'}">${tasaCierre}</span>
        <span class="fs-sub">Ganados vs. propuestas enviadas</span>
      </div>
      <div class="fs-item">
        <span class="fs-label">En negociación</span>
        <span class="fs-val fv-warn">${Utils?.formatNumber(negociacion) ?? negociacion}</span>
        <span class="fs-sub">Oportunidades activas de cierre</span>
      </div>
      <div class="fs-item">
        <span class="fs-label">Leads ganados</span>
        <span class="fs-val fv-good">${Utils?.formatNumber(ganados) ?? ganados}</span>
        <span class="fs-sub">Convertidos en el período</span>
      </div>
    `;
  }


  /* ============================================================
     BLOQUE 3 — TABLA CAMPAÑAS
  ============================================================ */
  function renderCampanas(data) {
    const tbody = document.getElementById('camp-kpi-tbody');
    if (!tbody || !data.campanas?.length) return;

    tbody.innerHTML = data.campanas.map(c => {
      const crClass  = c.convRate >= 25 ? 'crf-high' : c.convRate >= 15 ? 'crf-mid' : 'crf-low';
      const crValCls = c.convRate >= 25 ? 'crv-high' : c.convRate >= 15 ? 'crv-mid' : 'crv-low';
      const crWidth  = typeof Utils !== 'undefined' ? Utils.clamp(c.convRate, 0, 100) : c.convRate;
      const roiSign  = c.roi >= 0 ? '+' : '';
      const roiCls   = c.roi >= 0 ? 'roi-pos' : 'roi-neg';
      const cplFmt   = typeof Utils !== 'undefined' ? Utils.formatCurrency(c.cpl, true) : c.cpl;

      return `
        <tr>
          <td>
            <div class="camp-name">${typeof Utils !== 'undefined' ? Utils.truncate(c.nombre, 28) : c.nombre}</div>
            <div class="camp-tipo">${c.tipo}</div>
          </td>
          <td><span class="badge badge-accent">${c.canal}</span></td>
          <td class="t-mono t-sm">${typeof Utils !== 'undefined' ? Utils.formatNumber(c.leads) : c.leads}</td>
          <td class="t-mono t-sm">${typeof Utils !== 'undefined' ? Utils.formatNumber(c.conversiones) : c.conversiones}</td>
          <td>
            <div class="cr-wrap">
              <div class="cr-bar"><div class="cr-fill ${crClass}" style="width:${crWidth}%"></div></div>
              <span class="cr-val ${crValCls}">${c.convRate.toFixed(1)}%</span>
            </div>
          </td>
          <td class="t-mono t-sm">${cplFmt}</td>
          <td><span class="${roiCls}">${roiSign}${c.roi}%</span></td>
          <td>${estadoBadge(c.estado)}</td>
        </tr>
      `;
    }).join('');
  }


  /* ============================================================
     BLOQUE 4 — CANALES
  ============================================================ */
  function renderCanales(data) {
    const grid = document.getElementById('canal-grid');
    if (!grid || !data.canales?.length) return;

    grid.innerHTML = '';

    const colorMap = {
      blue  : { bg: 'var(--accent-bg)',  fg: 'var(--accent)',  text: '#fff' },
      purple: { bg: 'var(--info-bg)',    fg: 'var(--info)',    text: '#fff' },
      green : { bg: 'var(--success-bg)', fg: 'var(--success)', text: '#fff' },
      orange: { bg: 'var(--warning-bg)', fg: 'var(--warning)', text: '#fff' },
      teal  : { bg: 'rgba(8,145,178,.1)',fg: '#0891B2',        text: '#fff' },
    };

    data.canales.forEach((c, i) => {
      const col    = colorMap[c.color] ?? colorMap.blue;
      const roiCls = c.roi >= 0 ? 'roi-pos' : 'roi-neg';
      const roiSign = c.roi >= 0 ? '+' : '';
      const cplFmt  = typeof Utils !== 'undefined' ? Utils.formatCurrency(c.cpl, true) : c.cpl;
      const leadsN  = typeof Utils !== 'undefined' ? Utils.formatNumber(c.leads) : c.leads;

      const card = document.createElement('div');
      card.className = `canal-card cc-${c.color} anim anim-${Math.min(i+1,6)}`;
      card.innerHTML = `
        <div class="cc-name">
          <span class="cc-icon" style="background:${col.bg};color:${col.fg}">
            ${c.nombre.charAt(0)}
          </span>
          ${c.nombre}
        </div>
        <div class="cc-metric-main">${leadsN}</div>
        <div class="cc-metric-label">leads captados</div>
        <div class="cc-stats">
          <div class="cc-stat-row">
            <span class="cc-stat-label">Conv. Rate</span>
            <span class="cc-stat-val">${c.convRate.toFixed(1)}%</span>
          </div>
          <div class="cc-stat-row">
            <span class="cc-stat-label">CPL</span>
            <span class="cc-stat-val">${cplFmt}</span>
          </div>
          <div class="cc-stat-row">
            <span class="cc-stat-label">ROI</span>
            <span class="cc-stat-val ${roiCls}">${roiSign}${c.roi}%</span>
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  }


  /* ============================================================
     BLOQUE 5 — GESTIÓN COMERCIAL
  ============================================================ */
  function renderGestion(data) {
    renderAlertas(data.gestion?.alertas ?? []);
    renderRanking(data.gestion?.vendedores ?? []);
  }

  function renderAlertas(alertas) {
    const container = document.getElementById('comercial-alerts');
    if (!container) return;

    container.innerHTML = `<div class="ca-section-title">Leads sin interacción reciente</div>`;

    if (!alertas.length) {
      container.innerHTML += `
        <div class="empty-state">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          Sin alertas activas. ¡Buen trabajo!
        </div>`;
      return;
    }

    alertas.forEach(a => {
      const item = document.createElement('div');
      item.className = `alert-item ai-${a.urgencia}`;
      const daysLabel = a.urgencia === 'urgent'
        ? `🔴 ${a.dias} días`
        : `⚠ ${a.dias} días`;

      item.innerHTML = `
        <div class="ai-dot"></div>
        <div class="ai-body">
          <div class="ai-name">${a.nombre}</div>
          <div class="ai-meta">${a.empresa} · Resp: ${a.responsable}</div>
        </div>
        <span class="ai-days">${daysLabel}</span>
      `;
      container.appendChild(item);
    });
  }

  function renderRanking(vendedores) {
    const container = document.getElementById('vendedor-ranking');
    if (!container) return;

    const maxLeads = Math.max(...vendedores.map(v => v.leads), 1);

    container.innerHTML = `<div class="vr-title">Ranking de Vendedores</div><div class="vr-list" id="vr-list"></div>`;
    const list = document.getElementById('vr-list');

    vendedores.forEach((v, i) => {
      const pos      = i + 1;
      const posClass = pos <= 3 ? `pos-${pos}` : '';
      const avCls    = avColor(v.nombre);
      const barWidth = pct(v.leads, maxLeads);
      const leadsN   = typeof Utils !== 'undefined' ? Utils.formatNumber(v.leads) : v.leads;

      const item = document.createElement('div');
      item.className = 'vr-item';
      item.innerHTML = `
        <span class="vr-pos ${posClass}">${pos}</span>
        <div class="vr-avatar ${avCls}">${ini(v.nombre)}</div>
        <div class="vr-info">
          <div class="vr-name">${v.nombre}</div>
          <div class="vr-leads">${leadsN} leads · ${v.ganados} ganados</div>
        </div>
        <div class="vr-bar-wrap">
          <div class="vr-bar-fill" style="width:0%" data-w="${barWidth}"></div>
        </div>
        <span class="vr-conv">${v.convRate.toFixed(1)}%</span>
      `;
      list.appendChild(item);
    });

    /* Animar barras */
    requestAnimationFrame(() => setTimeout(() => {
      container.querySelectorAll('.vr-bar-fill').forEach(el => {
        el.style.width = el.dataset.w + '%';
      });
    }, 200));
  }


  /* ============================================================
     SIDEBAR NAV — reutiliza la misma lógica del dashboard
  ============================================================ */
  function buildNav() {
    if (typeof Render !== 'undefined' && Render.buildNav) {
      Render.buildNav(0);
      return;
    }
    /* Fallback: construir nav directamente si Render no está */
    const nav = document.getElementById('sb-nav');
    if (!nav || typeof NAV_ITEMS === 'undefined') return;
    nav.innerHTML = '';
    let currentSection = null;
    NAV_ITEMS.forEach(item => {
      if (item.section !== currentSection) {
        currentSection = item.section;
        if (item.section) {
          const label = document.createElement('div');
          label.className   = 'sb-section-label';
          label.textContent = item.section;
          nav.appendChild(label);
        }
      }
      const page   = location.pathname.split('/').pop() || 'index.html';
      const active = page === item.url ? 'active' : '';
      const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
      const a = document.createElement('a');
      a.className = `sb-item ${active}`;
      a.href      = item.url;
      a.innerHTML = `
        <span class="sb-item-icon">${iconSvg}</span>
        <span class="sb-item-label">${item.label}</span>
      `;
      nav.appendChild(a);
    });
  }


  /* ============================================================
     PUNTO DE ENTRADA — renderiza todo con los datos recibidos
  ============================================================ */
  function all(data) {
    renderEjecutivos(data);
    renderFunnel(data);
    renderCampanas(data);
    renderCanales(data);
    renderGestion(data);
  }

  return { all, buildNav, renderEjecutivos, renderFunnel, renderCampanas, renderCanales, renderGestion };

})();

window.KpiRender = KpiRender;