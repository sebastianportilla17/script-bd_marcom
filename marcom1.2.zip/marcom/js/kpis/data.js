/* ================================================================
   js/kpis/data.js — Capa de Datos KPI
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Responsabilidades:
     · Intentar fetch al endpoint configurado en API.kpis
     · Si falla → retornar FALLBACK_KPI_DATA
     · Filtrar datos según período seleccionado
     · Exponer getKpiData(periodo) como única función pública

   Períodos: 'mes' | 'trimestre' | 'anio'
================================================================ */
'use strict';

/* ================================================================
   FALLBACK DATA — Datos simulados por período
   Estructura espejo de lo que retornará la API PHP.
================================================================ */
const FALLBACK_KPI_DATA = {

  /* ── META ──────────────────────────────────────────────────── */
  meta: {
    generado : new Date().toISOString(),
    simulado : true,
  },

  /* ================================================================
     DATOS POR PERÍODO
     Cada clave ('mes' | 'trimestre' | 'anio') contiene la misma
     estructura con valores distintos para simular el filtro.
  ================================================================ */
  periodos: {

    /* ── MES ──────────────────────────────────────────────────── */
    mes: {
      label: 'Marzo 2026',

      /* Bloque 1 — KPIs Ejecutivos */
      ejecutivos: [
        {
          id      : 'leads-generados',
          label   : 'Leads Generados',
          value   : 312,
          format  : 'integer',
          trend   : '+8.3%',
          trendDir: 'up',
          footer  : 'vs. Feb: 288 leads',
          color   : 'blue',
          icon    : 'user',
        },
        {
          id      : 'tasa-conversion',
          label   : 'Tasa de Conversión',
          value   : 23.4,
          format  : 'percent',
          trend   : '+2.1%',
          trendDir: 'up',
          footer  : 'Meta del período: 25%',
          color   : 'green',
          icon    : 'check',
        },
        {
          id      : 'cpl',
          label   : 'Costo por Lead (CPL)',
          value   : 185000,
          format  : 'currency',
          trend   : '-12%',
          trendDir: 'up',
          footer  : 'Meta: < $200.000 · Cumplida ✓',
          color   : 'green',
          icon    : 'dollar',
        },
        {
          id      : 'roi-campanas',
          label   : 'ROI de Campañas',
          value   : 284,
          format  : 'percent',
          trend   : '+41pts',
          trendDir: 'up',
          footer  : 'vs. período anterior: 243%',
          color   : 'purple',
          icon    : 'trending-up',
        },
        {
          id      : 'leads-activos',
          label   : 'Leads Activos',
          value   : 868,
          format  : 'integer',
          trend   : 'en funnel',
          trendDir: 'info',
          footer  : 'Excluye ganados y perdidos',
          color   : 'blue',
          icon    : 'layers',
        },
        {
          id         : 'leads-ganados',
          label      : 'Leads Ganados',
          value      : 73,
          format     : 'integer',
          trend      : '+15.9%',
          trendDir   : 'up',
          footer     : 'Convertidos a clientes este mes',
          color      : 'green',
          icon       : 'check',
        },
      ],

      /* Bloque 2 — Funnel */
      funnel: [
        { etapa: 'Prospecto',    leads: 287, color: '#94A3B8' },
        { etapa: 'Contactado',   leads: 231, color: '#0057FF' },
        { etapa: 'Interesado',   leads: 198, color: '#7C3AED' },
        { etapa: 'Propuesta',    leads: 154, color: '#F79009' },
        { etapa: 'Negociación',  leads:  98, color: '#00C48C' },
        { etapa: 'Ganado',       leads:  73, color: '#00A76F' },
      ],

      /* Bloque 3 — Campañas */
      campanas: [
        {
          id          : 'c001',
          nombre      : 'Black Friday Digital',
          tipo        : 'Promocional / Ventas',
          canal       : 'Email',
          leads       : 198,
          conversiones: 47,
          convRate    : 23.7,
          cpl         : 212000,
          roi         : 385,
          inversion   : 4200000,
          estado      : 'activa',
        },
        {
          id          : 'c002',
          nombre      : 'LinkedIn B2B Q1',
          tipo        : 'Generación de Leads',
          canal       : 'Redes Sociales',
          leads       : 124,
          conversiones: 31,
          convRate    : 25.0,
          cpl         : 185000,
          roi         : 210,
          inversion   : 3800000,
          estado      : 'activa',
        },
        {
          id          : 'c003',
          nombre      : 'SEO Orgánico Blog',
          tipo        : 'Branding / Reconocimiento',
          canal       : 'SEO/Contenido',
          leads       : 312,
          conversiones: 68,
          convRate    : 21.8,
          cpl         : 45000,
          roi         : 540,
          inversion   : 1500000,
          estado      : 'activa',
        },
        {
          id          : 'c004',
          nombre      : 'Referidos Partner',
          tipo        : 'Generación de Leads',
          canal       : 'Referidos',
          leads       : 87,
          conversiones: 29,
          convRate    : 33.3,
          cpl         : 31000,
          roi         : 680,
          inversion   :  900000,
          estado      : 'activa',
        },
        {
          id          : 'c005',
          nombre      : 'Display Programático',
          tipo        : 'Branding / Reconocimiento',
          canal       : 'Google/Meta Ads',
          leads       : 246,
          conversiones: 18,
          convRate    :  7.3,
          cpl         : 344000,
          roi         : -45,
          inversion   : 6200000,
          estado      : 'pausada',
        },
      ],

      /* Bloque 4 — Canales */
      canales: [
        { nombre: 'Email',          leads: 198, convRate: 23.7, cpl: 212000, roi: 385, color: 'blue'   },
        { nombre: 'Redes Sociales', leads: 124, convRate: 25.0, cpl: 185000, roi: 210, color: 'purple' },
        { nombre: 'SEO/Contenido',  leads: 312, convRate: 21.8, cpl:  45000, roi: 540, color: 'green'  },
        { nombre: 'Referidos',      leads:  87, convRate: 33.3, cpl:  31000, roi: 680, color: 'orange' },
        { nombre: 'Ads',            leads: 246, convRate:  7.3, cpl: 344000, roi: -45, color: 'teal'   },
      ],

      /* Bloque 5 — Gestión comercial */
      gestion: {
        alertas: [
          { nombre: 'Marcela Ríos',    empresa: 'Soluciones XYZ',       responsable: 'Luis Mora',   dias: 16, urgencia: 'urgent' },
          { nombre: 'Alberto Vargas',  empresa: 'Plásticos del Norte',  responsable: 'Pedro Ruiz',  dias: 14, urgencia: 'urgent' },
          { nombre: 'Roberto Silva',   empresa: 'Grupo Alfa',           responsable: 'Ana Torres',  dias: 11, urgencia: 'warn'   },
          { nombre: 'Sandra Torres',   empresa: 'FinServ Colombia',     responsable: 'Luis Mora',   dias:  9, urgencia: 'warn'   },
          { nombre: 'Diana Castillo',  empresa: 'Construcciones Norte', responsable: 'Ana Torres',  dias:  8, urgencia: 'warn'   },
        ],
        vendedores: [
          { nombre: 'Ana Torres',  leads: 38, ganados: 12, convRate: 31.6 },
          { nombre: 'Pedro Ruiz',  leads: 31, ganados:  9, convRate: 29.0 },
          { nombre: 'Luis Mora',   leads: 24, ganados:  5, convRate: 20.8 },
          { nombre: 'María López', leads: 18, ganados:  3, convRate: 16.7 },
        ],
      },
    },

    /* ── TRIMESTRE ────────────────────────────────────────────── */
    trimestre: {
      label: 'Q1 2026 (Ene–Mar)',

      ejecutivos: [
        { id: 'leads-generados', label: 'Leads Generados',    value: 847,     format: 'integer',  trend: '+22.4%', trendDir: 'up',   footer: 'vs. Q4 2025: 692 leads',           color: 'blue',   icon: 'user'        },
        { id: 'tasa-conversion', label: 'Tasa de Conversión', value: 21.8,    format: 'percent',  trend: '+1.4%',  trendDir: 'up',   footer: 'Meta del trimestre: 22%',          color: 'green',  icon: 'check'       },
        { id: 'cpl',             label: 'Costo por Lead',     value: 198000,  format: 'currency', trend: '-8%',    trendDir: 'up',   footer: 'Meta: < $210.000 · Cumplida ✓',    color: 'green',  icon: 'dollar'      },
        { id: 'roi-campanas',    label: 'ROI de Campañas',    value: 261,     format: 'percent',  trend: '+28pts', trendDir: 'up',   footer: 'vs. Q4 2025: 233%',                color: 'purple', icon: 'trending-up' },
        { id: 'leads-activos',   label: 'Leads Activos',      value: 868,     format: 'integer',  trend: 'total',  trendDir: 'info', footer: 'Pipeline actual',                  color: 'blue',   icon: 'layers'      },
        { id: 'leads-ganados',   label: 'Leads Ganados',      value: 185,     format: 'integer',  trend: '+18.6%', trendDir: 'up',   footer: 'Convertidos en el trimestre',      color: 'green',  icon: 'check'       },
      ],

      funnel: [
        { etapa: 'Prospecto',    leads: 847, color: '#94A3B8' },
        { etapa: 'Contactado',   leads: 690, color: '#0057FF' },
        { etapa: 'Interesado',   leads: 543, color: '#7C3AED' },
        { etapa: 'Propuesta',    leads: 389, color: '#F79009' },
        { etapa: 'Negociación',  leads: 241, color: '#00C48C' },
        { etapa: 'Ganado',       leads: 185, color: '#00A76F' },
      ],

      campanas: [
        { id: 'c001', nombre: 'Black Friday Digital',  tipo: 'Promocional / Ventas',   canal: 'Email',          leads: 412, conversiones: 98,  convRate: 23.8, cpl: 198000, roi: 395, inversion: 12000000, estado: 'activa'   },
        { id: 'c002', nombre: 'LinkedIn B2B Q1',       tipo: 'Generación de Leads',    canal: 'Redes Sociales', leads: 294, conversiones: 72,  convRate: 24.5, cpl: 176000, roi: 225, inversion: 9200000,  estado: 'activa'   },
        { id: 'c003', nombre: 'SEO Orgánico Blog',     tipo: 'Branding',               canal: 'SEO/Contenido',  leads: 687, conversiones: 145, convRate: 21.1, cpl:  41000, roi: 580, inversion: 4200000,  estado: 'activa'   },
        { id: 'c004', nombre: 'Referidos Partner',     tipo: 'Generación de Leads',    canal: 'Referidos',      leads: 201, conversiones:  68, convRate: 33.8, cpl:  28000, roi: 720, inversion: 2400000,  estado: 'activa'   },
        { id: 'c005', nombre: 'Display Programático',  tipo: 'Branding',               canal: 'Google/Meta Ads',leads: 510, conversiones:  35, convRate:  6.9, cpl: 320000, roi: -38, inversion: 15800000, estado: 'pausada'  },
      ],

      canales: [
        { nombre: 'Email',          leads: 412, convRate: 23.8, cpl: 198000, roi: 395, color: 'blue'   },
        { nombre: 'Redes Sociales', leads: 294, convRate: 24.5, cpl: 176000, roi: 225, color: 'purple' },
        { nombre: 'SEO/Contenido',  leads: 687, convRate: 21.1, cpl:  41000, roi: 580, color: 'green'  },
        { nombre: 'Referidos',      leads: 201, convRate: 33.8, cpl:  28000, roi: 720, color: 'orange' },
        { nombre: 'Ads',            leads: 510, convRate:  6.9, cpl: 320000, roi: -38, color: 'teal'   },
      ],

      gestion: {
        alertas: [
          { nombre: 'Marcela Ríos',    empresa: 'Soluciones XYZ',      responsable: 'Luis Mora',  dias: 16, urgencia: 'urgent' },
          { nombre: 'Alberto Vargas',  empresa: 'Plásticos del Norte', responsable: 'Pedro Ruiz', dias: 14, urgencia: 'urgent' },
          { nombre: 'Roberto Silva',   empresa: 'Grupo Alfa',          responsable: 'Ana Torres', dias: 11, urgencia: 'warn'   },
          { nombre: 'Sandra Torres',   empresa: 'FinServ Colombia',    responsable: 'Luis Mora',  dias:  9, urgencia: 'warn'   },
        ],
        vendedores: [
          { nombre: 'Ana Torres',  leads: 112, ganados: 38, convRate: 33.9 },
          { nombre: 'Pedro Ruiz',  leads:  94, ganados: 28, convRate: 29.8 },
          { nombre: 'Luis Mora',   leads:  71, ganados: 16, convRate: 22.5 },
          { nombre: 'María López', leads:  58, ganados: 11, convRate: 19.0 },
        ],
      },
    },

    /* ── AÑO ──────────────────────────────────────────────────── */
    anio: {
      label: 'Año 2026 (acumulado)',

      ejecutivos: [
        { id: 'leads-generados', label: 'Leads Generados',    value: 1247,    format: 'integer',  trend: '+18.2%', trendDir: 'up',   footer: 'vs. mismo período 2025',           color: 'blue',   icon: 'user'        },
        { id: 'tasa-conversion', label: 'Tasa de Conversión', value: 23.4,    format: 'percent',  trend: '+3.2%',  trendDir: 'up',   footer: 'Meta anual: 25%',                  color: 'green',  icon: 'check'       },
        { id: 'cpl',             label: 'Costo por Lead',     value: 175000,  format: 'currency', trend: '-18%',   trendDir: 'up',   footer: 'Meta: < $200.000 · Cumplida ✓',    color: 'green',  icon: 'dollar'      },
        { id: 'roi-campanas',    label: 'ROI de Campañas',    value: 310,     format: 'percent',  trend: '+67pts', trendDir: 'up',   footer: 'vs. año anterior: 243%',           color: 'purple', icon: 'trending-up' },
        { id: 'leads-activos',   label: 'Leads Activos',      value: 868,     format: 'integer',  trend: 'hoy',    trendDir: 'info', footer: 'Pipeline actual',                  color: 'blue',   icon: 'layers'      },
        { id: 'leads-ganados',   label: 'Leads Ganados',      value: 292,     format: 'integer',  trend: '+23.1%', trendDir: 'up',   footer: 'Convertidos en el año',            color: 'green',  icon: 'check'       },
      ],

      funnel: [
        { etapa: 'Prospecto',    leads: 1247, color: '#94A3B8' },
        { etapa: 'Contactado',   leads:  998, color: '#0057FF' },
        { etapa: 'Interesado',   leads:  743, color: '#7C3AED' },
        { etapa: 'Propuesta',    leads:  512, color: '#F79009' },
        { etapa: 'Negociación',  leads:  347, color: '#00C48C' },
        { etapa: 'Ganado',       leads:  292, color: '#00A76F' },
      ],

      campanas: [
        { id: 'c001', nombre: 'Black Friday Digital', tipo: 'Promocional / Ventas',   canal: 'Email',          leads: 614, conversiones: 148, convRate: 24.1, cpl: 185000, roi: 410, inversion: 18000000, estado: 'activa'  },
        { id: 'c002', nombre: 'LinkedIn B2B Q1',      tipo: 'Generación de Leads',    canal: 'Redes Sociales', leads: 418, conversiones: 104, convRate: 24.9, cpl: 168000, roi: 240, inversion: 14000000, estado: 'activa'  },
        { id: 'c003', nombre: 'SEO Orgánico Blog',    tipo: 'Branding',               canal: 'SEO/Contenido',  leads: 987, conversiones: 215, convRate: 21.8, cpl:  38000, roi: 620, inversion:  6800000, estado: 'activa'  },
        { id: 'c004', nombre: 'Referidos Partner',    tipo: 'Generación de Leads',    canal: 'Referidos',      leads: 312, conversiones: 108, convRate: 34.6, cpl:  25000, roi: 780, inversion:  3800000, estado: 'activa'  },
        { id: 'c005', nombre: 'Display Programático', tipo: 'Branding',               canal: 'Google/Meta Ads',leads: 724, conversiones:  51, convRate:  7.0, cpl: 298000, roi: -28, inversion: 24000000, estado: 'pausada' },
      ],

      canales: [
        { nombre: 'Email',          leads: 614, convRate: 24.1, cpl: 185000, roi: 410, color: 'blue'   },
        { nombre: 'Redes Sociales', leads: 418, convRate: 24.9, cpl: 168000, roi: 240, color: 'purple' },
        { nombre: 'SEO/Contenido',  leads: 987, convRate: 21.8, cpl:  38000, roi: 620, color: 'green'  },
        { nombre: 'Referidos',      leads: 312, convRate: 34.6, cpl:  25000, roi: 780, color: 'orange' },
        { nombre: 'Ads',            leads: 724, convRate:  7.0, cpl: 298000, roi: -28, color: 'teal'   },
      ],

      gestion: {
        alertas: [
          { nombre: 'Marcela Ríos',    empresa: 'Soluciones XYZ',      responsable: 'Luis Mora',  dias: 16, urgencia: 'urgent' },
          { nombre: 'Alberto Vargas',  empresa: 'Plásticos del Norte', responsable: 'Pedro Ruiz', dias: 14, urgencia: 'urgent' },
          { nombre: 'Roberto Silva',   empresa: 'Grupo Alfa',          responsable: 'Ana Torres', dias: 11, urgencia: 'warn'   },
          { nombre: 'Sandra Torres',   empresa: 'FinServ Colombia',    responsable: 'Luis Mora',  dias:  9, urgencia: 'warn'   },
        ],
        vendedores: [
          { nombre: 'Ana Torres',  leads: 198, ganados: 68, convRate: 34.3 },
          { nombre: 'Pedro Ruiz',  leads: 172, ganados: 51, convRate: 29.7 },
          { nombre: 'Luis Mora',   leads: 134, ganados: 31, convRate: 23.1 },
          { nombre: 'María López', leads: 110, ganados: 24, convRate: 21.8 },
        ],
      },
    },
  },
};


/* ================================================================
   getKpiData(periodo)
   Intenta fetch al endpoint configurado en API.kpis.
   Si falla → usa FALLBACK_KPI_DATA.
   Siempre retorna los datos del período solicitado.
================================================================ */
async function getKpiData(periodo = 'mes') {
  let raw;

  try {
    const endpoint = (typeof API !== 'undefined' && API.kpis)
      ? API.kpis
      : '../data/kpis.json';

    const res = await fetch(endpoint, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    raw = await res.json();
  } catch (err) {
    console.warn('[MARCOM] getKpiData: usando datos simulados.', err.message);
    raw = FALLBACK_KPI_DATA;
  }

  /* Retorna el sub-objeto del período solicitado + meta */
  const periodData = raw?.periodos?.[periodo] ?? FALLBACK_KPI_DATA.periodos[periodo];
  return {
    meta   : raw?.meta ?? FALLBACK_KPI_DATA.meta,
    periodo: periodo,
    ...periodData,
  };
}

/* ── Exponer globalmente ──────────────────────────────────────── */
window.getKpiData        = getKpiData;
window.FALLBACK_KPI_DATA = FALLBACK_KPI_DATA;