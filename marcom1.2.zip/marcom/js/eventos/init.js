/* ================================================================
   js/eventos/init.js — Director de Orquesta · Modulo Eventos
   Modulo  : Marketing y Comercial · ERP ADSO 3171727
   Version : 1.1 — Corregido

   PATRON SEGURO: igual a campanas-init.js
   - No usa const/let al nivel global
   - window.addEventListener('load', async function(){...})
   - Depende de: font.js, auth.js, config.js, utils.js,
                 eventos/data.js, eventos/render.js
================================================================ */

(function () {

  /* ── Estado local (privado al IIFE) ─────────────────────────── */
  var _data        = null;
  var _filtered    = [];
  var _calMes      = new Date().getMonth();
  var _calAnio     = new Date().getFullYear();
  var _vistaActual = 'calendario';


  /* ================================================================
     buildNav() — identico en todos los modulos
     Lee NAV_ITEMS + ICONS de config.js → construye #sb-nav
  ================================================================ */
  function buildNav() {
    var nav = document.getElementById('sb-nav');
    if (!nav || typeof NAV_ITEMS === 'undefined') return;
    nav.innerHTML = '';
    var section = null;
    var page    = location.pathname.split('/').pop() || 'index.html';

    NAV_ITEMS.forEach(function (item) {
      if (item.section !== section) {
        section = item.section;
        if (item.section) {
          var lbl       = document.createElement('div');
          lbl.className   = 'sb-section-label';
          lbl.textContent = item.section;
          nav.appendChild(lbl);
        }
      }
      var active  = page === item.url;
      var iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
      var a       = document.createElement('a');
      a.className = 'sb-item' + (active ? ' active' : '');
      a.href      = item.url;
      a.setAttribute('aria-current', active ? 'page' : 'false');
      a.innerHTML =
        '<span class="sb-item-icon">' + iconSvg + '</span>' +
        '<span class="sb-item-label">' + item.label + '</span>';
      nav.appendChild(a);
    });
  }


  /* ================================================================
     _applyFilters()
  ================================================================ */
  function _applyFilters() {
    if (!_data) return [];
    var estado = (document.getElementById('f-ev-estado') || {}).value || 'Todos';
    var tipo   = (document.getElementById('f-ev-tipo')   || {}).value || 'Todos';
    var resp   = (document.getElementById('f-ev-resp')   || {}).value || 'Todos';

    return _data.eventos.filter(function (ev) {
      if (estado !== 'Todos' && ev.estado      !== estado) return false;
      if (tipo   !== 'Todos' && ev.tipo_evento !== tipo)   return false;
      if (resp   !== 'Todos' && ev.responsable !== resp)   return false;
      return true;
    });
  }


  /* ================================================================
     _renderCal()
  ================================================================ */
  function _renderCal() {
    EventosRender.buildNavMes(_calMes, _calAnio);
    EventosRender.buildCalendario(_filtered, _calMes, _calAnio);
  }


  /* ================================================================
     initViewToggle() — Calendario <-> Lista
  ================================================================ */
  function initViewToggle() {
    document.querySelectorAll('.vt-btn[data-view]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var view = btn.dataset.view;
        _vistaActual = view;

        document.querySelectorAll('.vt-btn').forEach(function (b) {
          b.classList.toggle('vt-active', b.dataset.view === view);
          b.setAttribute('aria-pressed', b.dataset.view === view ? 'true' : 'false');
        });

        document.querySelectorAll('.eventos-view').forEach(function (v) {
          var show = v.id === 'view-' + view;
          v.classList.toggle('view-active', show);
          v.setAttribute('aria-hidden', show ? 'false' : 'true');
        });

        if (view === 'lista') {
          EventosRender.buildTabla(_filtered);
        } else {
          _renderCal();
        }
      });
    });
  }


  /* ================================================================
     initFilters()
  ================================================================ */
  function initFilters() {
    function rebuild() {
      _filtered = _applyFilters();
      if (_vistaActual === 'lista') {
        EventosRender.buildTabla(_filtered);
      } else {
        _renderCal();
      }
    }
    ['f-ev-estado', 'f-ev-tipo', 'f-ev-resp'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('change', rebuild);
    });
  }


  /* ================================================================
     populateFiltros()
  ================================================================ */
  function populateFiltros(filtros) {
    function addOpts(id, arr) {
      var sel = document.getElementById(id);
      if (!sel) return;
      arr.forEach(function (v) {
        var o = document.createElement('option');
        o.value = v; o.textContent = v;
        sel.appendChild(o);
      });
    }
    addOpts('f-ev-estado', filtros.estados);
    addOpts('f-ev-tipo',   filtros.tipos);
    addOpts('f-ev-resp',   filtros.responsables);
  }


  /* ================================================================
     Modal nuevo evento
  ================================================================ */
  function openModal() {
    var modal = document.getElementById('modal-evento');
    if (!modal) return;
    modal.classList.add('modal-show');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    var modal = document.getElementById('modal-evento');
    if (modal) modal.classList.remove('modal-show');
    document.body.style.overflow = '';
  }

  function guardarEvento() {
    var nombre = (document.getElementById('mev-nombre') || {}).value;
    if (nombre) nombre = nombre.trim();
    var inicio = (document.getElementById('mev-inicio') || {}).value;

    if (!nombre || !inicio) {
      if (typeof Utils !== 'undefined') Utils.showToast('Nombre y fecha de inicio son obligatorios', 'warning');
      return;
    }

    var fin    = (document.getElementById('mev-fin')    || {}).value || inicio;
    var lugar  = (document.getElementById('mev-lugar')  || {}).value || '';
    var ciudad = (document.getElementById('mev-ciudad') || {}).value || '';
    var cupo   = parseInt((document.getElementById('mev-cupo')   || {}).value)  || 0;
    var presup = parseInt((document.getElementById('mev-presup') || {}).value)  || 0;
    var tipo   = (document.getElementById('mev-tipo')   || {}).value || 'Webinar';
    var resp   = (document.getElementById('mev-resp')   || {}).value || '';

    _data.eventos.unshift({
      id_evento       : Date.now(),
      nom_evento      : nombre,
      desc_evento     : '',
      tipo_evento     : tipo,
      fec_inicio      : inicio,
      fec_fin         : fin,
      lugar           : lugar,
      ciudad          : ciudad,
      cupo_maximo     : cupo,
      estado          : 'Borrador',
      responsable     : resp,
      id_campana      : null,
      nom_campana     : null,
      presupuesto     : presup,
      gasto_real      : 0,
      num_invitados   : 0,
      num_confirmados : 0,
      num_asistentes  : 0,
      leads           : [],
    });

    _filtered = _applyFilters();
    if (_vistaActual === 'lista') EventosRender.buildTabla(_filtered);
    else _renderCal();

    closeModal();
    if (typeof Utils !== 'undefined') Utils.showToast('Evento "' + nombre + '" creado', 'success');

    /* Limpiar form */
    ['mev-nombre','mev-lugar','mev-ciudad','mev-cupo','mev-presup','mev-inicio','mev-fin'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.value = '';
    });
  }


  /* ================================================================
     initShell() — sidebar movil, tema, logout
     Patron identico en todos los modulos
  ================================================================ */
  function initShell() {
    var mobBtn  = document.getElementById('mob-menu-btn');
    var sidebar = document.getElementById('sidebar');
    var sbOv    = document.getElementById('sb-overlay');

    if (mobBtn) mobBtn.addEventListener('click', function () {
      if (sidebar) sidebar.classList.toggle('sidebar-open');
      if (sbOv)    sbOv.classList.toggle('overlay-show');
    });
    if (sbOv) sbOv.addEventListener('click', function () {
      if (sidebar) sidebar.classList.remove('sidebar-open');
      sbOv.classList.remove('overlay-show');
    });

    var btnDark = document.getElementById('btn-dark');
    if (btnDark) btnDark.addEventListener('click', function () {
      if (typeof toggleDark === 'function') toggleDark();
    });

    var btnNotif = document.getElementById('btn-notif');
    if (btnNotif) btnNotif.addEventListener('click', function () {
      if (typeof Utils !== 'undefined') Utils.showToast('Sin notificaciones nuevas', 'info');
    });

    var btnLogout = document.getElementById('btn-logout');
    if (btnLogout) btnLogout.addEventListener('click', function () {
      if (typeof Auth !== 'undefined') Auth.logout();
    });
  }


  /* ================================================================
     INIT PRINCIPAL — window 'load', igual que campanas-init.js
  ================================================================ */
  window.addEventListener('load', async function () {

    /* 1. Sesion */
    if (typeof Auth !== 'undefined') {
      var user = Auth.initProtectedPage();
      if (!user) return;
    }

    /* 2. Fecha */
    var dateBadge = document.getElementById('date-badge');
    if (dateBadge) dateBadge.textContent = new Date().toLocaleDateString('es-CO', {
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
    });

    /* 3. Datos */
    try {
      _data = await getEventosData();
    } catch (e) {
      _data = window.EVENTOS_FALLBACK;
    }

    /* 4. Nav */
    buildNav();

    /* 5. KPIs */
    EventosRender.buildKPIs(_data.resumen);

    /* 6. Subtitulo */
    var sub = document.getElementById('eventos-sub');
    if (sub) sub.textContent = _data.eventos.length + ' eventos registrados \u00b7 ' + (_data.meta && _data.meta.periodo ? _data.meta.periodo : '');

    /* 7. Filtros */
    populateFiltros(_data.filtros);
    _filtered = _data.eventos.slice();

    /* 8. Vista inicial — Calendario */
    _renderCal();

    /* 9. Navegacion del mes */
    var btnPrev = document.getElementById('cal-prev');
    var btnNext = document.getElementById('cal-next');
    var btnHoy  = document.getElementById('cal-hoy');

    if (btnPrev) btnPrev.addEventListener('click', function () {
      _calMes--;
      if (_calMes < 0) { _calMes = 11; _calAnio--; }
      _renderCal();
    });
    if (btnNext) btnNext.addEventListener('click', function () {
      _calMes++;
      if (_calMes > 11) { _calMes = 0; _calAnio++; }
      _renderCal();
    });
    if (btnHoy) btnHoy.addEventListener('click', function () {
      _calMes  = new Date().getMonth();
      _calAnio = new Date().getFullYear();
      _renderCal();
    });

    /* 10. Toggle vistas */
    initViewToggle();

    /* 11. Filtros */
    initFilters();

    /* 12. Shell */
    initShell();

    /* 13. Drawer cerrar */
    var evdClose = document.getElementById('evd-close');
    var drOverlay = document.getElementById('drawer-overlay');
    if (evdClose)  evdClose.addEventListener('click',  EventosRender.closeDrawer);
    if (drOverlay) drOverlay.addEventListener('click', EventosRender.closeDrawer);

    /* 14. Modal nuevo evento */
    var btnNuevo    = document.getElementById('btn-nuevo-evento');
    var modalClose  = document.getElementById('modal-ev-close');
    var modalCancel = document.getElementById('modal-ev-cancel');
    var modalGuardar = document.getElementById('modal-ev-guardar');
    var modalOverlay = document.getElementById('modal-evento');

    if (btnNuevo)     btnNuevo.addEventListener('click', openModal);
    if (modalClose)   modalClose.addEventListener('click', closeModal);
    if (modalCancel)  modalCancel.addEventListener('click', closeModal);
    if (modalGuardar) modalGuardar.addEventListener('click', guardarEvento);
    if (modalOverlay) modalOverlay.addEventListener('click', function (e) {
      if (e.target.id === 'modal-evento') closeModal();
    });

    /* 15. Escape */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        EventosRender.closeDrawer();
        closeModal();
      }
    });

    /* 16. Toast bienvenida */
    setTimeout(function () {
      if (typeof Utils !== 'undefined') {
        var activos = _data.eventos.filter(function (ev) { return ev.estado === 'Activo'; }).length;
        Utils.showToast(activos + ' eventos activos \u00b7 ' + _data.eventos.length + ' en total', 'success', 2500);
      }
    }, 600);

  });

}());