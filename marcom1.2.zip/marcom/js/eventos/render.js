/* ================================================================
   js/eventos/render.js — Capa de Renderizado · Modulo Eventos
   Modulo  : Marketing y Comercial · ERP ADSO 3171727
   Version : 1.1 — Corregido

   PATRON SEGURO: window.EventosRender = window.EventosRender || (()=>{...})()
   Evita re-declaracion si el script se carga mas de una vez.
   No usa 'const' al nivel global del script.
================================================================ */

window.EventosRender = window.EventosRender || (function () {

  /* ── Mapa tipo → emoji + clase CSS ────────────────────────── */
  var TIPO_MAP = {
    'Feria'        : { cls: 'eti-feria',       emoji: '\uD83C\uDFDB', label: 'Feria'        },
    'Webinar'      : { cls: 'eti-webinar',     emoji: '\uD83D\uDCBB', label: 'Webinar'      },
    'Lanzamiento'  : { cls: 'eti-lanzamiento', emoji: '\uD83D\uDE80', label: 'Lanzamiento'  },
    'Taller'       : { cls: 'eti-taller',      emoji: '\uD83D\uDEE0', label: 'Taller'       },
    'Conferencia'  : { cls: 'eti-conferencia', emoji: '\uD83C\uDF99', label: 'Conferencia'  },
  };

  var ESTADO_BADGE = {
    'Activo'     : 'badge-success',
    'Finalizado' : 'badge-neutral',
    'Cancelado'  : 'badge-danger',
    'Borrador'   : 'badge-warning',
  };

  var ASIST_BADGE = {
    'Asistio'    : 'badge-success',
    'Confirmado' : 'badge-accent',
    'Invitado'   : 'badge-neutral',
  };

  /* ── Helpers internos ───────────────────────────────────────── */
  function _fmt$(v) {
    if (!v || v === 0) return '$0';
    if (v >= 1e9) return '$' + (v / 1e9).toFixed(1) + 'B';
    if (v >= 1e6) return '$' + (v / 1e6).toFixed(1) + 'M';
    if (v >= 1e3) return '$' + (v / 1e3).toFixed(0) + 'K';
    return '$' + Math.round(v).toLocaleString('es-CO');
  }

  function _fmtDate(s, style) {
    if (!s) return '\u2014';
    var d = new Date(s + 'T00:00:00');
    if (isNaN(d)) return '\u2014';
    if (style === 'long') {
      return d.toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    }
    return d.toLocaleDateString('es-CO', { day: '2-digit', month: 'short' });
  }

  function _safePct(v, t) {
    if (!t || isNaN(t) || isNaN(v)) return 0;
    return Math.min(Math.round((v / t) * 100), 100);
  }

  function _estadoBadge(estado) {
    var cls = ESTADO_BADGE[estado] || 'badge-neutral';
    return '<span class="badge ' + cls + '">' + estado + '</span>';
  }

  function _tipoInfo(tipo) {
    return TIPO_MAP[tipo] || { cls: 'eti-default', emoji: '\uD83D\uDCC5', label: tipo || 'Evento' };
  }

  function _scoreClass(score) {
    var s = Number(score);
    var hi = (window.THRESHOLDS && window.THRESHOLDS.score) ? window.THRESHOLDS.score.high : 70;
    var mi = (window.THRESHOLDS && window.THRESHOLDS.score) ? window.THRESHOLDS.score.mid  : 40;
    if (s >= hi) return 'sv-high';
    if (s >= mi) return 'sv-mid';
    return 'sv-low';
  }

  function _trunc(str, max) {
    if (typeof Utils !== 'undefined') return Utils.truncate(str, max);
    if (!str) return '';
    return str.length > max ? str.slice(0, max - 1) + '\u2026' : str;
  }

  function _initials(name) {
    if (!name) return '??';
    var parts = name.trim().split(/\s+/);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  }

  /* ================================================================
     buildKPIs(resumen)
     4 tarjetas KPI superiores. Patron identico a campanas-init.js.
  ================================================================ */
  function buildKPIs(resumen) {
    var grid = document.getElementById('eventos-kpis');
    if (!grid) return;

    var items = [
      {
        id: 'kpi-ev-activos', val: resumen.eventosActivos, suf: '',
        label: 'Eventos Activos', color: 'blue', trend: 'En ejecucion', tCls: 'kct-info',
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
      },
      {
        id: 'kpi-ev-asistentes', val: resumen.totalAsistentes, suf: '',
        label: 'Total Asistentes', color: 'green', trend: '+12% vs anterior', tCls: 'kct-up',
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
      },
      {
        id: 'kpi-ev-tasa', val: resumen.tasaAsistencia, suf: '%',
        label: 'Tasa de Asistencia', color: 'purple', trend: 'Meta: 80%', tCls: 'kct-info',
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
      },
      {
        id: 'kpi-ev-proximos', val: resumen.proximosEventos, suf: '',
        label: 'Proximos Eventos', color: 'orange', trend: 'Proximos 30 dias', tCls: 'kct-info',
        icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
      },
    ];

    var colorMap = { blue: 'kc-blue', green: 'kc-green', purple: 'kc-purple', orange: 'kc-orange' };
    var iconMap  = { blue: 'kci-blue', green: 'kci-green', purple: 'kci-purple', orange: 'kci-orange' };

    grid.innerHTML = '';
    items.forEach(function (k, i) {
      var card = document.createElement('div');
      card.className = 'kpi-card ' + colorMap[k.color] + ' anim anim-' + (i + 1);
      card.innerHTML =
        '<div class="kpi-card-top">' +
          '<div class="kc-icon ' + iconMap[k.color] + '">' + k.icon + '</div>' +
          '<span class="kc-trend ' + k.tCls + '">' + k.trend + '</span>' +
        '</div>' +
        '<div class="kc-value" id="' + k.id + '">' + k.val + k.suf + '</div>' +
        '<div class="kc-label">' + k.label + '</div>';
      grid.appendChild(card);

      /* Animacion contador */
      (function (kid, kval, ksuf) {
        requestAnimationFrame(function () {
          var el = document.getElementById(kid);
          if (!el) return;
          if (typeof Utils !== 'undefined') {
            if (ksuf === '%') {
              Utils.counter(el, kval, 900, 'decimal');
              setTimeout(function () { if (el) el.textContent = kval + '%'; }, 950);
            } else {
              Utils.counter(el, kval, 900, 'integer');
            }
          }
        });
      }(k.id, k.val, k.suf));
    });
  }


  /* ================================================================
     buildCalendario(eventos, mes, anio)
     Grid mensual — chips de eventos por dia.
  ================================================================ */
  function buildCalendario(eventos, mes, anio) {
    var wrap = document.getElementById('eventos-calendario');
    if (!wrap) return;

    var hoy       = new Date();
    var primerDia = new Date(anio, mes, 1);
    var ultimoDia = new Date(anio, mes + 1, 0);
    var iniciaSem = primerDia.getDay();
    var DIAS      = ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'];

    var cells = '';

    /* Celdas vacias antes del primer dia */
    for (var i = 0; i < iniciaSem; i++) {
      cells += '<div class="cal-cell cal-empty"></div>';
    }

    /* Dias del mes */
    for (var d = 1; d <= ultimoDia.getDate(); d++) {
      var fecha  = new Date(anio, mes, d);
      var fStr   = fecha.toISOString().split('T')[0];
      var esHoy  = (fecha.toDateString() === hoy.toDateString());

      /* Eventos que caen en este dia */
      var evsDia = eventos.filter(function (ev) {
        var ini = new Date(ev.fec_inicio + 'T00:00:00');
        var fin = new Date(ev.fec_fin    + 'T00:00:00');
        return fecha >= ini && fecha <= fin;
      });

      var evHTML = evsDia.map(function (ev) {
        var ti = _tipoInfo(ev.tipo_evento);
        return '<div class="cal-ev-chip ' + ti.cls + ' ev-estado-' + ev.estado.toLowerCase() +
          '" data-id="' + ev.id_evento + '" title="' + ev.nom_evento + '">' +
          ti.emoji + ' ' + _trunc(ev.nom_evento, 20) +
          '</div>';
      }).join('');

      cells +=
        '<div class="cal-cell' + (esHoy ? ' cal-hoy' : '') + '" data-fecha="' + fStr + '">' +
          '<span class="cal-num' + (esHoy ? ' cal-num-hoy' : '') + '">' + d + '</span>' +
          evHTML +
        '</div>';
    }

    wrap.innerHTML =
      '<div class="cal-header-row">' +
        DIAS.map(function (d) { return '<div class="cal-header-cell">' + d + '</div>'; }).join('') +
      '</div>' +
      '<div class="cal-grid" id="cal-grid">' + cells + '</div>';

    /* Click en chip → drawer */
    wrap.querySelectorAll('.cal-ev-chip[data-id]').forEach(function (chip) {
      chip.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = parseInt(chip.dataset.id);
        var ev = eventos.find(function (ev) { return ev.id_evento === id; });
        if (ev) openDrawer(ev);
      });
    });
  }


  /* ================================================================
     buildNavMes(mes, anio)
  ================================================================ */
  function buildNavMes(mes, anio) {
    var MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
                 'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    var el = document.getElementById('cal-mes-label');
    if (el) el.textContent = MESES[mes] + ' ' + anio;
  }


  /* ================================================================
     buildTabla(eventos)
     Tabla vista Lista.
  ================================================================ */
  function buildTabla(eventos) {
    var tbody   = document.getElementById('eventos-tbody');
    var counter = document.getElementById('ev-count');
    if (!tbody) return;
    if (counter) counter.textContent = eventos.length;

    if (!eventos.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-muted)">Sin eventos que coincidan con los filtros</td></tr>';
      return;
    }

    tbody.innerHTML = eventos.map(function (ev) {
      var ti       = _tipoInfo(ev.tipo_evento);
      var tasaAsis = _safePct(ev.num_asistentes, ev.num_invitados);
      var mismaFec = ev.fec_inicio === ev.fec_fin;
      var fechaStr = mismaFec
        ? _fmtDate(ev.fec_inicio, 'long')
        : _fmtDate(ev.fec_inicio) + ' \u2013 ' + _fmtDate(ev.fec_fin);

      return '<tr class="evento-row" data-id="' + ev.id_evento + '">' +
        '<td><div class="ev-name-cell">' +
          '<div class="ev-tipo-icon ' + ti.cls + '">' + ti.emoji + '</div>' +
          '<div><div class="ev-name">' + ev.nom_evento + '</div>' +
          '<div class="ev-lugar">' + ev.ciudad + ' \u00b7 ' + ev.lugar + '</div></div>' +
        '</div></td>' +
        '<td><span class="badge badge-neutral ev-tipo-badge">' + ev.tipo_evento + '</span></td>' +
        '<td>' + _estadoBadge(ev.estado) + '</td>' +
        '<td class="mono-val">' + fechaStr + '</td>' +
        '<td><div class="ev-asist-cell">' +
          '<span class="mono-val">' + ev.num_asistentes + ' / ' + ev.num_invitados + '</span>' +
          '<div class="ev-asist-bar"><div class="ev-asist-fill" style="width:' + tasaAsis + '%"></div></div>' +
        '</div></td>' +
        '<td class="mono-val">' + _fmt$(ev.presupuesto) + '</td>' +
        '<td class="t-sm t-second">' + ev.responsable + '</td>' +
        '<td><button class="btn-icon ev-btn-detail" data-id="' + ev.id_evento + '" title="Ver detalle">' +
          '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
          '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
        '</button></td>' +
      '</tr>';
    }).join('');

    /* Eventos de fila — abre drawer */
    tbody.querySelectorAll('.evento-row').forEach(function (row) {
      row.addEventListener('click', function (e) {
        if (e.target.closest('.ev-btn-detail')) return;
        var id = parseInt(row.dataset.id);
        var ev = eventos.find(function (ev) { return ev.id_evento === id; });
        if (ev) openDrawer(ev);
      });
    });
    tbody.querySelectorAll('.ev-btn-detail').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = parseInt(btn.dataset.id);
        var ev = eventos.find(function (ev) { return ev.id_evento === id; });
        if (ev) openDrawer(ev);
      });
    });
  }


  /* ================================================================
     openDrawer(evento)
  ================================================================ */
  function openDrawer(ev) {
    var drawer  = document.getElementById('ev-drawer');
    var overlay = document.getElementById('drawer-overlay');
    if (!drawer) return;

    var ti       = _tipoInfo(ev.tipo_evento);
    var pct      = _safePct(ev.gasto_real, ev.presupuesto);
    var tasaAsis = ev.num_invitados > 0 ? _safePct(ev.num_asistentes, ev.num_invitados) : 0;
    var mismaFec = ev.fec_inicio === ev.fec_fin;

    /* Header */
    var elNombre = document.getElementById('evd-nombre');
    if (elNombre) elNombre.textContent = ev.nom_evento;

    var elBadges = document.getElementById('evd-badges');
    if (elBadges) elBadges.innerHTML =
      _estadoBadge(ev.estado) +
      '<span class="badge badge-accent">' + ti.emoji + ' ' + ti.label + '</span>' +
      (ev.nom_campana ? '<span class="badge badge-neutral">' + ev.nom_campana + '</span>' : '');

    /* Info general */
    var elInfo = document.getElementById('evd-info');
    if (elInfo) elInfo.innerHTML =
      '<div class="evd-info-grid">' +
        '<div class="evd-info-item">' +
          '<span class="evd-info-label">Fecha</span>' +
          '<span class="evd-info-val">' +
            (mismaFec ? _fmtDate(ev.fec_inicio, 'long') : _fmtDate(ev.fec_inicio, 'long') + ' \u2192 ' + _fmtDate(ev.fec_fin, 'long')) +
          '</span>' +
        '</div>' +
        '<div class="evd-info-item">' +
          '<span class="evd-info-label">Lugar</span>' +
          '<span class="evd-info-val">' + ev.lugar + '</span>' +
        '</div>' +
        '<div class="evd-info-item">' +
          '<span class="evd-info-label">Ciudad</span>' +
          '<span class="evd-info-val">' + ev.ciudad + '</span>' +
        '</div>' +
        '<div class="evd-info-item">' +
          '<span class="evd-info-label">Cupo maximo</span>' +
          '<span class="evd-info-val mono-val">' + ev.cupo_maximo + '</span>' +
        '</div>' +
        '<div class="evd-info-item">' +
          '<span class="evd-info-label">Responsable</span>' +
          '<span class="evd-info-val">' + ev.responsable + '</span>' +
        '</div>' +
        (ev.desc_evento ?
          '<div class="evd-info-item evd-info-full">' +
            '<span class="evd-info-label">Descripcion</span>' +
            '<span class="evd-info-val">' + ev.desc_evento + '</span>' +
          '</div>' : '') +
      '</div>';

    /* KPIs */
    var elKpis = document.getElementById('evd-kpis');
    if (elKpis) elKpis.innerHTML =
      '<div class="evd-kpi"><div class="evd-kpi-val ckv-blue">' + ev.num_invitados + '</div><div class="evd-kpi-lbl">Invitados</div></div>' +
      '<div class="evd-kpi"><div class="evd-kpi-val ckv-purple">' + ev.num_confirmados + '</div><div class="evd-kpi-lbl">Confirmados</div></div>' +
      '<div class="evd-kpi"><div class="evd-kpi-val' + (ev.num_asistentes > 0 ? ' ckv-green' : '') + '">' + ev.num_asistentes + '</div><div class="evd-kpi-lbl">Asistieron</div></div>' +
      '<div class="evd-kpi"><div class="evd-kpi-val' + (tasaAsis >= 75 ? ' ckv-green' : tasaAsis >= 50 ? ' ckv-orange' : '') + '">' + tasaAsis + '%</div><div class="evd-kpi-lbl">Tasa asistencia</div></div>';

    /* Presupuesto */
    var elPresup = document.getElementById('evd-presupuesto');
    if (elPresup) {
      if (ev.presupuesto > 0) {
        elPresup.innerHTML =
          '<div class="cp-row"><span class="cp-label">Presupuesto total</span><span class="cp-val">' + _fmt$(ev.presupuesto) + '</span></div>' +
          '<div class="cp-row"><span class="cp-label">Gasto real</span><span class="cp-val" style="color:var(--accent)">' + _fmt$(ev.gasto_real) + '</span></div>' +
          '<div class="cp-bar-wrap"><div class="cp-bar-fill" style="width:' + pct + '%"></div></div>' +
          '<div class="cp-pct">' + pct + '% utilizado</div>';
      } else {
        elPresup.innerHTML = '<p class="evd-empty">Sin presupuesto registrado.</p>';
      }
    }

    /* Leads */
    var elLeads = document.getElementById('evd-leads');
    if (elLeads) {
      if (ev.leads && ev.leads.length > 0) {
        var leadsHTML = ev.leads.map(function (l) {
          var sc      = _scoreClass(l.val_score);
          var abadge  = ASIST_BADGE[l.estado_even] || 'badge-neutral';
          var initials = _initials(l.nom_lead);
          var avColor  = (typeof Utils !== 'undefined') ? Utils.avatarColor(l.nom_lead) : 'av-blue';
          return '<div class="evd-lead-item">' +
            '<div class="avatar ' + avColor + '" style="width:32px;height:32px;font-size:.72rem;flex-shrink:0">' + initials + '</div>' +
            '<div class="evd-lead-info">' +
              '<div class="evd-lead-name">' + l.nom_lead + '</div>' +
              '<div class="evd-lead-emp">' + l.empresa + '</div>' +
            '</div>' +
            '<div class="evd-lead-meta">' +
              '<span class="badge ' + abadge + '" style="font-size:.68rem">' + l.estado_even + '</span>' +
              '<span class="score-val ' + sc + '" style="font-size:.72rem">' + l.val_score + '</span>' +
            '</div>' +
          '</div>';
        }).join('');

        elLeads.innerHTML =
          '<div class="evd-leads-list">' + leadsHTML + '</div>' +
          '<div style="margin-top:12px">' +
            '<button class="btn-secondary btn-sm" id="evd-btn-exportar-leads">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">' +
              '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>' +
              '<polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' +
              ' Exportar asistentes CSV' +
            '</button>' +
          '</div>';

        /* Exportar CSV */
        var btnExp = document.getElementById('evd-btn-exportar-leads');
        if (btnExp) btnExp.addEventListener('click', function () { exportLeadsCSV(ev); });

      } else {
        elLeads.innerHTML = '<p class="evd-empty">Sin leads asociados a este evento.</p>';
      }
    }

    drawer.classList.add('drawer-open');
    if (overlay) overlay.classList.add('drawer-overlay-show');
    document.body.style.overflow = 'hidden';
  }


  /* ================================================================
     closeDrawer()
  ================================================================ */
  function closeDrawer() {
    var drawer  = document.getElementById('ev-drawer');
    var overlay = document.getElementById('drawer-overlay');
    if (drawer)  drawer.classList.remove('drawer-open');
    if (overlay) overlay.classList.remove('drawer-overlay-show');
    document.body.style.overflow = '';
  }


  /* ================================================================
     exportLeadsCSV(evento)
  ================================================================ */
  function exportLeadsCSV(ev) {
    if (!ev.leads || !ev.leads.length) {
      if (typeof Utils !== 'undefined') Utils.showToast('Sin leads para exportar', 'warning');
      return;
    }
    var headers = ['ID Lead', 'Nombre', 'Empresa', 'Estado', 'Score'];
    var rows    = ev.leads.map(function (l) {
      return [l.id_lead, l.nom_lead, l.empresa, l.estado_even, l.val_score];
    });
    var csv  = [headers].concat(rows).map(function (r) {
      return r.map(function (v) { return '"' + v + '"'; }).join(',');
    }).join('\n');
    var blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href     = url;
    a.download = 'asistentes_evento_' + ev.id_evento + '_' + ev.fec_inicio + '.csv';
    a.click();
    URL.revokeObjectURL(url);
    if (typeof Utils !== 'undefined') Utils.showToast('CSV exportado correctamente', 'success');
  }


  /* ── API publica ─────────────────────────────────────────── */
  return {
    buildKPIs      : buildKPIs,
    buildCalendario: buildCalendario,
    buildNavMes    : buildNavMes,
    buildTabla     : buildTabla,
    openDrawer     : openDrawer,
    closeDrawer    : closeDrawer,
    exportLeadsCSV : exportLeadsCSV,
  };

}());