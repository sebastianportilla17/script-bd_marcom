/* ================================================================
   js/eventos/data.js — Capa de Datos · Módulo Eventos
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.1 — Corregido

   PATRÓN SEGURO: no usa 'const' al nivel global.
   Usa window.X = window.X || {...} para evitar re-declaración
   si el script se ejecuta más de una vez (hot reload, cache).
   Idéntico al patrón correcto de getClientesData().
================================================================ */

/* ── Fallback de datos simulados ─────────────────────────────
   Espejo de: tab_evento + tab_even_lead + tab_presupuesto
──────────────────────────────────────────────────────────── */
window.EVENTOS_FALLBACK = window.EVENTOS_FALLBACK || {

  meta: { periodo: 'Marzo 2026', simulado: true },

  resumen: {
    totalEventos    : 8,
    eventosActivos  : 3,
    totalAsistentes : 563,
    tasaAsistencia  : 78.4,
    proximosEventos : 2,
  },

  filtros: {
    estados      : ['Todos', 'Activo', 'Finalizado', 'Cancelado', 'Borrador'],
    tipos        : ['Todos', 'Feria', 'Webinar', 'Lanzamiento', 'Taller', 'Conferencia'],
    responsables : ['Todos', 'Ana Torres', 'Pedro Ruiz', 'Luis Mora', 'Maria Lopez'],
  },

  eventos: [
    {
      id_evento       : 1,
      nom_evento      : 'Feria Internacional de Tecnologia 2026',
      desc_evento     : 'Participacion como expositor en la feria anual de tecnologia empresarial. Stand principal con demos en vivo del producto.',
      tipo_evento     : 'Feria',
      fec_inicio      : '2026-03-15',
      fec_fin         : '2026-03-17',
      lugar           : 'Centro de Convenciones Agora',
      ciudad          : 'Bogota',
      cupo_maximo     : 200,
      estado          : 'Activo',
      responsable     : 'Ana Torres',
      id_campana      : 'camp003',
      nom_campana     : 'LinkedIn B2B Q1',
      presupuesto     : 15000000,
      gasto_real      : 12500000,
      num_invitados   : 180,
      num_confirmados : 145,
      num_asistentes  : 120,
      leads: [
        { id_lead: 10000001, nom_lead: 'Carlos Mendoza',  empresa: 'TechCorp S.A.',        estado_even: 'Asistio',    val_score: 88 },
        { id_lead: 10000002, nom_lead: 'Laura Jimenez',   empresa: 'Innovatech SAS',       estado_even: 'Asistio',    val_score: 72 },
        { id_lead: 10000005, nom_lead: 'Felipe Vargas',   empresa: 'Distribuidora Sur',    estado_even: 'Confirmado', val_score: 91 },
        { id_lead: 10000007, nom_lead: 'Andres Ospina',   empresa: 'Logistica Express',    estado_even: 'Invitado',   val_score: 45 },
        { id_lead: 10000008, nom_lead: 'Valentina Cruz',  empresa: 'Agencia Creativa',     estado_even: 'Invitado',   val_score: 22 },
      ],
    },
    {
      id_evento       : 2,
      nom_evento      : 'Webinar: Transformacion Digital en PYMES',
      desc_evento     : 'Sesion virtual sobre estrategias de transformacion digital para pequeñas y medianas empresas.',
      tipo_evento     : 'Webinar',
      fec_inicio      : '2026-03-22',
      fec_fin         : '2026-03-22',
      lugar           : 'Zoom (Virtual)',
      ciudad          : 'Virtual',
      cupo_maximo     : 500,
      estado          : 'Activo',
      responsable     : 'Pedro Ruiz',
      id_campana      : 'camp005',
      nom_campana     : 'SEO Organico Blog',
      presupuesto     : 2000000,
      gasto_real      : 800000,
      num_invitados   : 450,
      num_confirmados : 310,
      num_asistentes  : 0,
      leads: [
        { id_lead: 10000003, nom_lead: 'Roberto Silva',   empresa: 'Grupo Alfa Ltda',      estado_even: 'Confirmado', val_score: 55 },
        { id_lead: 10000004, nom_lead: 'Marcela Rios',    empresa: 'Soluciones XYZ',       estado_even: 'Confirmado', val_score: 38 },
        { id_lead: 10000006, nom_lead: 'Diana Castillo',  empresa: 'Construcciones Norte', estado_even: 'Invitado',   val_score: 64 },
      ],
    },
    {
      id_evento       : 3,
      nom_evento      : 'Lanzamiento Producto Enterprise v3.0',
      desc_evento     : 'Evento exclusivo de lanzamiento de la nueva version Enterprise. Solo para clientes y prospectos calificados.',
      tipo_evento     : 'Lanzamiento',
      fec_inicio      : '2026-04-10',
      fec_fin         : '2026-04-10',
      lugar           : 'Hotel Sofitel Santa Clara',
      ciudad          : 'Cartagena',
      cupo_maximo     : 80,
      estado          : 'Activo',
      responsable     : 'Ana Torres',
      id_campana      : 'camp002',
      nom_campana     : 'Demo SaaS B2B',
      presupuesto     : 8000000,
      gasto_real      : 2100000,
      num_invitados   : 75,
      num_confirmados : 48,
      num_asistentes  : 0,
      leads: [
        { id_lead: 10000001, nom_lead: 'Carlos Mendoza',  empresa: 'TechCorp S.A.',        estado_even: 'Confirmado', val_score: 88 },
        { id_lead: 10000005, nom_lead: 'Felipe Vargas',   empresa: 'Distribuidora Sur',    estado_even: 'Confirmado', val_score: 91 },
        { id_lead: 10000009, nom_lead: 'Jorge Penaloza',  empresa: 'Finanzas Global',      estado_even: 'Confirmado', val_score: 61 },
      ],
    },
    {
      id_evento       : 4,
      nom_evento      : 'Taller: Growth Hacking para SaaS',
      desc_evento     : 'Taller practico de 4 horas sobre tecnicas de crecimiento acelerado para empresas SaaS.',
      tipo_evento     : 'Taller',
      fec_inicio      : '2026-02-18',
      fec_fin         : '2026-02-18',
      lugar           : 'WeWork Chico',
      ciudad          : 'Bogota',
      cupo_maximo     : 30,
      estado          : 'Finalizado',
      responsable     : 'Luis Mora',
      id_campana      : 'camp003',
      nom_campana     : 'LinkedIn B2B Q1',
      presupuesto     : 3000000,
      gasto_real      : 2850000,
      num_invitados   : 30,
      num_confirmados : 28,
      num_asistentes  : 25,
      leads: [
        { id_lead: 10000002, nom_lead: 'Laura Jimenez',   empresa: 'Innovatech SAS',       estado_even: 'Asistio',    val_score: 72 },
        { id_lead: 10000006, nom_lead: 'Diana Castillo',  empresa: 'Construcciones Norte', estado_even: 'Asistio',    val_score: 64 },
        { id_lead: 10000007, nom_lead: 'Andres Ospina',   empresa: 'Logistica Express',    estado_even: 'Asistio',    val_score: 45 },
      ],
    },
    {
      id_evento       : 5,
      nom_evento      : 'Conferencia Anual MARCOM 2025',
      desc_evento     : 'Conferencia anual interna del equipo de Marketing y Comercial. Revision de resultados 2025 y estrategia 2026.',
      tipo_evento     : 'Conferencia',
      fec_inicio      : '2025-12-05',
      fec_fin         : '2025-12-05',
      lugar           : 'Sede Principal',
      ciudad          : 'Bogota',
      cupo_maximo     : 120,
      estado          : 'Finalizado',
      responsable     : 'Maria Lopez',
      id_campana      : null,
      nom_campana     : null,
      presupuesto     : 5000000,
      gasto_real      : 4750000,
      num_invitados   : 115,
      num_confirmados : 110,
      num_asistentes  : 102,
      leads           : [],
    },
    {
      id_evento       : 6,
      nom_evento      : 'Webinar: Automatizacion de Marketing con IA',
      desc_evento     : 'Webinar sobre el uso de inteligencia artificial en la automatizacion de campanas de marketing B2B.',
      tipo_evento     : 'Webinar',
      fec_inicio      : '2026-02-05',
      fec_fin         : '2026-02-05',
      lugar           : 'Microsoft Teams (Virtual)',
      ciudad          : 'Virtual',
      cupo_maximo     : 300,
      estado          : 'Finalizado',
      responsable     : 'Pedro Ruiz',
      id_campana      : 'camp003',
      nom_campana     : 'LinkedIn B2B Q1',
      presupuesto     : 1500000,
      gasto_real      : 1200000,
      num_invitados   : 280,
      num_confirmados : 210,
      num_asistentes  : 198,
      leads: [
        { id_lead: 10000001, nom_lead: 'Carlos Mendoza',  empresa: 'TechCorp S.A.',        estado_even: 'Asistio',    val_score: 88 },
        { id_lead: 10000003, nom_lead: 'Roberto Silva',   empresa: 'Grupo Alfa Ltda',      estado_even: 'Asistio',    val_score: 55 },
        { id_lead: 10000004, nom_lead: 'Marcela Rios',    empresa: 'Soluciones XYZ',       estado_even: 'Invitado',   val_score: 38 },
      ],
    },
    {
      id_evento       : 7,
      nom_evento      : 'Feria Expo Construccion 2025',
      desc_evento     : 'Participacion en la feria del sector constructor. Generacion de leads del segmento construccion.',
      tipo_evento     : 'Feria',
      fec_inicio      : '2025-11-20',
      fec_fin         : '2025-11-22',
      lugar           : 'Corferias',
      ciudad          : 'Bogota',
      cupo_maximo     : 150,
      estado          : 'Finalizado',
      responsable     : 'Ana Torres',
      id_campana      : 'camp001',
      nom_campana     : 'Promo Black Friday',
      presupuesto     : 10000000,
      gasto_real      : 9800000,
      num_invitados   : 140,
      num_confirmados : 130,
      num_asistentes  : 118,
      leads: [
        { id_lead: 10000006, nom_lead: 'Diana Castillo',  empresa: 'Construcciones Norte', estado_even: 'Asistio',    val_score: 64 },
      ],
    },
    {
      id_evento       : 8,
      nom_evento      : 'Taller Avanzado: Negociacion B2B',
      desc_evento     : 'Taller de tecnicas avanzadas de negociacion para equipos comerciales. Certificacion incluida.',
      tipo_evento     : 'Taller',
      fec_inicio      : '2026-04-25',
      fec_fin         : '2026-04-25',
      lugar           : 'Centro de Formacion Empresarial',
      ciudad          : 'Medellin',
      cupo_maximo     : 40,
      estado          : 'Borrador',
      responsable     : 'Luis Mora',
      id_campana      : null,
      nom_campana     : null,
      presupuesto     : 4000000,
      gasto_real      : 0,
      num_invitados   : 0,
      num_confirmados : 0,
      num_asistentes  : 0,
      leads           : [],
    },
  ],
};

/* ================================================================
   getEventosData()
   Fetch a API (prod) o JSON local (dev). Fallback si falla.
   Patron identico a getClientesData() — ningun const global.
================================================================ */
window.getEventosData = window.getEventosData || async function getEventosData() {
  try {
    var endpoint = (typeof API !== 'undefined' && API.eventos)
      ? API.eventos
      : '../data/eventos.json';
    var res = await fetch(endpoint, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } catch (err) {
    console.warn('[MARCOM] getEventosData: usando datos simulados.', err.message);
    return window.EVENTOS_FALLBACK;
  }
};