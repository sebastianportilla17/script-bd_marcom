/**
 * auth.js — Módulo de Autenticación Compartido
 * Importado por TODAS las páginas del ERP.
 * Maneja: sesión, login, logout, protección de rutas.
 */
'use strict';

const AUTH = {
    SESSION_KEY: 'erp_session',
    USER_KEY:    'erp_user',
    LOGIN_URL: '../index.html',
    DEMO_USERS: [
                   { id:'u001', email:'Admin753', password:'Admin753', name:'Admin753', role:'Administrador', avatar:'AD' }
                ]
};

/* ── Sesión ── */
  async function mockAuth(email, password) {
  await new Promise(r => setTimeout(r, 500 + Math.random() * 400));
  const u = AUTH.DEMO_USERS.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
  if (!u) return null;
  const { password: _, ...safe } = u;
  return safe;
}

function createSession(user, remember) {
  const session = {
    token:   btoa(user.id + ':' + Date.now()),
    expires: Date.now() + (remember ? 7 * 86400000 : 8 * 3600000)
  };
  localStorage.setItem(AUTH.SESSION_KEY, JSON.stringify(session));
  localStorage.setItem(AUTH.USER_KEY,    JSON.stringify(user));
}

function destroySession() {
  localStorage.removeItem(AUTH.SESSION_KEY);
  localStorage.removeItem(AUTH.USER_KEY);
}

function isSessionActive() {
  try {
    const s = JSON.parse(localStorage.getItem(AUTH.SESSION_KEY));
    return s && s.expires > Date.now();
  } catch { return false; }
}

function getCurrentUser() {
  try { return JSON.parse(localStorage.getItem(AUTH.USER_KEY)); }
  catch { return null; }
}

/* ── Protección de rutas ── */
function requireAuth() {
  if (!isSessionActive()) {
    window.location.replace(AUTH.LOGIN_URL);
    return null;
  }
  return getCurrentUser();
}

function redirectIfAuthenticated(dest = 'dashboard.html') {
  if (isSessionActive()) window.location.replace(dest);
}

function logout() {
  destroySession();
  window.location.replace(AUTH.LOGIN_URL="../index.html");
}

/* ── Poblar UI con datos del usuario ── */
function populateUserUI(user) {
  if (!user) return;
  document.querySelectorAll('[data-user-name]').forEach(el   => el.textContent = user.name);
  document.querySelectorAll('[data-user-role]').forEach(el   => el.textContent = user.role);
  document.querySelectorAll('[data-user-avatar]').forEach(el => el.textContent = user.avatar);
}

/* ── Sidebar activa según página actual ── */
  function setActiveSidebarItem() {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.sb-item[href]').forEach(el => {
    el.classList.toggle('active', el.getAttribute('href') === page);
  });
}

/* ── Sidebar mobile ── */
function initMobileSidebar() {
  const btn     = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sb-overlay');
  btn?.addEventListener('click', () => {
    sidebar?.classList.add('open');
    overlay?.classList.add('show');
  });
  overlay?.addEventListener('click', () => {
    sidebar?.classList.remove('open');
    overlay?.classList.remove('show');
  });
}

/* ── Toast ── */
function showToast(msg, type = 'info', duration = 3000) {
  const icons = { success:'✅', danger:'❌', warning:'⚠️', info:'💡' };
  let c = document.getElementById('toast-container');
  if (!c) { c = document.createElement('div'); c.id = 'toast-container'; c.className = 'toast-container'; document.body.appendChild(c); }
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<span>${icons[type]||icons.info}</span> ${msg}`;
  c.appendChild(t);
  setTimeout(() => { t.style.cssText = 'opacity:0;transform:translateX(16px);transition:all .3s'; setTimeout(() => t.remove(), 300); }, duration);
}

/* ── Init páginas protegidas ── */
function initProtectedPage() {
  const user = requireAuth();
  if (!user) return null;
  populateUserUI(user);
  setActiveSidebarItem();
  initMobileSidebar();
  document.getElementById('btn-logout')?.addEventListener('click', logout);
  return user;
}

/* ── Validaciones ── */
function isValidEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim()) }

/* ── Expose ── */
window.Auth = { requireAuth, getCurrentUser, logout, isSessionActive, redirectIfAuthenticated, createSession, mockAuth, isValidEmail, initProtectedPage, showToast };
