/* ================================================================
   pipeline-init.js — Embudo de Ventas MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0
   ================================================================ */
'use strict';

/* ── Fallback data ───────────────────────────────────────────── */
const PIPELINE_FALLBACK = {
  meta: { periodo:'Marzo 2026', simulado:true },
  filtros: {
    vendedores: ['Todos','Ana Torres','Pedro Ruiz','Luis Mora'],
    campanas  : ['Todas','Black Friday Digital','LinkedIn B2B Q1','SEO Orgánico Blog','Referidos Partner'],
    periodos  : ['Este mes','Último trimestre','Este año'],
  },
  resumen: { totalLeads:868, valorPipeline:1840000000, tasaConversion:23.4, tiempoPromedio:18 },
  etapas: [
    { id:1, nombre:'Prospecto',   leads:287, valor:2100000000, tiempoProm:2,  color:'#94A3B8', colorLight:'rgba(148,163,184,0.12)', pctAnterior:100, conversion:69  },
    { id:2, nombre:'Contactado',  leads:198, valor:1450000000, tiempoProm:5,  color:'#0057FF', colorLight:'rgba(0,87,255,0.10)',     pctAnterior:69,  conversion:78  },
    { id:3, nombre:'Interesado',  leads:154, valor:980000000,  tiempoProm:8,  color:'#7C3AED', colorLight:'rgba(124,58,237,0.10)',   pctAnterior:78,  conversion:64  },
    { id:4, nombre:'Propuesta',   leads:98,  valor:720000000,  tiempoProm:12, color:'#F79009', colorLight:'rgba(247,144,9,0.10)',    pctAnterior:64,  conversion:63  },
    { id:5, nombre:'Negociación', leads:62,  valor:480000000,  tiempoProm:18, color:'#F04438', colorLight:'rgba(240,68,56,0.10)',    pctAnterior:63,  conversion:null},
    { id:6, nombre:'Ganado',      leads:69,  valor:284500000,  tiempoProm:null,color:'#00A76F',colorLight:'rgba(0,167,111,0.10)',   pctAnterior:null,conversion:null},
    { id:7, nombre:'Perdido',     leads:87,  valor:null,       tiempoProm:null,color:'#6B7280',colorLight:'rgba(107,114,128,0.10)', pctAnterior:null,conversion:null, motivoTop:'Precio muy alto (34%)'},
  ],
  motivosPerdida: [
    { motivo:'Precio muy alto',       cantidad:30, pct:34 },
    { motivo:'Eligió la competencia', cantidad:21, pct:24 },
    { motivo:'Sin presupuesto',       cantidad:18, pct:21 },
    { motivo:'No era el momento',     cantidad:11, pct:13 },
    { motivo:'Sin respuesta',         cantidad:7,  pct:8  },
  ],
  leads: [
    { id:'l001', nombre:'Carlos Mendoza',  empresa:'TechCorp S.A.',        etapa:'Prospecto',   etapaId:1, score:45, valor:12000000, vendedor:'Ana Torres',  diasEtapa:2,  ultimoContacto:'2026-03-07' },
    { id:'l002', nombre:'Laura Jiménez',   empresa:'Innovatech',           etapa:'Contactado',  etapaId:2, score:62, valor:8200000,  vendedor:'Pedro Ruiz',  diasEtapa:5,  ultimoContacto:'2026-03-05' },
    { id:'l003', nombre:'Roberto Silva',   empresa:'Grupo Alfa',           etapa:'Interesado',  etapaId:3, score:70, valor:22000000, vendedor:'Ana Torres',  diasEtapa:8,  ultimoContacto:'2026-03-01' },
    { id:'l004', nombre:'Marcela Ríos',    empresa:'Soluciones XYZ',       etapa:'Prospecto',   etapaId:1, score:38, valor:3200000,  vendedor:'Luis Mora',   diasEtapa:16, ultimoContacto:'2026-02-22' },
    { id:'l005', nombre:'Felipe Vargas',   empresa:'Distribuidora Sur',    etapa:'Negociación', etapaId:5, score:91, valor:9800000,  vendedor:'Pedro Ruiz',  diasEtapa:3,  ultimoContacto:'2026-03-08' },
    { id:'l006', nombre:'Diana Castillo',  empresa:'Construcciones Norte', etapa:'Propuesta',   etapaId:4, score:64, valor:14500000, vendedor:'Luis Mora',   diasEtapa:9,  ultimoContacto:'2026-03-03' },
    { id:'l007', nombre:'Andrés Mora',     empresa:'FinServ Colombia',     etapa:'Interesado',  etapaId:3, score:77, valor:28000000, vendedor:'Ana Torres',  diasEtapa:6,  ultimoContacto:'2026-03-01' },
    { id:'l008', nombre:'Valentina Cruz',  empresa:'Retail Express',       etapa:'Contactado',  etapaId:2, score:55, valor:6500000,  vendedor:'Pedro Ruiz',  diasEtapa:4,  ultimoContacto:'2026-02-28' },
    { id:'l009', nombre:'Jorge Patiño',    empresa:'Agro Sur S.A.',        etapa:'Propuesta',   etapaId:4, score:68, valor:18000000, vendedor:'Luis Mora',   diasEtapa:11, ultimoContacto:'2026-02-25' },
    { id:'l010', nombre:'Sofía Herrera',   empresa:'Médica Plus',          etapa:'Negociación', etapaId:5, score:83, valor:32000000, vendedor:'Ana Torres',  diasEtapa:7,  ultimoContacto:'2026-03-06' },
    { id:'l011', nombre:'Camilo Restrepo', empresa:'LogiTrans',            etapa:'Ganado',      etapaId:6, score:95, valor:15000000, vendedor:'Pedro Ruiz',  diasEtapa:0,  ultimoContacto:'2026-03-08' },
    { id:'l012', nombre:'Natalia Gómez',   empresa:'EduTech SAS',          etapa:'Perdido',     etapaId:7, score:30, valor:0,        vendedor:'Luis Mora',   diasEtapa:0,  ultimoContacto:'2026-02-10' },
    { id:'l013', nombre:'Ricardo Peña',    empresa:'Industrias Beta',      etapa:'Prospecto',   etapaId:1, score:42, valor:7500000,  vendedor:'Ana Torres',  diasEtapa:3,  ultimoContacto:'2026-03-06' },
    { id:'l014', nombre:'Paola Vargas',    empresa:'Clínica Central',      etapa:'Interesado',  etapaId:3, score:71, valor:19000000, vendedor:'Pedro Ruiz',  diasEtapa:10, ultimoContacto:'2026-02-27' },
    { id:'l015', nombre:'Hernán López',    empresa:'Constructora Omega',   etapa:'Contactado',  etapaId:2, score:58, valor:11000000, vendedor:'Luis Mora',   diasEtapa:6,  ultimoContacto:'2026-03-02' },
  ],
};

/* ── Helpers ─────────────────────────────────────────────────── */
function fmt$(v) {
  if (v === null || v === undefined) return '—';
  if (Math.abs(v) >= 1e9) return `$${(v/1e9).toFixed(1)}B`;
  if (Math.abs(v) >= 1e6) return `$${(v/1e6).toFixed(0)}M`;
  if (Math.abs(v) >= 1e3) return `$${(v/1e3).toFixed(0)}K`;
  return '$' + Math.round(v).toLocaleString('es-CO');
}
function fmtDate(s) {
  if (!s) return '—';
  return new Date(s+'T00:00:00').toLocaleDateString('es-CO',{day:'2-digit',month:'short'});
}
const AV = ['av-blue','av-green','av-purple','av-orange','av-teal','av-pink','av-red'];
function avColor(n='') { let h=0; for(let i=0;i<n.length;i++) h+=n.charCodeAt(i); return AV[h%AV.length]; }
function initials(n='') { const p=n.trim().split(/\s+/); return p.length>=2?(p[0][0]+p[1][0]).toUpperCase():n.slice(0,2).toUpperCase(); }
function scoreClass(s) {
  if (s>=70) return { fill:'sf-high', val:'sv-high' };
  if (s>=40) return { fill:'sf-mid',  val:'sv-mid'  };
  return { fill:'sf-low', val:'sv-low' };
}
function agingClass(d) {
  if (d<=5)  return 'aging-ok';
  if (d<=12) return 'aging-warn';
  return 'aging-crit';
}
function animCounter(el, target, format='integer', dur=900) {
  if (!el) return;
  const start = performance.now();
  const step = now => {
    const p = Math.min((now-start)/dur, 1);
    const e = 1 - Math.pow(2,-10*p);
    const v = target * e;
    if (format==='currency') el.textContent = fmt$(v);
    else if (format==='percent') el.textContent = v.toFixed(1)+'%';
    else el.textContent = Math.round(v).toLocaleString('es-CO');
    if (p<1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

/* ── Estado ──────────────────────────────────────────────────── */
let DATA          = null;
let activeEtapaId = null; /* null = todas */

/* ── Sidebar ─────────────────────────────────────────────────── */
function buildNav() {
  const nav = document.getElementById('sb-nav');
  if (!nav || typeof NAV_ITEMS==='undefined') return;
  nav.innerHTML = '';
  let section = null;
  const page = location.pathname.split('/').pop() || 'index.html';
  NAV_ITEMS.forEach(item => {
    if (item.section !== section) {
      section = item.section;
      if (item.section) {
        const lbl = document.createElement('div');
        lbl.className = 'sb-section-label';
        lbl.textContent = item.section;
        nav.appendChild(lbl);
      }
    }
    const active = page === item.url;
    const iconSvg = (typeof ICONS!=='undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
    const a = document.createElement('a');
    a.className = `sb-item${active?' active':''}`;
    a.href = item.url;
    a.innerHTML = `<span class="sb-item-icon">${iconSvg}</span><span class="sb-item-label">${item.label}</span>`;
    nav.appendChild(a);
  });
}

/* ── KPIs resumen ────────────────────────────────────────────── */
function renderKPIs(r) {
  const kpis = [
    { id:'kpi-leads',  val:r.totalLeads,      fmt:'integer',  label:'Leads en Pipeline', color:'blue',   icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>`,  trend:'+18%',  trendCls:'kct-up'  },
    { id:'kpi-valor',  val:r.valorPipeline,   fmt:'currency', label:'Valor del Pipeline', color:'green',  icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>`, trend:'+24%',  trendCls:'kct-up'  },
    { id:'kpi-conv',   val:r.tasaConversion,  fmt:'percent',  label:'Tasa de Conversión', color:'purple', icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>`,                                                            trend:'Meta 25%', trendCls:'kct-info'},
    { id:'kpi-tiempo', val:r.tiempoPromedio,  fmt:'integer',  label:'Días Promedio Cierre',color:'orange', icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,                      trend:'-3 días', trendCls:'kct-up'  },
  ];
  const colorMap = { blue:'kc-blue', green:'kc-green', purple:'kc-purple', orange:'kc-orange' };
  const iconMap  = { blue:'kci-blue', green:'kci-green', purple:'kci-purple', orange:'kci-orange' };

  const grid = document.getElementById('kpis-row');
  if (!grid) return;
  grid.innerHTML = '';

  kpis.forEach((k,i) => {
    const card = document.createElement('div');
    card.className = `kpi-card ${colorMap[k.color]} anim anim-${i+1}`;
    let dispVal = k.fmt==='currency' ? fmt$(k.val) : k.fmt==='percent' ? k.val.toFixed(1)+'%' : k.val.toLocaleString('es-CO');
    if (k.id==='kpi-tiempo') dispVal += ' días';
    card.innerHTML = `
      <div class="kpi-card-top">
        <div class="kc-icon ${iconMap[k.color]}">${k.icon}</div>
        <span class="kc-trend ${k.trendCls}">${k.trend}</span>
      </div>
      <div class="kc-value" id="${k.id}">${dispVal}</div>
      <div class="kc-label">${k.label}</div>`;
    grid.appendChild(card);

    requestAnimationFrame(() => {
      const el = document.getElementById(k.id);
      if (el) animCounter(el, k.val, k.fmt);
    });
  });
}

/* ── Embudo visual ───────────────────────────────────────────── */
function renderFunnel(etapas) {
  const body = document.getElementById('funnel-body');
  if (!body) return;

  const maxLeads = etapas[0]?.leads ?? 1;
  const activas  = etapas.filter(e => e.id <= 5); /* solo las del funnel */
  const ganado   = etapas.find(e => e.id === 6);
  const perdido  = etapas.find(e => e.id === 7);

  let html = '';

  activas.forEach((e, idx) => {
    const widthPct = Math.max((e.leads / maxLeads) * 100, 8);
    const isActive = activeEtapaId === e.id;

    /* Flecha de conversión ANTES de la etapa (excepto la primera) */
    if (idx > 0 && e.pctAnterior !== null) {
      const prev = activas[idx-1];
      const pct  = Math.round((e.leads / prev.leads) * 100);
      const cls  = pct >= 70 ? 'fsc-good' : pct >= 50 ? 'fsc-mid' : 'fsc-low';
      html += `
        <div class="fs-conversion">
          <div class="fsc-arrow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </div>
          <span class="fsc-pct ${cls}">${pct}%</span>
          <span class="fsc-label">pasan a ${e.nombre}</span>
        </div>`;
    }

    const valorStr   = e.valor       ? fmt$(e.valor)       : '—';
    const tiempoStr  = e.tiempoProm  ? `${e.tiempoProm}d`  : '—';

    html += `
      <div class="funnel-stage${isActive ? ' fs-active' : ''}" data-etapa-id="${e.id}">
        <div class="fs-label">
          <span class="fs-dot" style="background:${e.color}"></span>
          ${e.nombre}
        </div>
        <div class="fs-bar-wrap">
          <div class="fs-bar" style="width:${widthPct}%;background:${e.color}">
            <span class="fs-bar-leads">${e.leads}</span>
          </div>
        </div>
        <div class="fs-metrics">
          <div class="fs-metric">
            <span class="fsm-val">${valorStr}</span>
            <span class="fsm-lbl">Valor pot.</span>
          </div>
          <div class="fs-metric">
            <span class="fsm-val">${tiempoStr}</span>
            <span class="fsm-lbl">Prom. días</span>
          </div>
        </div>
      </div>`;
  });

  /* Separador */
  html += `
    <div class="fs-separator">
      <span class="fs-separator-label">Resultado final</span>
    </div>`;

  /* Ganado */
  if (ganado) {
    const isActive = activeEtapaId === ganado.id;
    html += `
      <div class="funnel-stage${isActive ? ' fs-active' : ''}" data-etapa-id="${ganado.id}">
        <div class="fs-label">
          <span class="fs-dot" style="background:${ganado.color}"></span>
          ✓ ${ganado.nombre}
        </div>
        <div class="fs-bar-wrap">
          <div class="fs-bar" style="width:${Math.max((ganado.leads/maxLeads)*100,4)}%;background:${ganado.color}">
            <span class="fs-bar-leads">${ganado.leads}</span>
          </div>
        </div>
        <div class="fs-metrics">
          <div class="fs-metric">
            <span class="fsm-val">${fmt$(ganado.valor)}</span>
            <span class="fsm-lbl">Revenue</span>
          </div>
          <div class="fs-metric">
            <span class="fsm-val">${((ganado.leads/etapas[0].leads)*100).toFixed(1)}%</span>
            <span class="fsm-lbl">Conv. total</span>
          </div>
        </div>
      </div>`;
  }

  /* Perdido */
  if (perdido) {
    const isActive = activeEtapaId === perdido.id;
    html += `
      <div class="funnel-stage${isActive ? ' fs-active' : ''}" data-etapa-id="${perdido.id}">
        <div class="fs-label">
          <span class="fs-dot" style="background:${perdido.color}"></span>
          ✗ ${perdido.nombre}
        </div>
        <div class="fs-bar-wrap">
          <div class="fs-bar" style="width:${Math.max((perdido.leads/maxLeads)*100,4)}%;background:${perdido.color}">
            <span class="fs-bar-leads">${perdido.leads}</span>
          </div>
        </div>
        <div class="fs-metrics">
          <div class="fs-metric">
            <span class="fsm-val" style="color:var(--danger)">${perdido.motivoTop ?? '—'}</span>
            <span class="fsm-lbl">Motivo top</span>
          </div>
          <div class="fs-metric">
            <span class="fsm-val">${((perdido.leads/etapas[0].leads)*100).toFixed(1)}%</span>
            <span class="fsm-lbl">Pérdida</span>
          </div>
        </div>
      </div>`;
  }

  body.innerHTML = html;

  /* Click en etapa → filtra tabla */
  body.querySelectorAll('.funnel-stage').forEach(row => {
    row.addEventListener('click', () => {
      const id = parseInt(row.dataset.etapaId);
      activeEtapaId = activeEtapaId === id ? null : id;
      renderFunnel(DATA.etapas);
      renderLeadsTabla(DATA.leads);
      renderStageTabs(DATA.etapas);
      syncActiveTab();
    });
  });
}

/* ── Motivos de pérdida ──────────────────────────────────────── */
function renderMotivos(motivos) {
  const el = document.getElementById('motivos-body');
  if (!el) return;
  const colors = ['mb-1','mb-2','mb-3','mb-4','mb-5'];
  el.innerHTML = motivos.map((m,i) => `
    <div class="motivo-item">
      <div class="motivo-top">
        <span class="motivo-nombre">${m.motivo}</span>
        <span class="motivo-pct">${m.pct}%</span>
      </div>
      <div class="motivo-bar-wrap">
        <div class="motivo-bar-fill ${colors[i]}" style="width:${m.pct}%"></div>
      </div>
      <div class="motivo-cantidad">${m.cantidad} leads</div>
    </div>`).join('');
}

/* ── Tabs de etapas ──────────────────────────────────────────── */
function renderStageTabs(etapas) {
  const tabs = document.getElementById('stage-tabs');
  if (!tabs) return;

  const todas = { id:null, nombre:'Todos', color:'#94A3B8', leads: DATA.leads.length };
  const items = [todas, ...etapas];

  tabs.innerHTML = items.map(e => {
    const count  = e.id === null ? DATA.leads.length : DATA.leads.filter(l => l.etapaId === e.id).length;
    const active = activeEtapaId === e.id;
    return `
      <button class="stage-tab${active?' st-active':''}" data-tab-id="${e.id ?? 'null'}">
        <span class="st-dot" style="background:${e.color}"></span>
        ${e.nombre}
        <span class="st-badge">${count}</span>
      </button>`;
  }).join('');

  tabs.querySelectorAll('.stage-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const raw = btn.dataset.tabId;
      activeEtapaId = raw === 'null' ? null : parseInt(raw);
      renderFunnel(DATA.etapas);
      renderLeadsTabla(DATA.leads);
      syncActiveTab();
    });
  });
}

function syncActiveTab() {
  document.querySelectorAll('.stage-tab').forEach(btn => {
    const raw = btn.dataset.tabId;
    const id  = raw === 'null' ? null : parseInt(raw);
    btn.classList.toggle('st-active', id === activeEtapaId);
  });
}

/* ── Tabla de leads ──────────────────────────────────────────── */
function renderLeadsTabla(leads) {
  const tbody   = document.getElementById('leads-tbody');
  const title   = document.getElementById('ls-dynamic-title');
  const counter = document.getElementById('ls-count');
  if (!tbody) return;

  const filtered = activeEtapaId === null
    ? leads
    : leads.filter(l => l.etapaId === activeEtapaId);

  const etapa = activeEtapaId
    ? DATA.etapas.find(e => e.id === activeEtapaId)
    : null;

  if (title)   title.textContent   = etapa ? `Leads · ${etapa.nombre}` : 'Todos los Leads';
  if (counter) counter.textContent = filtered.length;

  if (!filtered.length) {
    tbody.innerHTML = `
      <tr><td colspan="7">
        <div class="table-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
          </svg>
          <p>Sin leads en esta etapa</p>
        </div>
      </td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(l => {
    const av  = avColor(l.nombre);
    const ini = initials(l.nombre);
    const sc  = scoreClass(l.score);
    const agC = agingClass(l.diasEtapa);
    const etapaInfo = DATA.etapas.find(e => e.id === l.etapaId);
    const etapaBadge = etapaInfo
      ? `<span class="badge" style="background:${etapaInfo.colorLight};color:${etapaInfo.color};font-size:.68rem;font-weight:600;padding:2px 8px;border-radius:20px">${l.etapa}</span>`
      : '';

    return `
      <tr>
        <td>
          <div class="lead-cell">
            <div class="avatar ${av}">${ini}</div>
            <div>
              <div class="lead-name">${l.nombre}</div>
              <div class="lead-emp">${l.empresa}</div>
            </div>
          </div>
        </td>
        <td>${etapaBadge}</td>
        <td>
          <div class="score-wrap">
            <div class="score-bar"><div class="score-fill ${sc.fill}" style="width:${l.score}%"></div></div>
            <span class="score-val ${sc.val}">${l.score}</span>
          </div>
        </td>
        <td><span class="valor-mono">${fmt$(l.valor)}</span></td>
        <td><span class="${agC}">${l.diasEtapa}d</span></td>
        <td class="t-sm t-second">${l.vendedor}</td>
        <td class="t-mono t-sm t-muted">${fmtDate(l.ultimoContacto)}</td>
      </tr>`;
  }).join('');
}

/* ── Llenar filtros ──────────────────────────────────────────── */
function populateFiltros(filtros) {
  const selVend = document.getElementById('filter-vendedor');
  const selCamp = document.getElementById('filter-campana');
  const selPer  = document.getElementById('filter-periodo');

  filtros.vendedores?.forEach(v => {
    const o = document.createElement('option');
    o.value = v; o.textContent = v;
    selVend?.appendChild(o);
  });
  filtros.campanas?.forEach(c => {
    const o = document.createElement('option');
    o.value = c; o.textContent = c;
    selCamp?.appendChild(o);
  });
  filtros.periodos?.forEach(p => {
    const o = document.createElement('option');
    o.value = p; o.textContent = p;
    selPer?.appendChild(o);
  });
}

/* ════════════════════════════════════════════════════════════════
   INIT PRINCIPAL
════════════════════════════════════════════════════════════════ */
window.addEventListener('load', async () => {

  /* 1. Sesión */
  if (typeof Auth !== 'undefined') {
    const user = Auth.initProtectedPage();
    if (!user) return;
  }

  /* 2. Fecha */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge) dateBadge.textContent = new Date().toLocaleDateString('es-CO',{
    weekday:'short', day:'numeric', month:'short', year:'numeric'
  });

  /* 3. Datos */
  try {
    const endpoint = (typeof API !== 'undefined' && API.pipeline)
      ? API.pipeline : '../data/pipeline.json';
    const res = await fetch(endpoint, { cache:'no-store' });
    DATA = res.ok ? await res.json() : PIPELINE_FALLBACK;
  } catch {
    DATA = PIPELINE_FALLBACK;
  }

  /* 4. Nav */
  buildNav();

  /* 5. Render */
  renderKPIs(DATA.resumen);
  renderFunnel(DATA.etapas);
  renderMotivos(DATA.motivosPerdida);
  renderStageTabs(DATA.etapas);
  renderLeadsTabla(DATA.leads);
  populateFiltros(DATA.filtros);

  /* 6. Subtítulo */
  const sub = document.getElementById('page-sub');
  if (sub) sub.textContent = `${DATA.leads.length} leads en seguimiento · ${DATA.meta?.periodo ?? ''}`;

  /* 7. Eventos filtros (simulado: solo toast) */
  ['filter-vendedor','filter-campana','filter-periodo'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', e => {
      const val = e.target.value;
      const isDefault = val === 'Todos' || val === 'Todas' || val === 'Este mes';
      if (!isDefault && typeof Utils !== 'undefined')
        Utils.showToast(`Filtro aplicado: ${val}`, 'info', 2000);
    });
  });

  /* 8. Eventos globales */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark === 'function') toggleDark();
  });
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('Sin notificaciones nuevas', 'info');
  });
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    if (typeof Auth !== 'undefined') Auth.logout();
  });

  /* Sidebar móvil */
  const mobBtn  = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const sbOv    = document.getElementById('sb-overlay');
  mobBtn?.addEventListener('click',  () => { sidebar?.classList.toggle('sidebar-open'); sbOv?.classList.toggle('overlay-show'); });
  sbOv?.addEventListener('click',    () => { sidebar?.classList.remove('sidebar-open'); sbOv?.classList.remove('overlay-show'); });

  /* 9. Toast */
  setTimeout(() => {
    if (typeof Utils !== 'undefined')
      Utils.showToast(`${DATA.resumen.totalLeads} leads activos en el embudo`, 'success', 2500);
  }, 600);

});