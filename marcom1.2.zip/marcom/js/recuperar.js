// ════════════════════════════════════════
// RECUPERAR.JS – Recuperación de contraseña
// ════════════════════════════════════════

// ← Cambia este correo al del administrador del sistema
const ADMIN_EMAIL = 'camaro.adso@gmail.com';

let currentStep = 1;

// ── NAVEGACIÓN ENTRE PASOS ──────────────
function goStep(n) {
  if (n > currentStep && !validateStep(currentStep)) return;

  const checkSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"
    fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="20 6 9 17 4 12"/></svg>`;

  for (let i = 1; i <= 4; i++) {
    const dot    = document.getElementById('dot-' + i);
    const circle = document.getElementById('circle-' + i);
    const line   = document.getElementById('line-' + i);

    dot.classList.remove('active', 'done');
    if (line) line.classList.remove('done');

    if (i < n) {
      dot.classList.add('done');
      circle.innerHTML = checkSvg;
      if (line) line.classList.add('done');
    } else if (i === n) {
      dot.classList.add('active');
      if (i <= 3) circle.innerHTML = i;
    } else {
      if (i <= 3) circle.innerHTML = i;
    }
  }

  document.querySelectorAll('.step-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('panel-' + n).classList.add('active');

  if (n === 4) fillConfirmation();

  currentStep = n;
}

// ── VALIDACIONES POR PASO ───────────────
function validateStep(step) {
  let ok = true;

  if (step === 1) {
    const empresa = document.getElementById('empresa-input').value.trim();
    const nit     = document.getElementById('nit-input').value.trim();
    const eErr    = document.getElementById('empresa-error');
    const nErr    = document.getElementById('nit-error');
    eErr.textContent = '';
    nErr.textContent = '';
    if (!empresa) { eErr.textContent = 'Ingresa el nombre de la empresa'; ok = false; }
    if (!nit)     { nErr.textContent = 'Ingresa el NIT o identificación';  ok = false; }
  }

  if (step === 2) {
    const usuario = document.getElementById('usuario-input').value.trim();
    const correo  = document.getElementById('correo-input').value.trim();
    const cedula  = document.getElementById('cedula-input').value.trim();
    const uErr    = document.getElementById('usuario-error');
    const cErr    = document.getElementById('correo-error');
    const dErr    = document.getElementById('cedula-error');
    uErr.textContent = ''; cErr.textContent = ''; dErr.textContent = '';
    if (!usuario) { uErr.textContent = 'Ingresa tu nombre de usuario'; ok = false; }
    if (!correo)  { cErr.textContent = 'Ingresa tu correo electrónico'; ok = false; }
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) { cErr.textContent = 'Correo no válido'; ok = false; }
    if (!cedula)  { dErr.textContent = 'Ingresa tu cédula o ID'; ok = false; }
  }

  if (step === 3) {
    const modulo = document.getElementById('modulo-select').value;
    const motivo = document.getElementById('motivo-select').value;
    const mErr   = document.getElementById('modulo-error');
    const moErr  = document.getElementById('motivo-error');
    mErr.textContent = ''; moErr.textContent = '';
    if (!modulo) { mErr.textContent = 'Selecciona el módulo';  ok = false; }
    if (!motivo) { moErr.textContent = 'Selecciona el motivo'; ok = false; }
  }

  return ok;
}

// ── RELLENAR PANTALLA DE CONFIRMACIÓN ───
function fillConfirmation() {
  document.getElementById('conf-empresa').textContent = document.getElementById('empresa-input').value.trim();
  document.getElementById('conf-nit').textContent     = document.getElementById('nit-input').value.trim();
  document.getElementById('conf-usuario').textContent = document.getElementById('usuario-input').value.trim();
  document.getElementById('conf-correo').textContent  = document.getElementById('correo-input').value.trim();
  document.getElementById('conf-cedula').textContent  = document.getElementById('cedula-input').value.trim();
  document.getElementById('conf-modulo').textContent  = document.getElementById('modulo-select').value;
  document.getElementById('conf-motivo').textContent  = document.getElementById('motivo-select').value;
}

// ── ABRIR GMAIL CON CORREO PRELLENADO ───
function enviarGmail() {
  const empresa = document.getElementById('empresa-input').value.trim();
  const nit     = document.getElementById('nit-input').value.trim();
  const usuario = document.getElementById('usuario-input').value.trim();
  const correo  = document.getElementById('correo-input').value.trim();
  const cedula  = document.getElementById('cedula-input').value.trim();
  const modulo  = document.getElementById('modulo-select').value;
  const motivo  = document.getElementById('motivo-select').value;

  const fecha = new Date().toLocaleString('es-CO', {
    year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });

  const asunto = `[GDCAL] Solicitud de recuperación de acceso – ${usuario} · ${empresa}`;

  const cuerpo =
`Estimado Administrador,

Se ha recibido una solicitud de recuperación de acceso al Sistema de Gestión Documental y Calidad (GDCAL).

═══════════════════════════════════════
  DATOS DE LA SOLICITUD
═══════════════════════════════════════

  Empresa:              ${empresa}
  NIT / Identificación: ${nit}

  Usuario:              ${usuario}
  Correo registrado:    ${correo}
  Cédula / ID:          ${cedula}

  Módulo:               ${modulo}
  Motivo:               ${motivo}

  Fecha de solicitud:   ${fecha}

═══════════════════════════════════════

Por favor verifique la identidad del usuario y proceda con el restablecimiento de acceso según los procedimientos establecidos en el sistema.

Si esta solicitud no fue realizada por usted, ignórela y notifique al área de seguridad.

─────────────────────────────────────
Sistema GDCAL · Gestión Documental y Calidad
© 2026 ADSO`;

  const gmailUrl = 'https://mail.google.com/mail/?view=cm&fs=1'
    + '&to='   + encodeURIComponent(ADMIN_EMAIL)
    + '&su='   + encodeURIComponent(asunto)
    + '&body=' + encodeURIComponent(cuerpo);

  window.open(gmailUrl, '_blank');
}