/* ================================================================
   js/configuracion/data.js — Capa de Datos Configuración MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Datos simulados que replican EXACTAMENTE las tablas del BD:
     · tab_pmtros_marcom
     · tab_etapas_funnel
     · tab_canales
     · tab_criterios_segmentacion + tab_valores_segmentacion
     · tab_motivos_perdida
     · tab_kpis_campana
     · usuarios (simulado — en prod viene de SECURE/PHP)
================================================================ */
'use strict';

const FALLBACK_CFG_DATA = {

  /* ============================================================
     tab_pmtros_marcom
     Una fila por empresa. Reflejada como objeto plano.
  ============================================================ */
  parametros: {
    id_empresa              : 10000001,
    val_dias_sin_interaccion: 15,   /* días sin actividad antes de alertar al vendedor */
    val_dias_expiracion_lead: 90,   /* días máximos de vida de un lead                 */
    val_score_min_tibio     : 40,   /* score mínimo para clasificar lead como tibio    */
    val_score_min_caliente  : 70,   /* score mínimo para clasificar lead como caliente */
    val_max_contactos_adic  : 2,    /* máximo de contactos adicionales por tercero     */
    val_presupuesto_defecto : 0,    /* presupuesto inicial sugerido al crear campaña   */
    val_por_apertura_exito  : 20,   /* % de apertura para considerar email exitoso     */
  },

  /* Meta de cada parámetro para mostrar en la UI */
  parametrosMeta: [
    {
      campo   : 'val_dias_sin_interaccion',
      label   : 'Días sin interacción',
      desc    : 'Días sin actividad antes de alertar al vendedor sobre un lead inactivo.',
      unidad  : 'días',
      min     : 1,
      max     : 365,
      tipo    : 'number',
    },
    {
      campo   : 'val_dias_expiracion_lead',
      label   : 'Días de expiración del lead',
      desc    : 'Días máximos de vida de un lead antes de marcarse como perdido automáticamente.',
      unidad  : 'días',
      min     : 1,
      max     : 365,
      tipo    : 'number',
    },
    {
      campo   : 'val_score_min_tibio',
      label   : 'Score mínimo — Lead Tibio',
      desc    : 'Score mínimo para clasificar un lead como tibio. Debe ser menor al score caliente.',
      unidad  : 'puntos',
      min     : 1,
      max     : 99,
      tipo    : 'number',
      constraint: 'Debe ser menor a "Score mínimo — Lead Caliente"',
    },
    {
      campo   : 'val_score_min_caliente',
      label   : 'Score mínimo — Lead Caliente',
      desc    : 'Score mínimo para clasificar un lead como caliente. Debe ser mayor al score tibio.',
      unidad  : 'puntos',
      min     : 2,
      max     : 100,
      tipo    : 'number',
      constraint: 'Debe ser mayor a "Score mínimo — Lead Tibio"',
    },
    {
      campo   : 'val_max_contactos_adic',
      label   : 'Máx. contactos adicionales',
      desc    : 'Número máximo de contactos adicionales permitidos por tercero jurídico.',
      unidad  : 'contactos',
      min     : 1,
      max     : 20,
      tipo    : 'number',
    },
    {
      campo   : 'val_presupuesto_defecto',
      label   : 'Presupuesto por defecto',
      desc    : 'Presupuesto inicial sugerido al crear una campaña nueva.',
      unidad  : 'COP $',
      min     : 0,
      max     : null,
      tipo    : 'number',
    },
    {
      campo   : 'val_por_apertura_exito',
      label   : '% apertura de email exitoso',
      desc    : 'Porcentaje de apertura mínimo para considerar un email marketing como exitoso.',
      unidad  : '%',
      min     : 1,
      max     : 100,
      tipo    : 'number',
    },
  ],

  /* ============================================================
     tab_etapas_funnel
  ============================================================ */
  etapasFunnel: [
    { id_etapa: 1, nom_etapa: 'Prospecto',         des_etapa: 'Lead identificado pero aún sin contacto',             num_orden: 1, ind_etapa_final: false, ind_estado: true  },
    { id_etapa: 2, nom_etapa: 'Contactado',         des_etapa: 'Se realizó el primer contacto con el lead',           num_orden: 2, ind_etapa_final: false, ind_estado: true  },
    { id_etapa: 3, nom_etapa: 'Interesado',         des_etapa: 'El lead mostró interés en el producto o servicio',    num_orden: 3, ind_etapa_final: false, ind_estado: true  },
    { id_etapa: 4, nom_etapa: 'Propuesta enviada',  des_etapa: 'Se envió una propuesta comercial formal',             num_orden: 4, ind_etapa_final: false, ind_estado: true  },
    { id_etapa: 5, nom_etapa: 'Negociación',        des_etapa: 'En proceso de negociación de condiciones',            num_orden: 5, ind_etapa_final: false, ind_estado: true  },
    { id_etapa: 6, nom_etapa: 'Ganado',             des_etapa: 'Lead convertido en cliente, primera factura emitida', num_orden: 6, ind_etapa_final: true,  ind_estado: true  },
    { id_etapa: 7, nom_etapa: 'Perdido',            des_etapa: 'Lead que no convirtió, negocio no cerrado',           num_orden: 7, ind_etapa_final: true,  ind_estado: true  },
  ],

  /* ============================================================
     tab_canales
  ============================================================ */
  canales: [
    { id_canal: 1, nom_canal: 'Email',     des_canal: 'Campañas enviadas por correo electrónico masivo',        ind_estado: true  },
    { id_canal: 2, nom_canal: 'Instagram', des_canal: 'Publicaciones y anuncios en Instagram',                  ind_estado: true  },
    { id_canal: 3, nom_canal: 'Facebook',  des_canal: 'Publicaciones y anuncios en Facebook',                   ind_estado: true  },
    { id_canal: 4, nom_canal: 'LinkedIn',  des_canal: 'Publicaciones y anuncios en LinkedIn',                   ind_estado: true  },
    { id_canal: 5, nom_canal: 'WhatsApp',  des_canal: 'Mensajes promocionales masivos por WhatsApp Business',   ind_estado: true  },
  ],

  /* ============================================================
     tab_criterios_segmentacion + tab_valores_segmentacion
  ============================================================ */
  criterios: [
    {
      id_criterio : 1,
      nom_criterio: 'Origen',
      des_criterio: 'Define de dónde proviene el lead o cliente',
      ind_estado  : true,
      valores: [
        { id_valor: 1,  nom_valor: 'Redes Sociales',    des_valor: 'Lead captado por redes sociales',      val_peso: 2, ind_estado: true  },
        { id_valor: 2,  nom_valor: 'Referido',          des_valor: 'Lead recomendado por otro cliente',    val_peso: 3, ind_estado: true  },
        { id_valor: 3,  nom_valor: 'Búsqueda Orgánica', des_valor: 'Lead captado por búsqueda en internet',val_peso: 1, ind_estado: true  },
        { id_valor: 4,  nom_valor: 'Email',             des_valor: 'Lead captado por campaña de email',    val_peso: 2, ind_estado: true  },
      ],
    },
    {
      id_criterio : 2,
      nom_criterio: 'Temperatura',
      des_criterio: 'Indica qué tan cerca está el lead de tomar una decisión de compra',
      ind_estado  : true,
      valores: [
        { id_valor: 5,  nom_valor: 'Frío',     des_valor: 'Sin interés claro aún',                        val_peso: 1, ind_estado: true  },
        { id_valor: 6,  nom_valor: 'Tibio',    des_valor: 'Mostró algún interés pero no decide',          val_peso: 2, ind_estado: true  },
        { id_valor: 7,  nom_valor: 'Caliente', des_valor: 'Listo para tomar una decisión de compra',      val_peso: 3, ind_estado: true  },
      ],
    },
    {
      id_criterio : 3,
      nom_criterio: 'Tamaño de empresa',
      des_criterio: 'Clasifica según el tamaño de la empresa del lead o cliente',
      ind_estado  : true,
      valores: [
        { id_valor: 8,  nom_valor: 'Pequeña', des_valor: 'Empresa con menos de 50 empleados',             val_peso: 1, ind_estado: true  },
        { id_valor: 9,  nom_valor: 'Mediana', des_valor: 'Empresa entre 50 y 200 empleados',              val_peso: 2, ind_estado: true  },
        { id_valor: 10, nom_valor: 'Grande',  des_valor: 'Empresa con más de 200 empleados',              val_peso: 3, ind_estado: true  },
      ],
    },
    {
      id_criterio : 4,
      nom_criterio: 'Personalizado',
      des_criterio: 'Criterio configurable según las necesidades del negocio',
      ind_estado  : true,
      valores: [],
    },
  ],

  /* ============================================================
     tab_motivos_perdida
  ============================================================ */
  motivosPerdida: [
    { id_motivo_perdida: 1, nom_motivo: 'Precio muy alto',       des_motivo: 'El lead consideró que el precio no se ajustaba a su presupuesto',         ind_estado: true  },
    { id_motivo_perdida: 2, nom_motivo: 'Eligió la competencia', des_motivo: 'El lead decidió contratar con un competidor',                              ind_estado: true  },
    { id_motivo_perdida: 3, nom_motivo: 'Sin presupuesto',       des_motivo: 'El lead no contaba con presupuesto disponible en ese momento',             ind_estado: true  },
    { id_motivo_perdida: 4, nom_motivo: 'No era el momento',     des_motivo: 'El lead mostró interés pero no estaba listo para decidir',                ind_estado: true  },
    { id_motivo_perdida: 5, nom_motivo: 'Sin respuesta',         des_motivo: 'El lead no respondió tras varios intentos de contacto',                   ind_estado: true  },
    { id_motivo_perdida: 6, nom_motivo: 'Producto no se ajusta', des_motivo: 'El producto o servicio no cubría la necesidad del lead',                  ind_estado: true  },
  ],

  /* ============================================================
     tab_kpis_campana
  ============================================================ */
  kpisCampana: [
    { id_kpi: 1, nom_kpi: 'Leads Generados',  des_kpi: 'Cantidad de leads nuevos captados en el período',                    ind_estado: true  },
    { id_kpi: 2, nom_kpi: 'Correos Abiertos', des_kpi: 'Cantidad de correos abiertos por los destinatarios',                 ind_estado: true  },
    { id_kpi: 3, nom_kpi: 'Clics en Correo',  des_kpi: 'Cantidad de clics en enlaces dentro del correo',                    ind_estado: true  },
    { id_kpi: 4, nom_kpi: 'Conversiones',     des_kpi: 'Leads que se convirtieron en clientes en el período',               ind_estado: true  },
    { id_kpi: 5, nom_kpi: 'Alcance',          des_kpi: 'Cantidad de personas que vieron la campaña en el período',          ind_estado: true  },
    { id_kpi: 6, nom_kpi: 'Costo por Lead',   des_kpi: 'Presupuesto ejecutado dividido entre leads generados en el período',ind_estado: true  },
    { id_kpi: 7, nom_kpi: 'ROI',              des_kpi: 'Retorno sobre inversión expresado en porcentaje',                   ind_estado: true  },
  ],

  /* ============================================================
     Usuarios — simulado, en prod viene de SECURE/PHP
  ============================================================ */
  usuarios: [
    { id: 'u001', nombre: 'Admin753',    email: 'admin@marcom.co',   rol: 'Administrador', avatar: 'AD', color: 'av-blue',   activo: true  },
    { id: 'u002', nombre: 'Ana Torres',  email: 'a.torres@marcom.co',rol: 'Vendedor',      avatar: 'AT', color: 'av-green',  activo: true  },
    { id: 'u003', nombre: 'Pedro Ruiz',  email: 'p.ruiz@marcom.co',  rol: 'Vendedor',      avatar: 'PR', color: 'av-purple', activo: true  },
    { id: 'u004', nombre: 'Luis Mora',   email: 'l.mora@marcom.co',  rol: 'Vendedor',      avatar: 'LM', color: 'av-orange', activo: true  },
    { id: 'u005', nombre: 'María López', email: 'm.lopez@marcom.co', rol: 'Analista',      avatar: 'ML', color: 'av-teal',   activo: false },
  ],
};


/* ================================================================
   getCfgData()
   Intenta fetch al endpoint, si falla usa FALLBACK.
================================================================ */
async function getCfgData() {
  try {
    const endpoint = (typeof API !== 'undefined' && API.configuracion)
      ? API.configuracion
      : '../data/configuracion.json';

    const res = await fetch(endpoint, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[MARCOM] getCfgData: usando datos simulados.', err.message);
    return FALLBACK_CFG_DATA;
  }
}

window.getCfgData        = getCfgData;
window.FALLBACK_CFG_DATA = FALLBACK_CFG_DATA;