/* ================================================================
   js/configuracion/init.js — Director de Orquesta Configuración
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Flujo:
   1. Verifica sesión
   2. Fecha en header
   3. Construye sidebar nav
   4. Carga datos de configuración
   5. Renderiza todos los tabs
   6. Activa el sistema de tabs
   7. Activa lógica de guardar parámetros
   8. Sidebar móvil + tema oscuro
================================================================ */
'use strict';

window.addEventListener('load', async () => {

  /* ── 1. Sesión ──────────────────────────────────────────── */
  const user = (typeof Auth !== 'undefined') ? Auth.initProtectedPage() : null;
  if (typeof Auth !== 'undefined' && !user) return;

  /* ── 2. Fecha ───────────────────────────────────────────── */
  const dateBadge = document.getElementById('date-badge');
  if (dateBadge && typeof Utils !== 'undefined') {
    dateBadge.textContent = Utils.formatDate(new Date());
  }

  /* ── 3. Sidebar nav ─────────────────────────────────────── */
  CfgRender.buildNav();

  /* ── 4. Cargar datos ────────────────────────────────────── */
  let cfgData;
  try {
    cfgData = await getCfgData();
  } catch (err) {
    console.error('[MARCOM] Error al cargar configuración:', err);
    cfgData = FALLBACK_CFG_DATA;
    if (typeof Utils !== 'undefined') Utils.showToast('Usando datos simulados', 'warning');
  }

  /* ── 5. Renderizar todos los tabs ───────────────────────── */
  CfgRender.all(cfgData);

  /* ── 6. Sistema de tabs ─────────────────────────────────── */
  initTabs();

  /* ── 7. Guardar parámetros ──────────────────────────────── */
  initGuardarParams(cfgData);

  /* ── 8. Sidebar móvil ───────────────────────────────────── */
  initMobileSidebar();

  /* ── 9. Tema oscuro ─────────────────────────────────────── */
  document.getElementById('btn-dark')?.addEventListener('click', () => {
    if (typeof toggleDark === 'function') toggleDark();
  });

  /* ── 10. Notificaciones ─────────────────────────────────── */
  document.getElementById('btn-notif')?.addEventListener('click', () => {
    if (typeof Utils !== 'undefined') Utils.showToast('No hay notificaciones nuevas', 'info');
  });

  /* ── 11. Toast bienvenida ───────────────────────────────── */
  setTimeout(() => {
    if (typeof Utils !== 'undefined') Utils.showToast('Configuración cargada', 'success', 2500);
  }, 600);

});


/* ================================================================
   SISTEMA DE TABS
   Alterna entre los 7 paneles y muestra/oculta el botón guardar.
================================================================ */
function initTabs() {
  const tabs   = document.querySelectorAll('.cfg-tab');
  const panels = document.querySelectorAll('.cfg-panel');
  const btnGuardar = document.getElementById('btn-guardar-params');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;

      /* Actualizar tabs */
      tabs.forEach(t => {
        t.classList.toggle('cfg-tab-active', t.dataset.tab === target);
        t.setAttribute('aria-selected', t.dataset.tab === target ? 'true' : 'false');
      });

      /* Actualizar paneles */
      panels.forEach(p => {
        const show = p.id === `tab-${target}`;
        p.classList.toggle('cfg-panel-active', show);
      });

      /* Mostrar botón guardar solo en tab parámetros */
      if (btnGuardar) {
        btnGuardar.style.display = target === 'parametros' ? 'inline-flex' : 'none';
      }
    });
  });
}


/* ================================================================
   GUARDAR PARÁMETROS
   Recoge los valores de los inputs, valida y simula el guardado.
================================================================ */
function initGuardarParams(cfgData) {
  const btnGuardar = document.getElementById('btn-guardar-params');
  if (!btnGuardar) return;

  btnGuardar.addEventListener('click', () => {
    const inputs = document.querySelectorAll('.pc-input');
    const nuevosValores = {};
    let valido = true;
    let errorMsg = '';

    inputs.forEach(input => {
      const campo = input.dataset.campo;
      const val   = Number(input.value);
      const min   = input.min !== '' ? Number(input.min) : null;
      const max   = input.max !== '' ? Number(input.max) : null;

      /* Validar rango */
      if (min !== null && val < min) {
        valido   = false;
        errorMsg = `"${campo}" debe ser mayor o igual a ${min}.`;
        input.style.borderColor = 'var(--danger)';
        return;
      }
      if (max !== null && val > max) {
        valido   = false;
        errorMsg = `"${campo}" no puede superar ${max}.`;
        input.style.borderColor = 'var(--danger)';
        return;
      }
      input.style.borderColor = '';
      nuevosValores[campo] = val;
    });

    /* Validar constraint: score tibio < score caliente */
    const tibio    = nuevosValores['val_score_min_tibio'];
    const caliente = nuevosValores['val_score_min_caliente'];
    if (tibio !== undefined && caliente !== undefined && caliente <= tibio) {
      valido   = false;
      errorMsg = 'El score mínimo caliente debe ser mayor al score mínimo tibio.';
      document.getElementById('param-val_score_min_caliente').style.borderColor = 'var(--danger)';
      document.getElementById('param-val_score_min_tibio').style.borderColor    = 'var(--danger)';
    }

    if (!valido) {
      if (typeof Utils !== 'undefined') Utils.showToast(errorMsg, 'danger');
      return;
    }

    /* Simular guardado (en prod: fetch POST a ../api/configuracion.php) */
    Object.assign(cfgData.parametros, nuevosValores);
    console.info('[MARCOM] Parámetros actualizados (simulado):', cfgData.parametros);

    if (typeof Utils !== 'undefined') {
      Utils.showToast('Parámetros guardados correctamente', 'success');
    }
  });
}


/* ================================================================
   SIDEBAR MÓVIL
================================================================ */
function initMobileSidebar() {
  const btn     = document.getElementById('mob-menu-btn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sb-overlay');

  const open  = () => { sidebar?.classList.add('sidebar-open');    overlay?.classList.add('overlay-show');    btn?.setAttribute('aria-expanded','true');  };
  const close = () => { sidebar?.classList.remove('sidebar-open'); overlay?.classList.remove('overlay-show'); btn?.setAttribute('aria-expanded','false'); };

  btn?.addEventListener('click', open);
  overlay?.addEventListener('click', close);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
}