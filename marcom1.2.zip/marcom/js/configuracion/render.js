/* ================================================================
   js/configuracion/render.js — Ensamblador Configuración MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 1.0

   Renderiza los 7 tabs con los datos recibidos de data.js.
   Expone CfgRender.all(data) como punto de entrada.
================================================================ */
'use strict';

const CfgRender = (() => {

  /* ── Helpers ── */
  function toggle(on) {
    return `
      <div class="state-toggle">
        <div class="toggle-track ${on ? 't-on' : 't-off'}">
          <div class="toggle-thumb"></div>
        </div>
        <span class="toggle-label">${on ? 'Activo' : 'Inactivo'}</span>
      </div>`;
  }

  function cfgId(n) {
    return `<span class="cfg-id">${n}</span>`;
  }

  function avColor(name) {
    if (typeof Utils !== 'undefined') return Utils.avatarColor(name);
    const c = ['av-blue','av-green','av-purple','av-orange','av-teal'];
    let h = 0; for (const ch of name) h += ch.charCodeAt(0);
    return c[h % c.length];
  }

  function ini(name) {
    if (typeof Utils !== 'undefined') return Utils.initials(name);
    const p = name.trim().split(/\s+/);
    return p.length >= 2 ? (p[0][0]+p[1][0]).toUpperCase() : name.slice(0,2).toUpperCase();
  }


  /* ============================================================
     TAB 1 — PARÁMETROS GENERALES
  ============================================================ */
  function renderParametros(data) {
    const grid = document.getElementById('params-grid');
    if (!grid) return;

    const vals = data.parametros;
    const meta = data.parametrosMeta;

    grid.innerHTML = '';

    meta.forEach(m => {
      const val = vals[m.campo] ?? 0;

      const card = document.createElement('div');
      card.className = 'param-card';

      const constraintHTML = m.constraint
        ? `<div class="pc-constraint">
             <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12">
               <circle cx="12" cy="12" r="10"/>
               <line x1="12" y1="8" x2="12" y2="12"/>
               <line x1="12" y1="16" x2="12.01" y2="16"/>
             </svg>
             ${m.constraint}
           </div>`
        : '';

      const rangeText = m.min !== null && m.max !== null
        ? `Rango válido: ${m.min} – ${m.max}`
        : m.min !== null
          ? `Mínimo: ${m.min}`
          : '';

      card.innerHTML = `
        <div class="pc-label">${m.label}</div>
        <div class="pc-desc">${m.desc}</div>
        <div class="pc-input-wrap">
          <input
            class="pc-input"
            type="${m.tipo}"
            id="param-${m.campo}"
            name="${m.campo}"
            value="${val}"
            min="${m.min ?? ''}"
            max="${m.max ?? ''}"
            data-campo="${m.campo}"
          />
          <span class="pc-unit">${m.unidad}</span>
        </div>
        ${rangeText ? `<div class="pc-range">${rangeText}</div>` : ''}
        ${constraintHTML}
      `;

      grid.appendChild(card);
    });
  }


  /* ============================================================
     TAB 2 — ETAPAS DEL FUNNEL
  ============================================================ */
  function renderFunnel(data) {
    const tbody = document.getElementById('funnel-tbody');
    if (!tbody) return;

    tbody.innerHTML = data.etapasFunnel.map(e => `
      <tr>
        <td>${cfgId(e.id_etapa)}</td>
        <td><span class="cfg-name">${e.nom_etapa}</span></td>
        <td><span class="cfg-desc">${e.des_etapa}</span></td>
        <td class="t-mono t-sm" style="text-align:center">${e.num_orden}</td>
        <td>
          <span class="badge ${e.ind_etapa_final ? 'badge-final' : 'badge-normal'}">
            ${e.ind_etapa_final ? 'Final' : 'Intermedia'}
          </span>
        </td>
        <td>${toggle(e.ind_estado)}</td>
      </tr>
    `).join('');
  }


  /* ============================================================
     TAB 3 — CANALES
  ============================================================ */
  function renderCanales(data) {
    const tbody = document.getElementById('canales-tbody');
    if (!tbody) return;

    tbody.innerHTML = data.canales.map(c => `
      <tr>
        <td>${cfgId(c.id_canal)}</td>
        <td><span class="cfg-name">${c.nom_canal}</span></td>
        <td><span class="cfg-desc">${c.des_canal}</span></td>
        <td>${toggle(c.ind_estado)}</td>
      </tr>
    `).join('');
  }


  /* ============================================================
     TAB 4 — SEGMENTACIÓN (criterios + valores)
  ============================================================ */
  function renderSegmentacion(data) {
    const container = document.getElementById('seg-criterios');
    if (!container) return;

    container.innerHTML = '';

    data.criterios.forEach(crit => {
      const block = document.createElement('div');
      block.className = 'seg-criterio-block';

      /* Cabecera del criterio */
      block.innerHTML = `
        <div class="seg-crit-header">
          <div>
            <div class="seg-crit-name">${crit.nom_criterio}</div>
            <div class="seg-crit-desc">${crit.des_criterio}</div>
          </div>
          <div style="display:flex;align-items:center;gap:12px;flex-shrink:0">
            ${cfgId(crit.id_criterio)}
            ${toggle(crit.ind_estado)}
          </div>
        </div>
      `;

      /* Tabla de valores */
      if (crit.valores.length > 0) {
        const table = document.createElement('table');
        table.className = 'seg-valores-table';
        table.innerHTML = `
          <thead>
            <tr>
              <th style="width:50px">#</th>
              <th>Valor</th>
              <th>Descripción</th>
              <th style="width:140px">Peso (scoring)</th>
              <th style="width:100px">Estado</th>
            </tr>
          </thead>
          <tbody>
            ${crit.valores.map(v => {
              const barPct = Math.round((v.val_peso / 10) * 100);
              return `
                <tr>
                  <td>${cfgId(v.id_valor)}</td>
                  <td><span class="cfg-name">${v.nom_valor}</span></td>
                  <td><span class="cfg-desc">${v.des_valor}</span></td>
                  <td>
                    <div class="peso-wrap">
                      <div class="peso-bar-track">
                        <div class="peso-bar-fill" style="width:0%" data-w="${barPct}"></div>
                      </div>
                      <span class="peso-val">${v.val_peso}/10</span>
                    </div>
                  </td>
                  <td>${toggle(v.ind_estado)}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        `;
        block.appendChild(table);
      } else {
        /* Sin valores aún */
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.style.padding = '20px';
        empty.innerHTML = `<span style="font-size:.80rem;color:var(--text-muted)">Sin valores definidos para este criterio.</span>`;
        block.appendChild(empty);
      }

      container.appendChild(block);
    });

    /* Animar barras de peso */
    requestAnimationFrame(() => setTimeout(() => {
      container.querySelectorAll('.peso-bar-fill').forEach(el => {
        el.style.width = el.dataset.w + '%';
      });
    }, 150));
  }


  /* ============================================================
     TAB 5 — MOTIVOS DE PÉRDIDA
  ============================================================ */
  function renderMotivos(data) {
    const tbody = document.getElementById('motivos-tbody');
    if (!tbody) return;

    tbody.innerHTML = data.motivosPerdida.map(m => `
      <tr>
        <td>${cfgId(m.id_motivo_perdida)}</td>
        <td><span class="cfg-name">${m.nom_motivo}</span></td>
        <td><span class="cfg-desc">${m.des_motivo}</span></td>
        <td>${toggle(m.ind_estado)}</td>
      </tr>
    `).join('');
  }


  /* ============================================================
     TAB 6 — KPIs DE CAMPAÑA
  ============================================================ */
  function renderKpis(data) {
    const tbody = document.getElementById('kpis-tbody');
    if (!tbody) return;

    tbody.innerHTML = data.kpisCampana.map(k => `
      <tr>
        <td>${cfgId(k.id_kpi)}</td>
        <td><span class="cfg-name">${k.nom_kpi}</span></td>
        <td><span class="cfg-desc">${k.des_kpi}</span></td>
        <td>${toggle(k.ind_estado)}</td>
      </tr>
    `).join('');
  }


  /* ============================================================
     TAB 7 — USUARIOS (solo lectura)
  ============================================================ */
  function renderUsuarios(data) {
    const tbody = document.getElementById('usuarios-tbody');
    if (!tbody) return;

    tbody.innerHTML = data.usuarios.map(u => {
      const av = u.color ?? avColor(u.nombre);
      return `
        <tr>
          <td>
            <div class="usr-avatar ${av}">${u.avatar ?? ini(u.nombre)}</div>
          </td>
          <td>
            <div class="usr-cell">
              <div>
                <div class="usr-name">${u.nombre}</div>
              </div>
            </div>
          </td>
          <td><span class="cfg-desc">${u.email}</span></td>
          <td>
            <span class="badge ${u.rol === 'Administrador' ? 'badge-accent' : u.rol === 'Analista' ? 'badge-info' : 'badge-neutral'}">
              ${u.rol}
            </span>
          </td>
          <td>${toggle(u.activo)}</td>
        </tr>
      `;
    }).join('');
  }


  /* ============================================================
     SIDEBAR NAV
  ============================================================ */
  function buildNav() {
    const nav = document.getElementById('sb-nav');
    if (!nav || typeof NAV_ITEMS === 'undefined') return;
    nav.innerHTML = '';
    let currentSection = null;
    NAV_ITEMS.forEach(item => {
      if (item.section !== currentSection) {
        currentSection = item.section;
        if (item.section) {
          const label = document.createElement('div');
          label.className   = 'sb-section-label';
          label.textContent = item.section;
          nav.appendChild(label);
        }
      }
      const page   = location.pathname.split('/').pop() || 'index.html';
      const active = page === item.url ? 'active' : '';
      const iconSvg = (typeof ICONS !== 'undefined' && ICONS[item.icon]) ? ICONS[item.icon] : '';
      const a = document.createElement('a');
      a.className = `sb-item ${active}`;
      a.href      = item.url;
      a.innerHTML = `
        <span class="sb-item-icon">${iconSvg}</span>
        <span class="sb-item-label">${item.label}</span>
      `;
      nav.appendChild(a);
    });
  }


  /* ============================================================
     PUNTO DE ENTRADA
  ============================================================ */
  function all(data) {
    renderParametros(data);
    renderFunnel(data);
    renderCanales(data);
    renderSegmentacion(data);
    renderMotivos(data);
    renderKpis(data);
    renderUsuarios(data);
  }

  return { all, buildNav, renderParametros };

})();

window.CfgRender = CfgRender;