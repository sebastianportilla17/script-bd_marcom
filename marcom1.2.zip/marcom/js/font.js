/* ================================================================
   font.js — Tema Claro / Oscuro MARCOM
   Módulo  : Marketing y Comercial · ERP ADSO 3171727
   Versión : 2.0 — Corregido

   DEBE SER EL PRIMER SCRIPT EN CARGAR en todas las páginas.
   Al ejecutarse antes del primer pintado del browser evita
   el FOUC (flash blanco → oscuro al cargar en modo dark).

   LÓGICA:
     isDark = true  → html.dark activo → fondo oscuro
                    → ícono del botón muestra SOL  (para volver al claro)
     isDark = false → html.dark inactivo → fondo claro
                    → ícono del botón muestra LUNA (para ir al oscuro)

   EXPONE:
     window.toggleDark() — llamado por events.js al clic en #btn-dark
   ================================================================ */

'use strict';

/* ── Estado inicial ──────────────────────────────────────────────
   Lee la preferencia guardada por el usuario.
   Si no existe ninguna, el modo claro es el predeterminado.
──────────────────────────────────────────────────────────────── */
let isDark = localStorage.getItem('marcom-theme') === 'dark';

/* ── SVGs de los íconos del botón ────────────────────────────────
   SOL  → visible cuando el tema es oscuro  (clic → volver al claro)
   LUNA → visible cuando el tema es claro   (clic → ir al oscuro)
──────────────────────────────────────────────────────────────── */
const SVG_SUN = `
  <circle cx="12" cy="12" r="5"/>
  <line x1="12" y1="1"  x2="12" y2="3"/>
  <line x1="12" y1="21" x2="12" y2="23"/>
  <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
  <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
  <line x1="1"  y1="12" x2="3"  y2="12"/>
  <line x1="21" y1="12" x2="23" y2="12"/>
  <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
  <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
`;

const SVG_MOON = `<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>`;

/* ── Aplica el tema al DOM ───────────────────────────────────────
   Agrega o quita la clase 'dark' en <html> y actualiza
   el ícono de TODOS los botones de tema en la página
   (por si hay más de uno, ej: sidebar + header).
──────────────────────────────────────────────────────────────── */
function applyTheme() {
  if (isDark) {
    document.documentElement.classList.add('dark');
    /* Modo oscuro activo → mostrar sol para que el usuario pueda volver al claro */
    document.querySelectorAll('[id*="dark-icon"]').forEach(el => {
      el.innerHTML = SVG_SUN;
    });
  } else {
    document.documentElement.classList.remove('dark');
    /* Modo claro activo → mostrar luna para que el usuario pueda activar el oscuro */
    document.querySelectorAll('[id*="dark-icon"]').forEach(el => {
      el.innerHTML = SVG_MOON;
    });
  }
}

/* ── Toggle público ──────────────────────────────────────────────
   Llamado por events.js al hacer clic en #btn-dark.
   Persiste la preferencia en localStorage para todas las páginas.
──────────────────────────────────────────────────────────────── */
function toggleDark() {
  isDark = !isDark;
  localStorage.setItem('marcom-theme', isDark ? 'dark' : 'light');
  applyTheme();
}

/* ── Ejecución inmediata ─────────────────────────────────────────
   Al cargar el script (antes del primer paint) aplica el tema.
   Esto evita el FOUC — el usuario nunca ve el flash del tema contrario.
──────────────────────────────────────────────────────────────── */
applyTheme();

/* ── Exponer globalmente ─────────────────────────────────────────
   toggleDark() es llamado por events.js de cualquier página.
   applyTheme() por si algún script necesita re-aplicar el tema.
──────────────────────────────────────────────────────────────── */
window.toggleDark = toggleDark;
window.applyTheme = applyTheme;