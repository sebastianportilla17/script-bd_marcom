CREATE OR REPLACE FUNTION fun_insert_valores_segmentacion(wid_valor marcom.tab_valores_segmentacion.id_valor%TYPE,
                                                          wid_criterio marcom.tab_valores_segmentacion.id_criterio%TYPE,
                                                          wnom_valor marcom.tab_valores_segmentacion.nom_valor%TYPE,
                                                          wdes_valor marcom.tab_valores_segmentacion.des_valor%TYPE,
                                                          wval_peso marcom.tab_valores_segmentacion.val_peso%TYPE,
                                                          wind_estado marcom.tab_valores_segmentacion.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--
--VALIDACION NULIDAD
--
        IF wid_valor IS NULL THEN
                RAISE EXCEPTION 'El campo valor no puede ser nulo';
        END IF;
        IF wid_criterio IS NULL THEN
                RAISE EXCEPTION 'El campo criterio no puede ser nulo';
        END IF;
        IF wnom_valor IS NULL THEN
                RAISE EXCEPTION 'El campo nombre de valor no puede ser nulo';
        END IF;
        IF wdes_valor IS NULL THEN
                RAISE EXCEPTION 'El campo descripción de valor no puede ser nulo';
        END IF;
        IF wval_peso IS NULL THEN
                RAISE EXCEPTION 'El campo peso de valor no puede ser nulo';
        END IF;
        IF wind_estado IS NULL THEN
                RAISE EXCEPTION 'El campo estado de valor no puede ser nulo';
        END IF;

--
--INSERT DE DATOS
--
        INSERT INTO marcom.tab_valores_segmentacion (id_valor, id_criterio, nom_valor, des_valor, val_peso, ind_estado)
        VALUES (wid_valor, wid_criterio, wnom_valor, wdes_valor, wval_peso, wind_estado)
        ON CONFLICT (id_valor) DO NOTHING;

        IF NOT FOUND THEN
            RAISE NOTICE 'No se insertó porque esta duplicado el id_valor %', wid_valor;
            RETURN FALSE;
        END IF;

            RAISE NOTICE 'Valor % insertado correctamente', wnom_valor;
            RETURN TRUE;

        EXCEPTION
        WHEN OTHERS THEN    
            RAISE EXCEPTION 'Error %',public.fun_mensaje_error(SQLSTATE);   

END;
$$ LANGUAGE plpgsql;