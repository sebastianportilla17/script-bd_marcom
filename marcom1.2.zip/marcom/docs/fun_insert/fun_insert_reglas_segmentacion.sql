CREATE OR REPLACE FUNTION fun_insert_reglas_segmentacion(wid_regla marcom.tab_reglas_segmentacion.id_regla %TYPE,
                                                         wid_valor marcom.tab_reglas_segmentacion.id_valor %TYPE,
                                                         wnom_condicion marcom.tab_reglas_segmentacion.nom_condicion %TYPE,
                                                         wval_condicion marcom.tab_reglas_segmentacion.val_condicion %TYPE,
                                                         wind_aplica marcom.tab_reglas_segmentacion.ind_aplica %TYPE,
                                                         wind_estado marcom.tab_reglas_segmentacion.ind_estado %TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--
--VALIDACION NULIDAD
---
    IF wid_regla IS NULL THEN
        RAISE EXCEPTION 'El campo id_regla no puede ser nulo';
    END IF;
    IF wid_valor IS NULL THEN
        RAISE EXCEPTION 'El campo id_valor no puede ser nulo';
    END IF;
    IF wnom_condicion IS NULL THEN
        RAISE EXCEPTION 'El campo nombre condicion no puede ser nulo';
    END IF;
    IF wval_condicion IS NULL THEN
        RAISE EXCEPTION 'El campo valor condicion no puede ser nulo';
    END IF;
    IF wind_aplica IS NULL THEN
        RAISE EXCEPTION 'El campo indicador aplica no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo indicador estado no puede ser nulo';
    END IF;

--
--INSERT DE DATOS
--
    INSERT INTO marcom.tab_reglas_segmentacion (id_regla, id_valor, nom_condicion, val_condicion, ind_aplica, ind_estado)
    VALUES (wid_regla, wid_valor, wnom_condicion, wval_condicion, wind_aplica, wind_estado)
    ON CONFLICT (id_regla) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_regla %', wid_regla;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Regla % insertada correctamente', wnom_condicion;
    RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar regla: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;