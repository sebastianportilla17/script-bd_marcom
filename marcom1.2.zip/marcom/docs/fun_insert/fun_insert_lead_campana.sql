CREATE OR REPLACE FUNCTION fun_insert_lead_campana(wid_lead marcom.tab_lead_campana.id_lead%TYPE,
                                            wid_campana marcom.tab_lead_campana.id_campana%TYPE,
                                            wfec_asignacion marcom.tab_lead_campana.fec_asignacion%TYPE,
                                            wid_etapa marcom.tab_lead_campana.id_etapa%TYPE,
                                            wind_origen marcom.tab_lead_campana.id_origen%TYPE
                                            wind_estado marcom.tab_lead_campana.id_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_lead IS NULL THEN
        RAISE EXCEPTION 'El campo id_lead no puede ser nulo';
    END IF;
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campana no puede ser nulo';
    END IF;
    IF wfec_asignacion IS NULL THEN
        RAISE EXCEPTION 'El campo fec_asignacion no puede ser nulo';
    END IF;
    IF wid_etapa IS NULL THEN
        RAISE EXCEPTION 'El campo id_etapa no puede ser nulo';
    END IF;
    IF wind_origen IS NULL THEN
        RAISE EXCEPTION 'El campo id_origen no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo id_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_lead_campana (id_lead, id_campana, fec_asignacion, id_etapa, id_origen, id_estado)
    VALUES (wid_lead, wid_campana, wfec_asignacion, wid_etapa, wind_origen, wind_estado);
    ON CONFLICT (id_lead) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque este duplicado el id_lead %', wid_lead;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Lead % insertado correctamente', wid_lead;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar lead: %', SQLERRM;
END;
$$  
LANGUAGE plpgsql;