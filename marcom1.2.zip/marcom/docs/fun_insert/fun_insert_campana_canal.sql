CREATE OR REPLACE FUNCTION fun_campana_canal (wid_campana       marcom.tab_campanas.id_campana%TYPE,
                                              wid_canal         marcom.tab_canales.id_canal%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campana no puede ser nulo';
    END IF;
    IF wid_canal IS NULL THEN
        RAISE EXCEPTION 'El campo id_canal no puede ser nulo';
    END IF;
--INSERT DE DATOS
    INSERT INTO marcom.tab_campana_canal (id_campana, id_canal) 
    VALUES (wid_campana, wid_canal);
    ON CONFLICT (id_campana, id_canal) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_campana % y id_canal %', wid_campana, wid_canal;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Campaña canal con id_campana % e id_canal % insertada correctamente', wid_campana, wid_canal;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar campaña canal: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;