SELECT fun_insert_etapas_funel(1,'Prospecto','Lead identificado pero aún sin contacto',1, FALSE, TRUE);
SELECT fun_insert_etapas_funel(2,'Contactado','Se realizó el primer contacto con el lead',2, FALSE, TRUE);
SELECT fun_insert_etapas_funel(3,'Interesado','El lead mostró interés en el producto o servicio',3, FALSE, TRUE);
SELECT fun_insert_etapas_funel(4,'Propuesta enviada','Se envió una propuesta comercial formal',4, FALSE, TRUE);
SELECT fun_insert_etapas_funel(5,'Negociación','En proceso de negociación de condiciones',5, FALSE, TRUE);
SELECT fun_insert_etapas_funel(6,'Ganado','Lead convertido en cliente, primera factura emitida',6, TRUE,  TRUE);
SELECT fun_insert_etapas_funel(7,'Perdido','Lead que no convirtió, negocio no cerrado',7, TRUE,  TRUE);
---------
CREATE OR REPLACE FUNCTION fun_insert_etapas_funnel(wid_etapa        marcom.tab_etapas_funnel.id_etapa%TYPE,
                                                    wnom_etapa       marcom.tab_etapas_funnel.nom_etapa%TYPE,
                                                    wdes_etapa       marcom.tab_etapas_funnel.des_etapa%TYPE,
                                                    wind_etapa_final marcom.tab_etapas_funnel.ind_etapa_final%TYPE,
                                                    wind_estado      marcom.tab_etapas_funnel.ind_estado%TYPE) RETURNS BOOLEAN AS  

$$ 
BEGIN
    INSERT INTO marcom.tab_etapas_funnel (id_etapa, nom_etapa, des_etapa, ind_etapa_final, ind_estado)
    VALUES (wid_etapa, wnom_etapa, wdes_etapa, wind_etapa_final, wind_estado);

    RAISE NOTICE 'Etapa % insertada correctamente', wnom_etapa;

    RETURN TRUE;

EXCEPTION
    WHEN unique_violation THEN
            RAISE EXCEPTION 'Ya existe una etapa con ID %', wid_etapa 
            USING ERRCODE = '23505';

    WHEN check_violation THEN
            RAISE EXCEPTION 'Dato fuera de rango: id_etapa debe ser 1-99, nom_etapa mínimo 3 caracteres'
            USING ERRCODE = '23514';

    WHEN not_null_violation THEN
            RAISE EXCEPTION 'Falta un campo obligatorio (ninguno puede ser nulo)'
            USING ERRCODE = '23502';

    WHEN others THEN
            RAISE EXCEPTION 'Error inesperado al insertar etapa: %', SQLERRM;
END;

$$ LANGUAGE plpgsql;