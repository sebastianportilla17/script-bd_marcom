CREATE OR REPLACE FUNCTION fun_insert_segmentacion_tercero (wid_tercero       marcom.tab_reglas_segmentacion.id_regla%TYPE,
                                                            wid_valor         marcom.tab_reglas_segmentacion.nom_regla%TYPE,
                                                            wind_tipo         marcom.tab_reglas_segmentacion.des_regla%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--
--VALIDACION NULIDAD
--
    IF wid_tercero IS NULL THEN
        RAISE EXCEPTION 'El campo id_tercero no puede ser nulo';
    END IF;
    IF wid_valor IS NULL THEN
        RAISE EXCEPTION 'El campo valor no puede ser nulo';
    END IF;
    IF wind_tipo IS NULL THEN
        RAISE EXCEPTION 'El campo tipo no puede ser nulo';
    END IF;
END;
$$  LANGUAGE plpgsql;

--
--INSERT DE DATOS   
--
INSERT INTO marcom.tab_segmentacion_tercero (id_tercero, nom_tercero, tipo_tercero) 
VALUES (1, '1', 'TRUE')