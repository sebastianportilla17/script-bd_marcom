CREATE OR REPLACE FUNCTION fun_insert_motivos_perida (wid_motivo_perdida marcom.tab_motivos_perdida.id_motivo_perdida%TYPE,
                                    wnom_motivo_perdida marcom.tab_motivos_perdida.nom_motivo_perdida%TYPE,
                                    wdes_motivo_perdida marcom.tab_motivos_perdida.des_motivo_perdida%TYPE,
                                    wind_estado marcom.tab_motivos_perdida.ind_estado%TYPE) RETURNS BOOLEAN AS

$$
BEGIN
--VALIDACION NULIDAD
    IF wid_motivo_perdida IS NULL THEN
        RAISE EXCEPTION 'El campo id_motivo_perdida no puede ser nulo';
    END IF;
    IF wnom_motivo_perdida IS NULL THEN
        RAISE EXCEPTION 'El campo nom_motivo_perdida no puede ser nulo';
    END IF;
    IF wdes_motivo_perdida IS NULL THEN
        RAISE EXCEPTION 'El campo des_motivo_perdida no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS}
    INSERT INTO marcom.tab_motivos_perdida (id_motivo_perdida, nom_motivo_perdida, des_motivo_perdida, ind_estado) 
    VALUES (wid_motivo_perdida, wnom_motivo_perdida, wdes_motivo_perdida, wind_estado);
    ON CONFLICT (id_motivo_perdida) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_motivo_perdida %', wid_motivo_perdida;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Motivo de perdida % insertada correctamente', wnom_motivo_perdida;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar motivo de perdida: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;