CREATE OR REPLACE FUNCTION fun_insert_kpis_campana(wid_kpi marcom.tab_kpis_campana.id_kpi%TYPE
                                                    wnom_kpi marcom.tab_kpis_campana.nom_kpi%TYPE,
                                                    wdes_kpi marcom.tab_kpis_campana.des_kpi%TYPE,
                                                    wind_estado marcom.tab_kpis_campana.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_kpi IS NULL THEN
        RAISE EXCEPTION 'El campo id_kpi no puede ser nulo';
    END IF;
    IF wnom_kpi IS NULL THEN
        RAISE EXCEPTION 'El campo nom_kpi no puede ser nulo';
    END IF;
    IF wdes_kpi IS NULL THEN
        RAISE EXCEPTION 'El campo des_kpi no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_kpis_campana (id_kpi, nom_kpi, des_kpi, ind_estado) 
    VALUES (wid_kpi, wnom_kpi, wdes_kpi, wind_estado);
    ON CONFLICT (id_kpi) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_kpi %', wid_kpi;
        RETURN FALSE;
    END IF; 

    RAISE NOTICE 'KPI de campaña % insertada correctamente', wnom_kpi;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar KPI de campaña: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;