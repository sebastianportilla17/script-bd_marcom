CREATE OR REPLACE FUNCTION fun_insert_evento(wid_evento marcom.tab_eventos.id_evento%TYPE,
                                            wid_campana marcom.tab_eventos.id_campana%TYPE,
                                            wid_responsable marcom.tab_eventos.id_responsable%TYPE,
                                            wnom_evento marcom.tab_eventos.nom_even%TYPE,
                                            wdes_evento marcom.tab_eventos.des_evento%TYPE,
                                            wlug_evento marcom.tab_eventos.lug_evento%TYPE,
                                            wval_cupo marcom.tab_eventos.val_cupo%TYPE,
                                            wfec_evento marcom.tab_eventos.fec_evento%TYPE,
                                            wind_estado marcom.tab_eventos.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
 --VALIDACION NULIDAD
    IF wid_evento IS NULL THEN
        RAISE EXCEPTION 'El campo id_evento no puede ser nulo';
    END IF;
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campana no puede ser nulo';
    END IF;
    IF wid_responsable IS NULL THEN
        RAISE EXCEPTION 'El campo id_responsable no puede ser nulo';
    END IF;
    IF wnom_evento IS NULL THEN
        RAISE EXCEPTION 'El campo nom_evento no puede ser nulo';
    END IF;
    IF wdes_evento IS NULL THEN
        RAISE EXCEPTION 'El campo des_evento no puede ser nulo';
    END IF;
    IF wlug_evento IS NULL THEN
        RAISE EXCEPTION 'El campo lug_evento no puede ser nulo';
    END IF;
    IF wval_cupo IS NULL THEN
        RAISE EXCEPTION 'El campo val_cupo no puede ser nulo';
    END IF;
    IF wfec_evento IS NULL THEN
        RAISE EXCEPTION 'El campo fec_evento no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_eventos (id_evento, id_campana, id_responsable, nom_even, des_evento, lug_evento, val_cupo, fec_evento, ind_estado) 
    VALUES (wid_evento, wid_campana, wid_responsable, wnom_evento, wdes_evento, wlug_evento, wval_cupo, wfec_evento, wind_estado);
    ON CONFLICT (id_evento) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_evento %', wid_evento;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Evento % insertado correctamente', wnom_evento;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar evento: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;