CREATE OR REPLACE FUNCTION fun_insert_campana (wid_campana       marcom.tab_campanas.id_campana%TYPE,
                                               wid_tipo_campana  marcom.tab_tipo_campana.id_tipo_campana%TYPE,
                                               wnom_campana      marcom.tab_tipo_campana.nom_tipo_campana%TYPE,
                                               wdes_objetivo     marcom.tab_tipo_campana.des_tipo_campana%TYPE,
                                               wfec_inicio       marcom.tab_campanas.fec_inicio%TYPE,
                                               wfec_fin          marcom.tab_campanas.fec_fin%TYPE,
                                               wind_estado       marcom.tab_tipo_campana.ind_estado%TYPE) RETURNS BOOLEAN AS

$$
BEGIN
--VALIDACION NULIDAD
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campana no puede ser nulo';
    END IF;
    IF wid_tipo_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_tipo_campana no puede ser nulo';
    END IF;
    IF wnom_campana IS NULL THEN
        RAISE EXCEPTION 'El campo nom_campana no puede ser nulo';
    END IF;
    IF wdes_objetivo IS NULL THEN
        RAISE EXCEPTION 'El campo des_objetivo no puede ser nulo';
    END IF;
    IF wfec_inicio IS NULL THEN
        RAISE EXCEPTION 'El campo fec_inicio no puede ser nulo';
    END IF;
    IF wfec_fin IS NULL THEN
        RAISE EXCEPTION 'El campo fec_fin no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_campanas (id_campana, id_tipo_campana, nom_campana, des_objetivo, fec_inicio, fec_fin, ind_estado) 
    VALUES (wid_campana, wid_tipo_campana, wnom_campana, wdes_objetivo, wfec_inicio, wfec_fin, wind_estado);
    ON CONFLICT (id_campana) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_campana %', wid_campana;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Campaña % insertada correctamente', wnom_campana;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar campaña: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;