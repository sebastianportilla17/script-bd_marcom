CREATE OR REPLACE FUNCTION fun_insert_prod_camp(wid_producto marcom.tab_productos.id_producto%TYPE,
                                                wid_campana marcom.tab_campañas.id_campaña%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_producto IS NULL THEN
        RAISE EXCEPTION 'El campo id_producto no puede ser nulo';
    END IF;
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campaña no puede ser nulo';
    END IF;
--INSERT DE DATOS
    INSERT INTO marcom.tab_prod_camp (id_producto, id_campaña)  
    VALUES (wid_producto, wid_campana);
    ON CONFLICT (id_producto, id_campaña) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_producto % y id_campaña %', wid_producto, wid_campana;
        RETURN FALSE;
    END IF; 

    RAISE NOTICE 'Producto-Campaña para producto % y campaña % insertada correctamente', wid_producto, wid_campana;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar producto-campaña: %', SQLERRM; 
END;
$$
LANGUAGE plpgsql;