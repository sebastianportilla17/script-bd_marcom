CREATE OR REPLACE FUNCTION fun_insert_leads(wid_lead marcom.tab_leads.id_lead%TYPE
                                            wfec_registro marcom.tab_leads.fec_registro%TYPE
                                            wval_score marcom.tab_leads.val_score%TYPE
                                            wid_etapa marcom.tab_leads.id_etapa%TYPE
                                            wid_motivo_perdida marcom.tab_leads.id_motivo_perdida%TYPE
                                            wind_estado marcom.tab_leads.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_lead IS NULL THEN
        RAISE EXCEPTION 'El campo id_lead no puede ser nulo';
    END IF;
    IF wfec_registro IS NULL THEN
        RAISE EXCEPTION 'El campo fec_registro no puede ser nulo';
    END IF;
    IF wval_score IS NULL THEN
        RAISE EXCEPTION 'El campo val_score no puede ser nulo';
    END IF;
    IF wid_etapa IS NULL THEN
        RAISE EXCEPTION 'El campo id_etapa no puede ser nulo';
    END IF;
    IF wid_motivo_perdida IS NULL THEN
        RAISE EXCEPTION 'El campo id_motivo_perdida no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_leads (id_lead, fec_registro, val_score, id_etapa, id_motivo_perdida, ind_estado)
    VALUES (wid_lead, wfec_registro, wval_score, wid_etapa, wid_motivo_perdida, wind_estado);
    ON CONFLICT (id_lead) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque este duplicado el id_lead %', wid_lead;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Lead % insertado correctamente', wid_lead;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar lead: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;