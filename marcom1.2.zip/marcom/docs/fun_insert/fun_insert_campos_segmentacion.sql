CREATE OR REPLACE FUNCTION fun_insert_campos_segmentacion(wid_campo marcom.tab_campos_segmentacion.id_campo%TYPE,
                                                           wnom_campo marcom.tab_campos_segmentacion.nom_campo%TYPE,
                                                           wdes_campo marcom.tab_campos_segmentacion.des_campo%TYPE,
                                                           wtipo_dato marcom.tab_campos_segmentacion.tipo_dato%TYPE,
                                                           wind_estado marcom.tab_campos_segmentacion.ind_estado%TYPE)RETURNS BOOLEAN AS 
$$
BEGIN
END;
$$
LANGUAGE plpgsql