CREATE OR REPLACE FUNCTION fun_insert_tipo_campana (wid_tipo_campana       marcom.tab_tipo_campana.id_tipo_campana%TYPE,
                                                    wnom_tipo_campana      marcom.tab_tipo_campana.nom_tipo_campana%TYPE,
                                                    wdes_tipo_campana      marcom.tab_tipo_campana.des_tipo_campana%TYPE,
                                                    wind_estado            marcom.tab_tipo_campana.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_tipo_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_tipo_campana no puede ser nulo';
    END IF;
    IF wnom_tipo_campana IS NULL THEN
        RAISE EXCEPTION 'El campo nom_tipo_campana no puede ser nulo';
    END IF;
    IF wdes_tipo_campana IS NULL THEN
        RAISE EXCEPTION 'El campo des_tipo_campana no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;
END;

--INSERT DE DATOS
    INSERT INTO marcom.tab_tipo_campana (id_tipo_campana, nom_tipo_campana, des_tipo_campana, ind_estado) 
    VALUES (wid_tipo_campana, wnom_tipo_campana, wdes_tipo_campana, wind_estado);
    ON CONFLICT (id_tipo_campana) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el wid_tipo_campana %', wid_tipo_campana;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Tipo de campaña % insertada correctamente', wnom_tipo_campana;
    RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar tipo de campaña  : %', SQLERRM;
END;
$$
LANGUAGE plpgsql;