CREATE OR REPLACE FUNCTION fun_insert_interacciones_lead(wid_interaccion marcom.tab_interacciones_lead.id_interaccion%TYPE,
                                            wid_lead marcom.tab_interacciones_lead.id_lead%TYPE,
                                            wid_vendedor marcom.tab_interacciones_lead.id_vendedor%TYPE,
                                            wid_canal marcom.tab_interacciones_lead.id_canal%TYPE,
                                            wfec_interaccion marcom.tab_interacciones_lead.fec_interaccion%TYPE,
                                            wind_tipo marcom.tab_interacciones_lead.id_tipo%TYPE,
                                            wdes_resultado marcom.tab_interacciones_lead.des_resultado%TYPE,
                                            wfec_proxima_accion marcom.tab_interacciones_lead.fec_proxima_accion%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
--VALIDACION NULIDAD
    IF wid_interaccion IS NULL THEN
        RAISE EXCEPTION 'El campo id_interaccion no puede ser nulo';
    END IF;
    IF wid_lead IS NULL THEN
        RAISE EXCEPTION 'El campo id_lead no puede ser nulo';
    END IF;
    IF wid_vendedor IS NULL THEN
        RAISE EXCEPTION 'El campo id_vendedor no puede ser nulo';
    END IF;
    IF wid_canal IS NULL THEN
        RAISE EXCEPTION 'El campo id_canal no puede ser nulo';
    END IF;
    IF wfec_interaccion IS NULL THEN
        RAISE EXCEPTION 'El campo fec_interaccion no puede ser nulo';
    END IF;
    IF wind_tipo IS NULL THEN
        RAISE EXCEPTION 'El campo id_tipo no puede ser nulo';
    END IF;
    IF wdes_resultado IS NULL THEN
        RAISE EXCEPTION 'El campo des_resultado no puede ser nulo';
    END IF;
    IF wfec_proxima_accion IS NULL THEN
        RAISE EXCEPTION 'El campo fec_proxima_accion no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_interacciones_lead (id_interaccion, id_lead, id_vendedor, id_canal, fec_interaccion, id_tipo, des_resultado, fec_proxima_accion)
    VALUES (wid_interaccion, wid_lead, wid_vendedor, wid_canal, wfec_interaccion, wind_tipo, wdes_resultado, wfec_proxima_accion);
    ON CONFLICT (id_interaccion) DO NOTHING;    

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque este duplicado el id_interaccion %', wid_interaccion;
        RETURN FALSE;
    END IF;

    RAISE NOTICE 'Interacción % insertada correctamente', wid_interaccion;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar interacción: %', SQLERRM;
END;
$$ 
LANGUAGE plpgsql;