INSERT INTO marcom.tab_canales VALUES(1, 'Email',     'Campañas enviadas por correo electrónico masivo',          TRUE);
INSERT INTO marcom.tab_canales VALUES(2, 'Instagram', 'Publicaciones y anuncios en Instagram',                    TRUE);
INSERT INTO marcom.tab_canales VALUES(3, 'Facebook',  'Publicaciones y anuncios en Facebook',                     TRUE);
INSERT INTO marcom.tab_canales VALUES(4, 'LinkedIn',  'Publicaciones y anuncios en LinkedIn',                     TRUE);
INSERT INTO marcom.tab_canales VALUES(5, 'WhatsApp',  'Mensajes promocionales masivos por WhatsApp Business',     TRUE);

CREATE OR REPLACE FUNCTION fun_insert_canales(wid_canal       marcom.tab_canales.id_canal%TYPE,
                                              wnom_canal      marcom.tab_canales.nom_canal%TYPE,) RETURNS BOOLEAN AS  

$$ 
BEGIN
    INSERT INTO marcom.tab_canales (id_canal, nom_canal)
    VALUES (wid_canal, wnom_canal);

    RAISE NOTICE 'Canal % insertado correctamente', wnom_canal;

    RETURN TRUE;

EXCEPTION
    WHEN unique_violation THEN
            RAISE EXCEPTION 'Ya existe un canal con ID %', wid_canal 
            USING ERRCODE = '23505';

    WHEN check_violation THEN
            RAISE EXCEPTION 'Dato fuera de rango: id_canal debe ser 1-99, nom_canal mínimo 3 caracteres'
            USING ERRCODE = '23514';

    WHEN not_null_violation THEN
            RAISE EXCEPTION 'Falta un campo obligatorio (ninguno puede ser nulo)'
            USING ERRCODE = '23502';

    WHEN others THEN
            RAISE EXCEPTION 'Error inesperado al insertar canal: %', SQLERRM;
END;

$$ LANGUAGE plpgsql;