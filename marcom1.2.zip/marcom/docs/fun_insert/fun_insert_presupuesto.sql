CREATE OR REPLACE FUNCTION fun_insert_presupuesto(wid_presupuesto marcom.tab_presupuestos.id_presupuesto%TYPE,
                                                   wid_campana marcom.tab_campañas.id_campaña%TYPE,
                                                   wid_evento marcom.tab_eventos.id_evento%TYPE,
                                                   wval_aprobado marcom.tab_presupuestos.val_aprobado%TYPE,
                                                   wval_ejecutado marcom.tab_presupuestos.val_ejecutado%TYPE,
                                                   wdes_presupuesto marcom.tab_presupuestos.des_presupuesto%TYPE,
                                                   wfec_presupuesto marcom.tab_presupuestos.fec_presupuesto%TYPE,
                                                   wind_estado marcom.tab_presupuestos.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
 --VALIDACION NULIDAD
    IF wid_presupuesto IS NULL THEN
        RAISE EXCEPTION 'El campo id_presupuesto no puede ser nulo';
    END IF;
    IF wid_campana IS NULL THEN
        RAISE EXCEPTION 'El campo id_campaña no puede ser nulo';
    END IF;
    IF wid_evento IS NULL THEN
        RAISE EXCEPTION 'El campo id_evento no puede ser nulo';
    END IF;
    IF wval_aprobado IS NULL THEN
        RAISE EXCEPTION 'El campo val_aprobado no puede ser nulo';
    END IF;
    IF wval_ejecutado IS NULL THEN
        RAISE EXCEPTION 'El campo val_ejecutado no puede ser nulo';
    END IF;
    IF wdes_presupuesto IS NULL THEN
        RAISE EXCEPTION 'El campo des_presupuesto no puede ser nulo';
    END IF;
    IF wfec_presupuesto IS NULL THEN
        RAISE EXCEPTION 'El campo fec_presupuesto no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_presupuestos (id_presupuesto, id_campana,    id_evento, val_aprobado, val_ejecutado, des_presupuesto, fec_presupuesto, ind_estado) 
    VALUES (wid_presupuesto, wid_campana, wid_evento, wval_aprobado, wval_ejecutado, wdes_presupuesto, wfec_presupuesto, wind_estado);
    ON CONFLICT (id_presupuesto) DO NOTHING;    

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_presupuesto %', wid_presupuesto;
        RETURN FALSE;
    END IF; 

    RAISE NOTICE 'Presupuesto para campaña % y evento % insertado correctamente', wid_campana, wid_evento;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar presupuesto: %', SQLERRM;
END;
$$
LANGUAGE plpgsql;