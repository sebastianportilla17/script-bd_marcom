INSERT INTO marcom.tab_criterios_segmentacion VALUES(1, 'Origen',             'Define de dónde proviene el lead o cliente',                       TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(2, 'Temperatura',        'Indica qué tan cerca está el lead de tomar una decisión de compra', TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(3, 'Tamaño de empresa',  'Clasifica según el tamaño de la empresa del lead o cliente',        TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(4, 'Personalizado',      'Criterio configurable según las necesidades del negocio',           TRUE);
CREATE OR REPLACE FUNCTION fun_insert_criterios_segmentacion (wid_criterio       marcom.tab_criterios_segmentacion.id_criterio%TYPE,
                                                              wnom_criterio      marcom.tab_criterios_segmentacion.nom_criterio%TYPE,
                                                              wdes_criterio      marcom.tab_criterios_segmentacion.des_criterio%TYPE,
                                                              wind_estado        marcom.tab_criterios_segmentacion.ind_estado%TYPE) RETURNS BOOLEAN AS  

$$ 
BEGIN

---
--Validacion Nulidad 
---
        IF wid_criterio IS NULL THEN
                RAISE EXCEPTION 'El campo criterio no puede ser nulo';
        END IF;
        IF wnom_criterio IS NULL THEN 
                RAISE EXCEPTION 'El campo nombre de criterio no puede ser nulo';
        END IF;
        IF wdes_criterio IS NULL THEN
                RAISE EXCEPTION 'El campo descripción de criterio no puede ser nulo';
        END IF;
        IF wind_estado IS NULL THEN
                RAISE EXCEPTION 'El campo estado de criterio no puede ser nulo';
        END IF;
        --
        --inserción de datos
        --
        INSERT INTO marcom.tab_criterios_segmentacion (id_criterio, nom_criterio, des_criterio, ind_estado)
        VALUES (wid_criterio, wnom_criterio, wdes_criterio, wind_estado)
        ON CONFLICT (id_criterio) DO NOTHING;

        IF NOT FOUND THEN
                RAISE NOTICE 'No se insertó porque esta duplicado el id_criterio %', wid_criterio;
        RETURN FALSE;
         END IF;

                RAISE NOTICE 'Criterio % insertado correctamente', wnom_criterio;
        RETURN TRUE;

        EXCEPTION
                WHEN OTHERS THEN
        RAISE EXCEPTION 'Error %',public.fun_mensaje_error(SQLSTATE);
END;

$$ LANGUAGE plpgsql;