CREATE OR REPLACE FUNCTION fun_insert_even_lead(wid_evento marcom.tab_eventos.id_evento%TYPE,
                                            wid_lead marcom.tab_leads.id_lead%TYPE,
                                            wfec_invitacion marcom.tab_invitaciones.fec_invitacion%TYPE,
                                            wfec_confirmacion marcom.tab_invitaciones.fec_confirmacion%TYPE,
                                            wfec_asistencia marcom.tab_invitaciones.fec_asistencia%TYPE,
                                            wind_estado marcom.tab_invitaciones.ind_estado%TYPE) RETURNS BOOLEAN AS
$$
BEGIN
 --VALIDACION NULIDAD
    IF wid_evento IS NULL THEN
        RAISE EXCEPTION 'El campo id_evento no puede ser nulo';
    END IF;
    IF wid_lead IS NULL THEN
        RAISE EXCEPTION 'El campo id_lead no puede ser nulo';
    END IF;
    IF wfec_invitacion IS NULL THEN
        RAISE EXCEPTION 'El campo fec_invitacion no puede ser nulo';
    END IF;
    IF wfec_confirmacion IS NULL THEN
        RAISE EXCEPTION 'El campo fec_confirmacion no puede ser nulo';
    END IF;
    IF wfec_asistencia IS NULL THEN
        RAISE EXCEPTION 'El campo fec_asistencia no puede ser nulo';
    END IF;
    IF wind_estado IS NULL THEN
        RAISE EXCEPTION 'El campo ind_estado no puede ser nulo';
    END IF;

--INSERT DE DATOS
    INSERT INTO marcom.tab_invitaciones (id_evento, id_lead, fec_invitacion, fec_confirmacion, fec_asistencia, ind_estado) 
    VALUES (wid_evento, wid_lead, wfec_invitacion, wfec_confirmacion, wfec_asistencia, wind_estado);
    ON CONFLICT (id_evento, id_lead) DO NOTHING;

    IF NOT FOUND THEN
        RAISE NOTICE 'No se insertó porque esta duplicado el id_evento % y id_lead %', wid_evento, wid_lead;
        RETURN FALSE;
    END IF; 

    RAISE NOTICE 'Invitación para evento % y lead % insertada correctamente', wid_evento, wid_lead;
    RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE EXCEPTION 'Error al insertar invitación: %', SQLERRM; 
END;
$$
LANGUAGE plpgsql;