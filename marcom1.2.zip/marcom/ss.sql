schema public;
CREATE TABLE IF NOT EXISTS tab_cat_terceros
(			
	id_cat_tercero 		DECIMAL(2,0)	NOT NULL,					--identificador de la categoria 
	nom_cat_tercero		VARCHAR			NOT NULL,					--Nombre de la categoria tercero
	PRIMARY KEY(id_cat_tercero)			
);			
INSERT INTO tab_cat_terceros VALUES(1,'CLIENTE');			
INSERT INTO tab_cat_terceros VALUES(2,'VENDEDOR');			
INSERT INTO tab_cat_terceros VALUES(3,'EMPLEADO');			
INSERT INTO tab_cat_terceros VALUES(4,'LEAD');			
INSERT INTO tab_cat_terceros VALUES(5,'PROVEEDOR');	

CREATE TABLE IF NOT EXISTS tab_terceros			
(			
	id_tercero			DECIMAL(10,0)	NOT NULL CHECK(id_tercero >=10000000 AND id_tercero<=9999999999),		--identificador de terceros		
	ind_tipo_tercero	BOOLEAN			NOT NULL, --TRUE:Jurídica / FALSE:Natural								--tipo de tercero si es persona natural o jurídica
	id_cat_tercero		DECIMAL(2,0)	NOT NULL,																--identifiador de la categoria 
	nom_tercero			VARCHAR			NOT NULL,																--nombre del tercero
	dir_tercero			DATOS_UBICACION,																		--Estructura de   datos de ubicación de terceros
	id_ciudad			VARCHAR			NOT NULL,																--identificador de ciudad
	id_restriccion		DECIMAL(2,0)	NOT NULL, -- Validado contra tabla de restricciones						--identificador de las restrincion
	ind_estado			BOOLEAN			NOT NULL, --TRUE:Activo ( FALSE:Inactivo)								--indicador de estado del tercero
    ind_borrado         BOOLEAN         NOT NULL DEFAULT FALSE, --TRUE: Borrado lógico (Inactivo) / FALSE: Activo	--indicador de borrado lógico
	PRIMARY KEY(id_tercero),			
	FOREIGN KEY(id_ciudad)			REFERENCES tab_ciudades(id_ciudad),			
	FOREIGN KEY(id_cat_tercero)		REFERENCES tab_cat_terceros(id_cat_tercero),			
	FOREIGN KEY(id_restriccion)		REFERENCES tab_restricciones(id_restriccion)
);

schema marcom;
-- ------------------------------------------------
-- TABLA DE CRITERIOS DE SEGMENTACIÓN
-- Define los aspectos estratégicos por los que se 
-- clasifican leads y clientes. Solo modificable 
-- por el rol administrador via módulo SECURE.
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS marcom.tab_criterios_segmentacion
(
    id_criterio         DECIMAL(2,0)    NOT NULL CHECK(id_criterio > 0 AND id_criterio <= 99),
    nom_criterio        VARCHAR(30)     NOT NULL CHECK(LENGTH(nom_criterio) >= 3),
    des_criterio        TEXT            NOT NULL,
    ind_estado          BOOLEAN         NOT NULL, -- TRUE = activo / FALSE = inactivo
    PRIMARY KEY(id_criterio)
);

INSERT INTO marcom.tab_criterios_segmentacion VALUES(1, 'Origen',             'Define de dónde proviene el lead o cliente',                       TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(2, 'Temperatura',        'Indica qué tan cerca está el lead de tomar una decisión de compra', TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(3, 'Tamaño de empresa',  'Clasifica según el tamaño de la empresa del lead o cliente',        TRUE);
INSERT INTO marcom.tab_criterios_segmentacion VALUES(4, 'Personalizado',      'Criterio configurable según las necesidades del negocio',           TRUE);

-- ------------------------------------------------
-- TABLA DE VALORES DE SEGMENTACIÓN
-- Define las opciones específicas de cada criterio
-- e incluye un peso para calcular Lead Scoring.
-- Solo modificable por el rol administrador.
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS marcom.tab_valores_segmentacion
(
    id_valor            DECIMAL(3,0)    NOT NULL CHECK(id_valor > 0 AND id_valor <= 999),
    id_criterio         DECIMAL(2,0)    NOT NULL,
    nom_valor           VARCHAR(30)     NOT NULL CHECK UNIQUE (LENGTH(nom_valor) >= 3),
    des_valor           TEXT            NOT NULL,
    val_peso            DECIMAL(2,0)    NOT NULL CHECK(val_peso >= 1 AND val_peso <= 10),
    ind_estado          BOOLEAN         NOT NULL, -- TRUE = activo / FALSE = inactivo
    PRIMARY KEY(id_valor),
    FOREIGN KEY(id_criterio) REFERENCES marcom.tab_criterios_segmentacion(id_criterio)
);

-- Valores para Origen (id_criterio = 1)
INSERT INTO marcom.tab_valores_segmentacion VALUES(1,  1, 'Redes Sociales',    'Lead captado por redes sociales',              2, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(2,  1, 'Referido',          'Lead recomendado por otro cliente',            3, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(3,  1, 'Búsqueda Orgánica', 'Lead captado por búsqueda en internet',        1, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(4,  1, 'Email',             'Lead captado por campaña de email',            2, TRUE);

-- Valores para Temperatura (id_criterio = 2)
INSERT INTO marcom.tab_valores_segmentacion VALUES(5,  2, 'Frío',              'Sin interés claro aún',                        1, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(6,  2, 'Tibio',             'Mostró algún interés pero no decide',          2, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(7,  2, 'Caliente',          'Listo para tomar una decisión de compra',      3, TRUE);

-- Valores para Tamaño de empresa (id_criterio = 3)
INSERT INTO marcom.tab_valores_segmentacion VALUES(8,  3, 'Pequeña',           'Empresa con menos de 50 empleados',            1, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(9,  3, 'Mediana',           'Empresa entre 50 y 200 empleados',             2, TRUE);
INSERT INTO marcom.tab_valores_segmentacion VALUES(10, 3, 'Grande',            'Empresa con más de 200 empleados',             3, TRUE);

-- ------------------------------------------------
-- TABLA DE REGLAS DE SEGMENTACIÓN AUTOMÁTICA
-- Define las condiciones que disparan la asignación
-- automática de valores de segmentación a leads y 
-- clientes. Solo modificable por el administrador.
-- Versión 1.0 - condición simple por regla.
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS marcom.tab_reglas_segmentacion
(
    id_regla                DECIMAL(3,0)    NOT NULL CHECK(id_regla > 0 AND id_regla <= 999),
    id_valor                DECIMAL(3,0)    NOT NULL,
    tipo_logica             VARCHAR(10)     NOT NULL DEFAULT 'AND' CHECK (tipo_logica IN ('AND', 'OR')),
    -- Define cómo se combinan las condiciones:
    -- AND → todas deben cumplirse
    -- OR  → basta con una

    --nom_condicion           VARCHAR(30)     NOT NULL, -- se queda VARCHAR porque es el nombre del campo
    --val_condicion           DECIMAL(5,0)    NOT NULL CHECK(val_condicion > 0), -- cambia a número
    --ind_aplica              BOOLEAN         NOT NULL, -- TRUE = aplica a clientes / FALSE = aplica a leads
    ind_estado              BOOLEAN         NOT NULL, -- TRUE = activa / FALSE = inactiva
    PRIMARY KEY(id_regla),
    FOREIGN KEY(id_valor) REFERENCES marcom.tab_valores_segmentacion(id_valor)
);

-- Si el lead vino por LinkedIn, asignar Redes Sociales
INSERT INTO marcom.tab_reglas_segmentacion VALUES(1, 1, 'AND' , TRUE);
-- Si el lead vino por Instagram, asignar Redes Sociales
INSERT INTO marcom.tab_reglas_segmentacion VALUES(2, 3, 'AND', TRUE);
-- Si el lead vino por Facebook, asignar Redes Sociales
INSERT INTO marcom.tab_reglas_segmentacion VALUES(3, 4, 'AND', TRUE);
-- Si el lead vino por Email, asignar origen Email
INSERT INTO marcom.tab_reglas_segmentacion VALUES(4, 6, 'AND', TRUE);
-- Si entra en etapa Negociación, asignar temperatura Caliente
INSERT INTO marcom.tab_reglas_segmentacion VALUES(5, 9, 'AND', TRUE);
-- Si entra en etapa Contactado, asignar temperatura Tibio
INSERT INTO marcom.tab_reglas_segmentacion VALUES(6, 5, 'AND', TRUE);

-- ============================================================
-- TABLA DE SEGMENTACIÓN DE TERCEROS
-- Conecta leads y clientes con sus valores de segmentación.
-- Una sola tabla para ambos usando ind_tipo como diferenciador.
-- PHP inserta aquí después de evaluar tab_reglas_segmentacion
-- y luego actualiza val_score en tab_leads.
-- ============================================================
CREATE TABLE IF NOT EXISTS marcom.tab_segmentacion_tercero
(
    id_tercero          DECIMAL(10,0)   NOT NULL CHECK(id_tercero >= 10000000 AND id_tercero <= 9999999999),
    id_valor            DECIMAL(3,0)    NOT NULL CHECK(id_valor > 0 AND id_valor <= 999),
    ind_tipo            BOOLEAN         NOT NULL, -- TRUE = CLIENTE / FALSE = LEAD
    fec_asignacion      DATE            NOT NULL DEFAULT CURRENT_DATE,
    PRIMARY KEY(id_tercero, id_valor),
    FOREIGN KEY(id_tercero) REFERENCES public.tab_terceros(id_tercero),
    FOREIGN KEY(id_valor)   REFERENCES marcom.tab_valores_segmentacion(id_valor)
);

-- ============================================================
-- TABLA: CAMPOS DE SEGMENTACIÓN
-- Define los campos del sistema que pueden ser evaluados
-- en las reglas (ej: canal, etapa, número de compras).
-- Permite integridad referencial y evita usar strings sueltos.
-- ============================================================

CREATE TABLE IF NOT EXISTS marcom.tab_campos_segmentacion
(
    id_campo        SMALLINT  NOT NULL PRIMARY KEY, 
    -- Identificador único del campo

    nom_campo       VARCHAR(50) NOT NULL UNIQUE, 
    -- Nombre técnico del campo (ej: id_canal, id_etapa, num_compras)

    des_campo       VARCHAR     NOT NULL, 
    -- Descripción funcional del campo

    tipo_dato       VARCHAR     NOT NULL CHECK (tipo_dato IN ('NUMERICO', 'TEXTO', 'FECHA')),
    -- Tipo de dato del campo:
    -- NUMERICO → comparaciones matemáticas
    -- TEXTO   → comparaciones string
    -- FECHA   → comparaciones temporales

    ind_estado      BOOLEAN     NOT NULL DEFAULT TRUE
    -- TRUE = activo / FALSE = inactivo
);

-- ============================================================
-- TABLA: CONDICIONES DE REGLA
-- Define las condiciones que deben cumplirse para aplicar
-- una regla de segmentación.
-- Permite múltiples condiciones por regla.
-- ============================================================

CREATE TABLE IF NOT EXISTS marcom.tab_condiciones_regla
(
    id_condicion    SERIAL PRIMARY KEY,
    -- Identificador único de la condición

    id_regla        SMALLINT NOT NULL,
    -- Regla a la que pertenece la condición

    id_campo        SMALLINT NOT NULL,
    -- Campo que se va a evaluar (FK a campos_segmentacion)

    ind_opera       VARCHAR(10) NOT NULL CHECK (ind_opera IN ('=', '>', '<', '>=', '<=', 'IN')),
    -- Operador de comparación:
    -- =   → igual
    -- >   → mayor
    -- <   → menor
    -- >=  → mayor o igual
    -- <=  → menor o igual
    -- IN  → dentro de una lista

    val_numero      DECIMAL(10,2),
    -- Valor numérico para comparación (si tipo_dato = NUMERICO)

    val_texto       VARCHAR(100),
    -- Valor texto (si tipo_dato = TEXTO o IN)

    val_fecha       DATE,
    -- Valor fecha (si tipo_dato = FECHA)

    FOREIGN KEY (id_regla) REFERENCES marcom.tab_reglas_segmentacion(id_regla),
    FOREIGN KEY (id_campo) REFERENCES marcom.tab_campos_segmentacion(id_campo)
);
